package com.noblebug.chefpro.planner;

import java.util.ArrayList;
import java.util.List;
import com.noblebug.chefpro.cookbook.RecipePreviewButtonInfo;
import com.noblebug.chefpro.tools.IconifiedText;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CalendarTextButtonAdapter extends BaseAdapter{

	private List<String> textItems = new ArrayList<String>();
	private Context mContext;
	
	public CalendarTextButtonAdapter(Context context,List<String> tmp) {
		mContext = context;
		textItems = tmp;
	}
	
	@Override
	public int getCount() {
		return textItems.size();
	}

	@Override
	public String getItem(int position) {
		return textItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// create a textView beside a button
		View v = convertView;
        String fulltext = textItems.get(position);
        TextView myText = new TextView(mContext);
        myText.setText(fulltext);
        myText.setTextColor(Color.rgb(66, 41, 10));
        LinearLayout myLayout = new LinearLayout(mContext);
        myLayout.addView(myText);      
        return myLayout;
	}

}
