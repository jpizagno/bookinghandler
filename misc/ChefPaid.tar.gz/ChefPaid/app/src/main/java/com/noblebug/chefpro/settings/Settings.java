package com.noblebug.chefpro.settings;

public class Settings {
	// this is a class that holds the Settings.
	// may be depricated.  4 June 2011
	
	// getter methods
	public boolean getQuantityInGroceryLists() {
		return QuantityInGroceryLists;
	}

	public boolean getDisableSleep() {
		return DisableSleep;
	}

	public boolean getQuantityBadge() {
		return QuantityBadge;
	}

	public String getcolorTheme() {
		return colorTheme;
	}

	public String getStartingPage() {
		return StartingPage;
	}

	// setter methods
	public void getQuantityInGroceryLists(boolean tempQuantityInGroceryLists) {
		QuantityInGroceryLists = tempQuantityInGroceryLists;
	}

	public void getDisableSleep(boolean tempDisableSleep) {
		DisableSleep = tempDisableSleep;
	}

	public void getQuantityBadge(boolean tempQuantityBadge) {
		QuantityBadge = tempQuantityBadge;
	}

	public void getcolorTheme(String tempcolorTheme) {
		colorTheme = tempcolorTheme;
	}

	public void getStartingPage(String tempStartingPage) {
		StartingPage = tempStartingPage;
	}

	// this object has the settings infomation
	boolean QuantityInGroceryLists = true;
	boolean DisableSleep = false;
	boolean QuantityBadge = true;
	// MAKE SECTION ORDER'
	String colorTheme = "blue"; // blue or black
	String StartingPage = "home"; // home,grocerylist, cookbook, recipesearch
}
