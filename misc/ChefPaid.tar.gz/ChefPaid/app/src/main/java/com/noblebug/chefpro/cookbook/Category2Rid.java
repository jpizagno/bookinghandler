package com.noblebug.chefpro.cookbook;

import java.util.HashMap;
import java.util.Map;

import com.noblebug.chefpro.R;

public class Category2Rid {
	//
	 // Class to fill/return the Map of category to Resource Integer.
	 // 12 May 2011 jim
	 //
	
	public Category2Rid() {
		fillmapper();
	}

	private void fillmapper() {
		// sets the key=category value=resourceInteger in the map
		Category2Rint.put("appetizer", R.drawable.appetizer);
		Category2Rint.put("bread", R.drawable.bread);
		Category2Rint.put("breakfast", R.drawable.breakfast);
		Category2Rint.put("breakfeast", R.drawable.breakfast);
		Category2Rint.put("brunch", R.drawable.brunch);
		Category2Rint.put("dessert", R.drawable.dessert);
		Category2Rint.put("drink", R.drawable.drink);
		Category2Rint.put("lunch", R.drawable.lunch);
		Category2Rint.put("maincourse", R.drawable.maincourse);
		Category2Rint.put("main course", R.drawable.maincourse);
		Category2Rint.put("outdoor", R.drawable.outdoor);
		Category2Rint.put("salad", R.drawable.salad);
		Category2Rint.put("sauce", R.drawable.sauce);
		Category2Rint.put("side", R.drawable.side);
		Category2Rint.put("soup", R.drawable.soup);
		Category2Rint.put("other", R.drawable.other);
	}

	static Map<String, Integer> Category2Rint = new HashMap<String, Integer>();

	public int getRid(String category) {
		// returns the category. default is Other
		category = category.toLowerCase();
		if (Category2Rint.containsKey(category) == true) {
			return Category2Rint.get(category);
		} else {
			return R.drawable.other;
		}
	}
}
