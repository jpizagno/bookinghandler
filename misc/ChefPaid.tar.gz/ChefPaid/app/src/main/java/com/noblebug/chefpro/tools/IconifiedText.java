package com.noblebug.chefpro.tools;

import android.graphics.drawable.Drawable;

public class IconifiedText implements Comparable<IconifiedText> {
	// compares a text and icon
	// getter and setter methods.  
	// 4 June 2011, Jim Pizagno

	public IconifiedText(String text, Drawable bullet) {
		mIcon = bullet;
		mText = text;
	}

	public boolean isSelectable() {
		return mSelectable;
	}

	public void setSelectable(boolean selectable) {
		mSelectable = selectable;
	}

	public String getText() {
		return mText;
	}

	public void setText(String text) {
		mText = text;
	}

	public void setIcon(Drawable icon) {
		mIcon = icon;
	}

	public Drawable getIcon() {
		return mIcon;
	}
	

	// Make IconifiedText comparable by its name */
	public int compareTo(IconifiedText other) {
		if (this.mText != null)
			return this.mText.compareTo(other.getText());
		else
			throw new IllegalArgumentException();
	}

	// fields
	private String mText = "";
	private Drawable mIcon;
	private boolean mSelectable = true;
	public Integer recipeid;
}
