package com.noblebug.chefpro.cookbook;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.planner.Planner;
import com.noblebug.chefpro.recipe.Recipe;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.settings.AboutChef;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.FlagToRid;
import com.noblebug.chefpro.tools.IconifiedTextListAdapter;
import com.noblebug.chefpro.tools.ImageHandler;
import com.noblebug.chefpro.tools.NewUser;
import com.noblebug.chefpro.tools.RecipeButtonAdapter;
import com.noblebug.chefpro.tools.RecipeListDisplay;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class CookbookSelectorDisplay extends Activity {
	
	 // class to display the cookbook. it has a selector. and displays cookbook buttons.
	 // can also login user. can also delete recipes.
	 // 12May2011 Jim
	// 
	// method description:   
	// onCreate()  -  called when this activity is first created.
	// callRecipeListDisplay(String format) -   this is called when a button is selected
	// TitleView() - creates the view of the title
	// SelectorView() -  creates the view o the Selector
	// onStop() - handles activity lifecycle
	// callSelf(String)  - re-creates self when items in list have changed
	// onCreateOptionsMenu(Menu) -  creates the menu
	// onMenuItemSelected(int, MenuItem) - handles methods when menu item is selected
	// contact_us() - allows the user to email chefslittlehelper@gmail.com
	// createNewUser() - allows the user to login, which will then sync webpage and phone
	// downloadRecipesUponStart(Context, Integer) - downloads recipes when the Application is first run
	// progressHandler() - Handler for progress bar as recipes are downloaded
	// startProgressDialog4ExampleRecipes(int=userID) - downloads 10 example recipes
	// Add2Cookbook(Recipe) - adds Recipe object to DB
	// messageListDelete() - displays the Dialog that allows the user to delete recipes
	// DeleteRecipe(int) - index(int) or Recipe to be deleted from DB.
	// reCreateObjectsReDisplayCookbook() - re-create all objects that store information for Chef
	// gotoChef()  - go to Home activity
	// gotoCookbook() -  go to the Cookbook
	// createTimers() - go to the Timers activity
	// createSearch() - go to the Search activity
	// createGroceryList() -  go to the Grocery List
	// createCookbook() - depricated class
	
	public void onCreate(Bundle savedInstanceState) {
		/* 
		 * called when activity is first created
		 */
		super.onCreate(savedInstanceState);
		// do some cleaning before creating object(s)
		System.gc();
		
		// create appState object from ChefController class
		appState = ((ChefController) getApplicationContext());
		
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		
		if(appState.getUIDandPASSWD().split("_")[0]==null 
				// password check:
				| appState.getUIDandPASSWD().split("_")[0].equalsIgnoreCase("null")==true ){
			//get UID from DB and pass back to appstate:
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			String[] temp = mDbHelper.getUserSingle();
			this.userid = Integer.valueOf(temp[BackEndSQLite.out_int_userid]);
			String password = temp[BackEndSQLite.out_int_password];
			appState.setUIDandPASSWD(String.valueOf(userid), password);
			mDbHelper.close();
		}
		
		
		
		if(appState.check4InternetConnection(this)){
			// check to see if the internet is working:
			//check to see if the user wants to download the starter recipes
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			boolean alreadyDownloaded = true;
			if (appState.getUIDandPASSWD().split("_")[0]!=null) {
				alreadyDownloaded = mDbHelper.getCookbookDownloaded(Integer.valueOf(appState.getUIDandPASSWD().split("_")[0]));
				mDbHelper.close();	
				if(alreadyDownloaded==false) {
					downloadRecipesUponStart(this, Integer.valueOf(appState.getUIDandPASSWD().split("_")[0]));
				}
			}			
		}
		
		// instantiate:  image handler for chef images:
		myImageHandler = new ImageHandler();
		myContext = this;
		// get cookbook objects from appState
		// make field so DeleteRecipes can get it.
		myCookbook = appState.getCookbook();
		if (myCookbook==null){  // make sure this is not null
			appState.createObjects(this.myContext);
			myCookbook = appState.getCookbook();
		}

		// get Tab type: all,cuisines,categories
		format = getIntent().getStringExtra("key");

        //get State:
        String cookbookState = "chefs";
        final SelectorView mySelector = new SelectorView(this);
    	if (getIntent().hasExtra("cookbookState")==true) {
        	cookbookState = (String) getIntent().getExtras().get("cookbookState");
    		mySelector.setState(cookbookState);
    		mDbHelper = new BackEndSQLite(this);
    		mDbHelper.open();
    		int UserID = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
    		mDbHelper.setCookbookState(String.valueOf(UserID), cookbookState);
    		mDbHelper.close();
        	mySelector.invalidate();
    	} else {
    		mDbHelper = new BackEndSQLite(this);
    		mDbHelper.open();
    		int UserID = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
    		cookbookState = mDbHelper.getCookbookState(String.valueOf(UserID));
    		mDbHelper.close();
        	mySelector.setState(cookbookState);
    	}
    	
    	// make and define the clear windowframe
    	buttonheight = this.getWindowManager().getDefaultDisplay().getHeight()/8;
    	windowYfraction = (float) 0.80;
    	windowXfractionChef = (float) 0.17;
    	windowXfractionNotChef = (float) 0.25;
    	int Ysize = (int) ((float)buttonheight *windowYfraction); //70/100;  ///2;
		int Xsize;
		if(cookbookState.equalsIgnoreCase("chefs")==true) {
			Xsize = (int)((float)this.getWindowManager().getDefaultDisplay().getWidth()*windowXfractionChef); //15/100;  
		} else {
			Xsize = (int)((float)this.getWindowManager().getDefaultDisplay().getWidth()*windowXfractionNotChef); //20/100; 
		}
		windowXposition = Xsize*1/4;
    	windowYposition = buttonheight*1/10;
		//System.out.println("***** (float)buttonheight="+String.valueOf((float)buttonheight)
		//		+" windowYfraction="+String.valueOf(windowYfraction));
		WindowFrame = Bitmap.createScaledBitmap(
	    				BitmapFactory.decodeResource(this.getResources(), R.drawable.windowframe)
	    				, Xsize, Ysize, true);
        
    	// define layout
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setBackgroundResource(R.drawable.cookbookbackground);
		
		TitleView myTitle = new TitleView(this,R.drawable.cookbooktitle,
				this.getWindowManager().getDefaultDisplay().getWidth(),
				this.getWindowManager().getDefaultDisplay().getHeight());
		mLinearLayout.addView(myTitle);
		
		
		// add selector at top which displays cuisines,categories,chefs
		mySelector.setPadding(0, 5, 0, 5);
		mySelector.setClickable(true);
		mySelector.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_UP:
		            {
		            	float screenSize = mySelector.getWidth();
		            	float x = ev.getX();
		            	float percentX = x/screenSize;
		            	if(percentX<=0.33){
		            		callSelf("cuisines");
		            	}
		            	if(percentX>0.33 && percentX<=0.66){
		            		callSelf("categories");
		            	}
		            	if(percentX>0.66){
		            		callSelf("chefs");
		            	}
		            	break;
		            }
		        }
				return true;
			}
		});
		mLinearLayout.addView(mySelector);
		
		
		// add cuisines:
		if (cookbookState.equalsIgnoreCase("cuisines")) {
			Set<String> cuisines = myCookbook.getCuisinesSet();
			if(cuisines.isEmpty()) {
				// recreate if empty.  may happen during crash
				myCookbook.setupValues();
				cuisines = myCookbook.getCuisinesSet();
			}
			cuisine_info = new ArrayList<RecipePreviewButtonInfo>();  // collection of RecipePreviewButtonInfo objects
			for (Iterator it = cuisines.iterator(); it.hasNext();) {
				final String cuisinename = ((String) it.next());
				String cuisename4test = cuisinename.toLowerCase();
				// create a Recipe Preview Button and set meta data
				RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this); 
				myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
				myrecipe.setResource(Flag2IntMapper.getRid(cuisename4test)); // get Flag from Collection
				myrecipe.setButtonText(cuisinename);
				// set graphic size and position
				myrecipe.setXY(this.getWindowManager().getDefaultDisplay().getWidth(), this.buttonheight);
				myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
				myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
				myrecipe.partofCookbook = true; 
				cuisine_info.add(myrecipe);
			}
			// give cuisine_info collection to instance of adapter
			final ListView myListView = new ListView(this);
			myListView.setCacheColorHint(Color.TRANSPARENT);
			myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.FILL_PARENT));
			this.adapter_fileorresource = new RecipeButtonAdapter(this, R.layout.rowcookbook, cuisine_info);
			myListView.setAdapter(this.adapter_fileorresource);
			// give adapter to layoutmanager
		    mLinearLayout.addView(myListView);
			
		    // make clickable
		    myListView.setClickable(true);
	        myListView.setFocusable(true);
	        myListView.setDividerHeight(0);
	        myListView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
					String cuisinename = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getButtonText();
					String casename = "cuisine::"+cuisinename;
	            	callRecipeListDisplay(casename);
				}
			});
	        setContentView(mLinearLayout);
		}
		
      
		if (cookbookState.equalsIgnoreCase("chefs")) {
			// add chefs to the display:
			chef_info = new ArrayList<RecipePreviewButtonInfo>();  // collection of RecipePreviewButtonInfo-Chef objects
			Map<String, String> ChefsCollection = myCookbook.getChefs();
			if (ChefsCollection.isEmpty()) {
				// recreate.. safety feature.
				myCookbook.setupValues();
				ChefsCollection = myCookbook.getChefs();
			}
			// iterate through list of chefs.
			for (Iterator it = ChefsCollection.keySet().iterator(); it.hasNext();) {
				final String chefname = (String) it.next();
				final Integer chefid = Integer.valueOf(ChefsCollection.get(chefname).split("::")[0]);
				final Integer chefimagedownloaded = 
					Integer.valueOf(ChefsCollection.get(chefname).split("::")[1]);
				// get image.  either on disk, or default
				RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this); 
				if (chefimagedownloaded==0){
					// image downloaded	. do not re-download	
					if(chefid>=0) {
						String imagename = ChefsCollection.get(chefname).split("::")[2];
						if (imagename==null | imagename.equalsIgnoreCase("null")) {
							myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
							myrecipe.setResource(R.drawable.chefprofile);
						} else {
							myrecipe.setType(RecipePreviewButtonInfo.FILEONDISK);
							myrecipe.setDrawableFileName(imagename);
						}
					} else {
						// this step may be obsolete
						//resourceInt = R.drawable.chefprofile;
						myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
						myrecipe.setResource(R.drawable.chefprofile);
					}
				} else {
					// load default image
					myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
					myrecipe.setResource(R.drawable.chefprofile);
				}
				myrecipe.setChefID(chefid);
				myrecipe.setButtonText(chefname);
				// set button graphic
				myrecipe.setXY(this.getWindowManager().getDefaultDisplay().getWidth(), this.buttonheight);
				myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
				myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
				myrecipe.partofCookbook = true; 
				chef_info.add(myrecipe);
			}
			// give collection to instance of adapter
			final ListView myListView = new ListView(this);
			myListView.setCacheColorHint(Color.TRANSPARENT);
			myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.FILL_PARENT));
			this.adapter_fileorresource = new RecipeButtonAdapter(this, R.layout.rowcookbook, chef_info);
			myListView.setAdapter(this.adapter_fileorresource);
			// give adapter to layoutmanager
		    mLinearLayout.addView(myListView);
			
		    // make clickable, focusable
		    myListView.setClickable(true);
	        myListView.setFocusable(true);
	        myListView.setDividerHeight(0);
	        myListView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
					String chefname = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getButtonText();
					int chefid = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getChefID();
	            	String casename = "chef::"+ String.valueOf(chefid)+"::"+chefname;     
	            	callRecipeListDisplay(casename);
				}
			});
	        setContentView(mLinearLayout);
		}
		
		 
		if (cookbookState.equalsIgnoreCase("categories")) {
			// add categories to display
			Set<String> categories = myCookbook.getCategorySet();
			if(categories.isEmpty()) {
				// recreate if empty.  may happen during crash
				myCookbook.setupValues();
				categories = myCookbook.getCategorySet();
			}
			category_info = new ArrayList<RecipePreviewButtonInfo>(); // collection of RecipePreviewButtonInfo objects
			for (Iterator it = categories.iterator(); it.hasNext();) {
				// iterate through categories, adding each one to the ArrayList
				final String category = ((String) it.next());
				String categorytest = category.toLowerCase();
				RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this);
				myrecipe.setResource(Flag2IntMapper.getRid(categorytest));
				myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
				myrecipe.setButtonText(category);
				myrecipe.setXY(this.getWindowManager().getDefaultDisplay().getWidth(), this.buttonheight);
				myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
				myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
				myrecipe.partofCookbook = true; 
				category_info.add(myrecipe);
			}
			// give collection to instance of adapter
			final ListView myListView = new ListView(this);
			myListView.setCacheColorHint(Color.TRANSPARENT);
			myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.FILL_PARENT));
			this.adapter_fileorresource = new RecipeButtonAdapter(this, R.layout.rowcookbook, category_info);
			myListView.setAdapter(this.adapter_fileorresource);
			// give adapter to layoutmanager
		    mLinearLayout.addView(myListView);
			
		    // make clickable
		    myListView.setClickable(true);
	        myListView.setFocusable(true);
	        myListView.setDividerHeight(0);
	        myListView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
	            	String category = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getButtonText();
	            	String casename = "category::"+category;
	            	callRecipeListDisplay(casename);
				}
			});
	        setContentView(mLinearLayout);
		}
        
        // do some cleaning before creating object(s)
		System.gc();
	}
	
	private void callRecipeListDisplay(String casename){
		/*
		* this is called when a button is clicked. It creates an activity that displays a list of recipes
		* call format:  casename = "chef::4","category::maincourse","cuisine::american"
		*/
		Intent i = new Intent(this, RecipeListDisplay.class);
		i.putExtra("How2Display", casename.trim());
		startActivityForResult(i, ACTIVITY_RECIPELISTDISPLAY);
	}
	
	private class TitleView extends View {
		/*
		 *  displays the title of the cookbook. this is a graphics with ONE of chefs,cuisines,categories as PUSHED.
		 */
		Integer resourceInt;
		Integer width;
		Integer height;
		public TitleView(Context innercontext,Integer resourceInttemp,Integer screenWidth, Integer screenHeight){
    		super(innercontext);
    		resourceInt=resourceInttemp;
    		width = screenWidth;
    		height = screenHeight * 10 / 100;
		}
	   	protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			this.setBackgroundResource(resourceInt);
    	}
    	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
    		this.setMeasuredDimension(width,height);
    	} 
	}
	
    private class SelectorView extends View {
    	/*
    	* Displays the "Cuisines","Categories","Chefs" selector.
    	*/
    	private String cookbookState="chefs";
		private Drawable myDrawable;
		private Integer width;
		private Integer height;
		
		public void setState(String temp){
			// sets the state of how the selector should display
			cookbookState=temp;
			
			Display display = getWindowManager().getDefaultDisplay();
			width = display.getWidth();
			height = display.getHeight() / 12;
			
	   		if(cookbookState.equalsIgnoreCase("chefs")){
	   			myDrawable = this.getResources().getDrawable(R.drawable.cookbooktabchefs);
    		}
    		if(cookbookState.equalsIgnoreCase("cuisines")){
    			myDrawable = this.getResources().getDrawable(R.drawable.cookbooktabcuisine);
    		}
    		if(cookbookState.equalsIgnoreCase("categories")){
    			myDrawable = this.getResources().getDrawable(R.drawable.cookbooktabcategory);
    		}
		}
    	public SelectorView(Context innercontext){
    		super(innercontext);
    	}
    	protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			this.setBackgroundDrawable(myDrawable);
    	}
    	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
    		this.setMeasuredDimension(width,height);
    	} 
    }
 
	@Override
	protected void onStop() {
		/*
		 *  activity life cycle handling
		 */
		super.onStop();
		// check later for things to clear/stop
	}
	
	private void callSelf(String cookbookState) {
		/*
		 *  save state, and call self when items in list have changed.
		 */
		Intent i = new Intent(this, CookbookSelectorDisplay.class);
		i.putExtra("cookbookState", cookbookState);
		startActivity(i);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		/*
		 *  create menu
		 */
		super.onCreateOptionsMenu(menu);
		
		if (userid== null || userid > -1) {
			// only add Planner when user is logged in
			Drawable mealplanner = this.getResources().getDrawable(R.drawable.mealplanner);
			menu.add(0, Planner_ID, 0, "").setIcon(mealplanner);;
		}
		
		menu.add(0, DeleteRecipe_ID, 0, R.string.btndeleterecipe);
		
		menu.add(0, Login_ID, 0, "Login");
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "Home").setIcon(home);
		menu.add(0, AboutChef_ID, 0, "About Chef");
		menu.add(0, Contact_ID, 0, "Contact Us");
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		/*
		 *  create menu listener, that tells us which activity to start, according to which menu button was pushed.
		 */
		switch (item.getItemId()) {
		case Planner_ID:
			goto_planner();
			return true;
		case Contact_ID:
			contact_us();
			return true;
		case DeleteRecipe_ID:
			this.messageListDelete();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		case Login_ID:
			this.createNewUser();
			return true;
		case AboutChef_ID:
			this.gotoAboutChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}
	
	private void contact_us() {
		/*
		 *  email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
		 * users to provide feedback.
		 */
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity Cookbook");
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    // avoid catch
		}
	}
	
	private void goto_planner() {
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}
	
	private static final int AboutChef_ID = 10;
	protected void gotoAboutChef() {
		Intent i = new Intent(this, AboutChef.class);
		startActivity(i);
	}
	private void createNewUser() {
		/*
		 *  call new user activity.  OR login
		 */
		Intent i_newuser = new Intent(this, NewUser.class);
		startActivity(i_newuser);
	}
	
	
	private void downloadRecipesUponStart(Context innercontext, final Integer userid) {
		/*
		 * This method asks the user if they want to download the recipes.
		*
		* it should only be called once.
		* if the user selects yes, then it should download the recipes:
		* @"11161",@"11549",@"2359",@"256",@"8",@"103",@"31",@"8670",@"11119",@"10422",@"9853"
		*/
		final CharSequence[] items = new CharSequence[2]; //Home,Cookbook,GroceryList,Search,Timers
		items[0]="Yes";
		items[1]="No";
		final boolean[] checked = new boolean[2];
		checked[0]=false;
		checked[1]=false;
		// ask user if they want to download recipes
		final AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Download 11 sample recipes?");
		int arg1=-1;
		builder.setSingleChoiceItems(items, arg1,  new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// click one, unclick the other
				if (which==1){
					checked[1]=true;
					checked[0]=false;
				} else {
					checked[1]=false;
					checked[0]=true;
				}
			}
		});
		
		// if yes, then download, add to cookbook
		AlertDialog alert = builder.create();
		alert.setButton2("Proceed",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						if (checked[0]) {
							startProgressDialog4ExampleRecipes(userid);
						}
					}
				});
		alert.show();
	}
	
	// handler for the background updating
    Handler progressHandler = new Handler() {
        public void handleMessage(Message msg) {
        	myProgressDialog.incrementProgressBy(increment);
        }
    };
	
	private void startProgressDialog4ExampleRecipes(final int userid){
		/*
		 *  download recipes:
		 *
		*@"11161",@"11549",@"2359",@"256",@"8",@"103",@"31",@"8670",@"11119",@"10422",@"9853"
		*/
		final Integer[] recipeIDs = new Integer[11];
		recipeIDs[0]=11161;
		recipeIDs[1]=11549;
		recipeIDs[2]=2359;
		recipeIDs[3]=256;
		recipeIDs[4]=8;
		recipeIDs[5]=103;
		recipeIDs[6]=31;
		recipeIDs[7]=8670;
		recipeIDs[8]=11119;
		recipeIDs[9]=10422;
		recipeIDs[10]=9853;
		//recipeIDs[11] = 1000000; // for testing
		final BackEndPHPHandler myPHP = new BackEndPHPHandler();
			
		myProgressDialog = new ProgressDialog(this);
		myProgressDialog.setCancelable(true);
		myProgressDialog.setMessage("Downloading Recipes...");
		// set the progress to be horizontal
		myProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        // reset the bar to the default value of 0
		myProgressDialog.setProgress(0);
        // get the maximum value
        // convert the text value to a integer
        final int maximum = recipeIDs.length;
        increment = 1;
        // set the maximum value
        myProgressDialog.setMax(maximum);
        // display the progressbar
        myProgressDialog.show();
        // create a thread for updating the progress bar
        Thread background = new Thread (new Runnable() {
           public void run() {
               // enter the code to be run while displaying the progressbar.
			   //
			   // This example is just going to increment the progress bar:
			   // So keep running until the progress value reaches maximum value
			   //while (myProgressDialog.getProgress()<= myProgressDialog.getMax()) {
			   for (int i=0;i<maximum;i++) {
				   String contentsStringRecipe = "RecipeNAME";
	            	try {
					   myPHP.fetchStringRecipe(recipeIDs[i], userid);
					   contentsStringRecipe = myPHP.contentsStringRecipe;
					   Recipe recipe2download = myPHP.RecipeFromFetchString;
					   // put in database:
					   Add2Cookbook(recipe2download);
				       progressHandler.sendMessage(progressHandler.obtainMessage());
	            	} catch (Exception e) {
	            		String comment = "::from CookbookSelectorDisplay.startProgressDialog4ExampleRecipes could not dowload recipeid: "+recipeIDs[i]+" ::contentsStringRecipe:"+contentsStringRecipe;
	            		String priority = "WARNING";
	            		myPHP.exceptionlog(userid,comment,priority);
	            	}
			   }
			   myProgressDialog.dismiss();
			   gotoCookbook();
           }
        });
        // start the background thread
        background.start();
	}

	
	private void Add2Cookbook(Recipe recipehere) {
		/*
		 *  add a recipe (recipehere) to the cookbook
		 */
		if (recipehere == null ) {  
			// maybe the progress updater thread bombs in the middle.  What to do now?
			
		} else { // recipehere!=null so load into DB:
			recipehere.partofcookbook = 0;
			if (recipehere.Imagehttp==null || recipehere.Imagehttp.equalsIgnoreCase("null")) {  
				// no image with this recipe, dont download.
				recipehere.PictureNameOnDisk=null;
				recipehere.Imagehttp=null;
			} else {
				if (recipehere.PictureNameOnDisk==null) {
					// download file
					if (appState.internetConnectionOpen==true) {
						ImageHandler myImgHandler = new ImageHandler();
						myImgHandler.downloadFile(recipehere.Imagehttp);
						recipehere.PictureNameOnDisk = myImgHandler.imagename;
					} else {
						//Toast.makeText(getBaseContext(), "This device may not be connected to the internet",
						//		Toast.LENGTH_SHORT).show();
					}
				}
			}
			// get chef image if needed:
			// cannot check if a particular recipe has its chefimagedownloaded because
			// one chef can have multiple recipes.  so check database for recipes that have
			// that chef AND have it downloaded:
			BackEndSQLite mDbHelperInner;
			mDbHelperInner = new BackEndSQLite(this);
			mDbHelperInner.open();
			if(mDbHelperInner.chefImageDownaloded(recipehere.chefname)==false) {
				// chef image not downloaded so downloaded.
				if (appState.internetConnectionOpen==true) {
					ImageHandler myImgHandler = new ImageHandler();
					String answer=myImgHandler.downloadChefImage(recipehere.user);
					if (answer.equals("None")) {
						// no image
						recipehere.chefimagedownloaded=1;
						recipehere.chefimagename="None";
					} else {
						recipehere.chefimagedownloaded=0;
						recipehere.chefimagename = answer;
					}
				} else {
					// no open connection
					recipehere.chefimagedownloaded=1;
				}
			} else {
				recipehere.chefimagedownloaded=0;
			}
			// add recipe to the cookbook/database
			mDbHelperInner.addRecipe(recipehere);
			mDbHelperInner.close();
			// update cookbook
			Cookbook myCookbook = appState.getCookbook();
			if (myCookbook==null){  // make sure this is not null
				appState.createObjects(this);
				myCookbook = appState.getCookbook();
			}
			// have cookbook update values by calling database.
			myCookbook.setupValues();
			// pass this cookbook back to the Chefcontroller
			appState.setCookbook(myCookbook);
		}
	}
	
	
	private void messageListDelete() {
		/*
		 *  displays the Dialog that allows the user to delete recipes
		 */
		final CharSequence[] items = new CharSequence[this.myCookbook.AllRecipesInCookBook
				.size()];
		final boolean[] checked = new boolean[this.myCookbook.AllRecipesInCookBook
				.size()];
		final Integer[] recipeIDs = new Integer[this.myCookbook.AllRecipesInCookBook
				.size()];

		int i = -1;
		for (Iterator it = this.myCookbook.AllRecipesInCookBook.keySet().iterator(); it.hasNext();) {
			String recipehere = (String) it.next();
			i = i + 1;
			items[i] = recipehere;
			checked[i] = false;
			recipeIDs[i] = this.myCookbook.AllRecipesInCookBook.get(recipehere);
		}

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Select Recipes to Delete");
		builder.setMultiChoiceItems(items, checked,
				new DialogInterface.OnMultiChoiceClickListener() {
					public void onClick(DialogInterface dialog, int which,
							boolean isChecked) {
					}
				});
	

		AlertDialog alert = builder.create();
		
		alert.setButton2("Delete Recipes",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						for (int i = 0; i < checked.length; i++) {
							if (checked[i]) {
								DeleteRecipe(recipeIDs[i]);
							}
						}
						reCreateObjectsReDisplayCookbook();
					}
				});

		alert.show();
	}

	private void DeleteRecipe(int recipehereID) {
		/*
		 *  given a unique recipe index, delete that recipe from the DB and webpage.
		 */
		BackEndSQLite mDbHelperInner;
		mDbHelperInner = new BackEndSQLite(this);
		mDbHelperInner.open();
		Recipe recipehere = mDbHelperInner.getRecipeByID(recipehereID);
		mDbHelperInner.deleteRecipe(recipehere.recipeid);// deletes recipe from database, delete before syncing to web
		int UserID = Integer.valueOf(mDbHelperInner.getUserSingle()[BackEndSQLite.out_int_userid]);
		String username = mDbHelperInner.getUserSingle()[BackEndSQLite.out_int_username];
		String md5password = mDbHelperInner.getUserSingle()[BackEndSQLite.out_int_md5hashpass];
		if (UserID>0 || username.equalsIgnoreCase("newUser")==false) {
			// if user is logged in, then delete recipe from webpage:  
			BackEndPHPHandler myPHP3 = new BackEndPHPHandler();
			if (UserID==recipehere.user){  //API says match on userid not username
				// from API:  If it's YOUR recipe then call deleterecipe.php with index and password parameters. 
				myPHP3.deleteRecipe(recipehere.recipeid,md5password,UserID);
			} else {
				//           If it's a bookmark then call bookmarkstoweb.php.
				List<Integer> recipeIDs_bookmarked = mDbHelperInner.getAllRecipesNotThisUser(UserID);
				if (recipeIDs_bookmarked.size()==0) {
					// still may need to delete current recipe. database deleted it.
					// this is a problem for the case when there is a single recipeid left.
					// DB deletes it. by how to tell the website to clear the recipes.
					recipeIDs_bookmarked.add(0);
				} 
				myPHP3.bookmarkstoweb(UserID,recipeIDs_bookmarked,md5password);
			}
		} //else user not logged in. so do nothing with webpage
		mDbHelperInner.close();
		reCreateObjectsReDisplayCookbook();
		return;
	}
	
	private void reCreateObjectsReDisplayCookbook() {
		/*
		 *  recreate all objects of phone, and then re-display this cookbook acitvity.
		 */
		mDbHelper.close();
		appState.createObjects(this);
		Intent myIntent = new Intent(this, CookbookSelectorDisplay.class);
		startActivity(myIntent);
	}

	private void gotoChef() {
		/*
		 *  go to the Home page
		 */
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}
	
	private void gotoCookbook() {
		/*
		 *  go to the cookbook
		 */
		Intent i = new Intent(this, CookbookSelectorDisplay.class);
		startActivity(i);
	}

	private void createTimers() {
		/*
		 *  goto timers
		 */
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		// search can get this from the Chef controller
		startActivity(i_search);
	}

	private void createGroceryList() {
		/*
		 *  save state, and go to the grocerylist
		 */
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivity(i_grocerylist);
	}

	private void createCookbook() {
		Intent i_cookbook = new Intent(this, Cookbook.class);
		startActivity(i_cookbook);
	}
	

	// onCreate is called when object is first created.
	private RecipeButtonAdapter adapter_fileorresource;
	private ArrayList<RecipePreviewButtonInfo> chef_info;
	private ArrayList<RecipePreviewButtonInfo> category_info;
	// create variables, fields, Adapter
	private ArrayList<RecipePreviewButtonInfo> cuisine_info;
	private final int Cookbook_ID = 0;
	private final int Grocerylist_ID = 1;
	private final int Search_ID = 2;
	private final int Timers_ID = 3;
	private final int Chef_ID = 4;
	private final int ACTIVITY_RECIPELISTDISPLAY = 5;
	private final int DeleteRecipe_ID = 5;
	private final int Login_ID = 6;
	private final int Planner_ID = 7;
	static final int Contact_ID = 11;
	IconifiedTextListAdapter itla;
	private BackEndSQLite mDbHelper;
	FlagToRid Flag2IntMapper = new FlagToRid();
	ImageHandler myImageHandler;
	public Bitmap WindowFrame;
	private String format;
	private Cookbook myCookbook;
	private ChefController appState;
	private Context myContext;
	private LinearLayout mLinearLayout;
	private int buttonheight;
	private ProgressDialog myProgressDialog;
	private float windowYfraction;
	private float windowXfractionChef;
	private float windowXfractionNotChef;
	private int windowXposition;
	private int windowYposition;
	private int increment;
	private Integer userid;
}
