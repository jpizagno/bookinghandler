package com.noblebug.chefpro.tools;

import com.noblebug.chefpro.R;
import android.content.Context;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class StarView extends LinearLayout {
	// class used to display stars for rating.
	// number of stars can be non integer, for half star ratings, i.e. 3.5
	// it is used in RecipeView. In future should be used in RecipePreview.
	// 4 June 2011 Jim Pizagno

	public StarView(Context context, float numstarstmp, Integer BackgroundColorInt, int screenwidth) {
		super(context);
		// this is just a class that loads the stars.
		this.numstars = numstarstmp;
		
		int starSize = screenwidth * 4/100;
		
		Integer numstars_int = (int) numstars;
		
		Integer numstars_half_int = (int) (numstars + 0.5) - (int) numstars;
		
		Integer numstars_blank_int = (int) 5 - (numstars_half_int + numstars_int);

		mLinearLayout = new LinearLayout(context);
		mLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
		if (BackgroundColorInt!=null) {
			mLinearLayout.setBackgroundColor(BackgroundColorInt);
		} else {
			mLinearLayout.setBackgroundResource(R.drawable.grocerypaperbackgroundstar);
		}

		for (int i = 0; i < numstars_int; i++) {
			ImageView image1 = new ImageView(context);
			image1.setImageResource(R.drawable.star);
			mLinearLayout.addView(image1,starSize,starSize);
		}

		for (int i = 0; i < numstars_half_int; i++) {
			ImageView image2 = new ImageView(context);
			image2.setImageResource(R.drawable.starhalf);
			mLinearLayout.addView(image2,starSize,starSize);
		}

		for (int i = 0; i < numstars_blank_int; i++) {
			ImageView image3 = new ImageView(context);
			image3.setImageResource(R.drawable.starblank);
			mLinearLayout.addView(image3,starSize,starSize);
		}

		setGravity(Gravity.CENTER_HORIZONTAL);

		addView(mLinearLayout);
	}
    
	
	public void setStars(float numstarstmp){
		this.numstars=numstarstmp;
	}
	
	// fields
	public float numstars;
	LinearLayout mLinearLayout;

}
