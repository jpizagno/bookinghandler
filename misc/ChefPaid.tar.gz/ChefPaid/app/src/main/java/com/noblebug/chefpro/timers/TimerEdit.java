package com.noblebug.chefpro.timers;

import com.noblebug.chefpro.R;
import com.noblebug.chefpro.search.ArrayWheelAdapter;
import com.noblebug.chefpro.search.WheelView;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class TimerEdit extends Activity {
	// this class is called by TimersDisplay and edits a timer.
	// onBackPressed is overriden to go back to the Timers.
	// 4 June 2011. Jim Pizagno
	
	// class edits a timer's name, and sets the time
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// do not show TITLE, and fix orientation at PORTRAIT
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// give this class time so user can edit existing time
		time_string = getIntent().getStringExtra("time");
		item = getIntent().getStringExtra("item");
		position = getIntent().getIntExtra("position", 0);
		timerint = getIntent().getIntExtra("timerint", 0);

		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setBackgroundResource(R.drawable.cookbookbackground);

		// add title
		LinearLayout innerLayout = new LinearLayout(this);
		innerLayout.setGravity(Gravity.CENTER);
		innerLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.WRAP_CONTENT));
		TextView title = new TextView(this);
		title.setText("Timer Edit");
		title.setTextColor(Color.WHITE);
		title.setBackgroundResource(R.drawable.blanktitle);
		title.setGravity(Gravity.CENTER);
		Typeface myType = Typeface.create(Typeface.SERIF, Typeface.NORMAL);
		title.setTypeface(myType);
		if (this.getWindowManager().getDefaultDisplay().getHeight() > 600) {  
			// this If()else statement accounts for devices with different sizes
			title.setTextSize(36);
		} else {
			title.setTextSize(18);
		}
		innerLayout.addView(title, this.getWindowManager().getDefaultDisplay().getWidth(), 
				this.getWindowManager().getDefaultDisplay().getHeight()*10/100);
		mLinearLayout.addView(innerLayout);
		
		// create edit item edittext
		mytext = new EditText(this);
		//mytext.setText("enter item name i.e. Chicken ");
		mytext.setHint("Timer "+String.valueOf(timerint));
		mLinearLayout.addView(mytext);
		
		
		// add labels that should be:   Hours   Minutes Seconds
		LinearLayout innerLayout4 = new LinearLayout(this);
		innerLayout4.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
		innerLayout4.setOrientation(LinearLayout.HORIZONTAL);
		//innerLayout4.setGravity(Gravity.CENTER_HORIZONTAL);
		innerLayout4.setPadding(5, 25, 5, 0);
		TextView hour_label = new TextView(this);
		hour_label.setText("Hours");
		hour_label.setPadding(5, 0, this.getWindowManager().getDefaultDisplay().getWidth()/10, 0);
		hour_label.setTextColor(Color.rgb(66, 41, 10));
		innerLayout4.addView(hour_label);
		TextView min_label = new TextView(this);
		min_label.setPadding(this.getWindowManager().getDefaultDisplay().getWidth()/7, 0, this.getWindowManager().getDefaultDisplay().getWidth()/7, 0);
		min_label.setText("Min");
		min_label.setTextColor(Color.rgb(66, 41, 10));
		innerLayout4.addView(min_label);
		TextView sec_label = new TextView(this);
		sec_label.setText("Secs");
		sec_label.setTextColor(Color.rgb(66, 41, 10));
		sec_label.setPadding(this.getWindowManager().getDefaultDisplay().getWidth()/10, 0, 0, 0);
		innerLayout4.addView(sec_label);
		mLinearLayout.addView(innerLayout4);
		
		// define sizes
		// must set relative to screeHeight
		//Integer screenHeight = this.getWindowManager().getDefaultDisplay().getHeight();
		//Integer visibleitems = 10;
		//Integer textsize = screenHeight * 4/100;
		//float itemoffset = -8; //textsize/5;  //screenHeight * 55/1000;
		//float x = (float) screenHeight;
		//float itemoffset = (float)-0.00033639086*x*x + (float)0.3712053129*x + (float)-100.67409;
		//float addItemHeight = (float) 0.0;
		//int centerBarHalfWidth = screenHeight*3/100; //20;
		//int centerBarHeightOffsetPix = 0;
		
		// add Wheels
		// create innerLayout2
		LinearLayout innerLayout2 = new LinearLayout(this);
		innerLayout2.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
		innerLayout2.setOrientation(LinearLayout.HORIZONTAL);
		innerLayout2.setGravity(Gravity.CENTER_HORIZONTAL);
		innerLayout2.setPadding(5, 0, 5, 25);
		//// hour wheel
		hourwheel = new WheelView(this);
		LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT, 1);
		hourwheel.setLayoutParams(params2);
	
		//hourwheel.setLabel("hours");
	    hoursarray = this.getResources().getStringArray(R.array.hours);
	    hourwheel.setViewAdapter(new ArrayWheelAdapter<String>(this,hoursarray));
	    hourwheel.setCurrentItem(0);
	    
	    //cuisinewheel.setLabel("cuisines");
	    //hourwheel.setDEFVISIBLEITEMS(visibleitems);  // number of visible items in wheel
	    //hourwheel.setTEXTSIZE(textsize);  // font size
	    //hourwheel.setITEMOFFSET(itemoffset); //offset in pixels?
	    //hourwheel.setADDITIONALITEMHEIGHT(addItemHeight);
	    //hourwheel.setCenterBarHalfWidth(centerBarHalfWidth);
	    //hourwheel.setCenterBarOffsetPixels(centerBarHeightOffsetPix);
	    innerLayout2.addView(hourwheel);
		// minute wheel
	    minutewheel = new WheelView(this);
		minutewheel.setLayoutParams(params2);
		//minutewheel.setLabel("min.");
	    minutesarray = this.getResources().getStringArray(R.array.sixty);
	    minutewheel.setViewAdapter(new ArrayWheelAdapter<String>(this,minutesarray));
	    minutewheel.setCurrentItem(0);
	    //minutewheel.setDEFVISIBLEITEMS(visibleitems);  // number of visible items in wheel
	    //minutewheel.setTEXTSIZE(textsize);  // font size
	    //minutewheel.setITEMOFFSET(itemoffset); //offset in pixels?
	    //minutewheel.setADDITIONALITEMHEIGHT(addItemHeight);
	    //minutewheel.setCenterBarHalfWidth(centerBarHalfWidth);
	    //minutewheel.setCenterBarOffsetPixels(centerBarHeightOffsetPix);
	    innerLayout2.addView(minutewheel);
	    // second wheel
	    secondwheel = new WheelView(this);
	    secondwheel.setLayoutParams(params2);
	    //secondwheel.setLabel("sec.");
	    secondsarray = this.getResources().getStringArray(R.array.sixty);
	    secondwheel.setViewAdapter(new ArrayWheelAdapter<String>(this,secondsarray));
	    secondwheel.setCurrentItem(0);
	    //secondwheel.setDEFVISIBLEITEMS(visibleitems);  // number of visible items in wheel
	    //secondwheel.setTEXTSIZE(textsize);  // font size
	    //secondwheel.setITEMOFFSET(itemoffset); //offset in pixels?
	    //secondwheel.setADDITIONALITEMHEIGHT(addItemHeight);
	    //secondwheel.setCenterBarHalfWidth(centerBarHalfWidth);
	    //secondwheel.setCenterBarOffsetPixels(centerBarHeightOffsetPix);
	    innerLayout2.addView(secondwheel);
	    mLinearLayout.addView(innerLayout2);
	
		// create ok/end button -> finish
		Button gettimes = new Button(this);
		gettimes.setText("Finished Setting Time & Name");
		mLinearLayout.addView(gettimes);
		// create listener
		gettimes.setOnClickListener(new View.OnClickListener() {
			// private long milliseconds;

			public void onClick(View v) {
				// get params
				getParamsAndGoToTimers();
			}
		});

		// add mLinearLayout to view
		setContentView(mLinearLayout);
	}
	
	public void getParamsAndGoToTimers() {
		// get params
		item = mytext.getText().toString();
		Integer hourposition = hourwheel.getCurrentItem();
		String hours = (String) hoursarray[hourposition];
		Integer minuteposition = minutewheel.getCurrentItem();
		String minutes = (String) minutesarray[minuteposition];
		Integer secondposition = secondwheel.getCurrentItem();
		String seconds = (String) secondsarray[secondposition];

		if (hours == null) {
			milliseconds = 0;
		} else {
			milliseconds = Long.parseLong(hours.trim()) * 60 * 60 * 1000;
		}
		if (minutes == null) {
			milliseconds = milliseconds + 0;
		} else {
			milliseconds = milliseconds
					+ Long.parseLong(minutes.trim()) * 60 * 1000;
		}
		if (minutes == null) {
			milliseconds = milliseconds + 0;
		} else {
			milliseconds = milliseconds
					+ Long.parseLong(seconds.trim()) * 1000;
		}

		goback2TimersDisplay();
	}
	
	@Override
	public void onBackPressed() {
		getParamsAndGoToTimers();
	}

	protected void goback2TimersDisplay() {
		Intent mIntent = new Intent();
		// mIntent.putExtras(bundle);
		if (item==null | item.length()==0) {
			item = "Timer"+String.valueOf(timerint);
		}
		mIntent.putExtra("item", item);
		mIntent.putExtra("milliseconds", milliseconds);
		mIntent.putExtra("position", position);
		mIntent.putExtra("timerint", timerint);
		setResult(RESULT_OK, mIntent);
		finish();
	}

	// fields
	String time_string;
	String item = null;
	long milliseconds;
	int position;
	private Spinner spinner_hours;
	private LinearLayout mLinearLayout;
	private Spinner spinner_minutes;
	private Spinner spinner_seconds;
	private EditText mytext;
	private int timerint;
	private WheelView hourwheel;
	private WheelView minutewheel;
	private WheelView secondwheel;
	private String[] hoursarray;
	private String[] minutesarray;
	private String[] secondsarray;
}
