package com.noblebug.chefpro.planner;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.RecipePreviewButtonInfo;
import com.noblebug.chefpro.recipe.Recipe;
import com.noblebug.chefpro.recipe.RecipeDisplay;
import com.noblebug.chefpro.search.ArrayWheelAdapter;
import com.noblebug.chefpro.search.OnWheelChangedListener;
import com.noblebug.chefpro.search.WheelView;
import com.noblebug.chefpro.tools.RecipeButtonAdapter;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class MealEditor extends Activity {
	
	private Context mCtx;
	private int viewwidth;
	private int viewheight;
	private LinearLayout mLinearLayout;
	private ArrayList<RecipePreviewButtonInfo> recipe_info;
	private RecipeButtonAdapter adapter_fileorresource;
	private WheelView dateWheel;
	private WheelView typeWheel;
	private int buttonheight;
	private float windowYfraction;
	private float windowXfractionNotChef;
	private int flagYsize;
	private int flagXsize;
	private int recipeid;
	private float rating;
	private BackEndSQLite mDbHelper;
	private String[] dates;
	private String[] datesRecipeNodeFormat;
	private String recipeinformationOld;
	private String[] types;
	private String recipeInformationNew;
	private int nodeid;
	private String recipeName;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
		{
			super.onCreate(savedInstanceState);
			// do some garbage collecting
			System.gc();
			
			// fix phone in POTRAIT (not landscape), and remove TITLE.
			this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			
			
			recipeinformationOld = getIntent().getStringExtra("recipeinformation");
			//System.out.println("**** Chef planner MealEditor recipeinformation ="+recipeinformationOld);
			// recipeinformation format:  node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
			
			// get more information:
			String currentDate = recipeinformationOld.split("%%%%")[4]; //YYYY-MM-DD
			String currentType = recipeinformationOld.split("%%%%")[3];
			recipeName = recipeinformationOld.split("%%%%")[2];
			recipeid = Integer.valueOf(recipeinformationOld.split("%%%%")[1]);
			nodeid = Integer.valueOf(recipeinformationOld.split("%%%%")[0]);
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			Recipe myRecipe = mDbHelper.getRecipeByID(recipeid);
			mDbHelper.close();
			rating = myRecipe.rating;
			String imageName = myRecipe.Imagehttp.split("/")[myRecipe.Imagehttp.split("/").length - 1];;

			// set Context for this MealEditor
			mCtx = this;
			
			// set types for typesWheel
			types = new String[4];
		    types[0] = "Breakfast";
		    types[1] = "Brunch";
		    types[2] = "Lunch";
		    types[3] = "Dinner";
		    int typeWheelCurrentPosition = 0 ;
		    if (recipeinformationOld.split("%%%%")[3].equalsIgnoreCase("breakfast")==true) {
		    	typeWheelCurrentPosition = 0;
		    }
		    if (recipeinformationOld.split("%%%%")[3].equalsIgnoreCase("brunch")==true) {
		    	typeWheelCurrentPosition = 1;
		    }
		    if (recipeinformationOld.split("%%%%")[3].equalsIgnoreCase("lunch")==true) {
		    	typeWheelCurrentPosition = 2;
		    }
		    if (recipeinformationOld.split("%%%%")[3].equalsIgnoreCase("dinner")==true) {
		    	typeWheelCurrentPosition = 3;
		    }
			
		    
			// need to get the month/days for this recipe
			final String[] weekdays = new String[]{"","Sun","Mon","Tue","Wed","Thr","Fri","Sat"};
			final String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
			final int[] daysOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
			int dd = Integer.valueOf(currentDate.split("-")[2]);
			int mm = Integer.valueOf(currentDate.split("-")[1]);
			int yy = Integer.valueOf(currentDate.split("-")[0]);
			System.out.println("****** Chef.MealEditor.onCreate  currentDate = "+currentDate+" "+dd+" "+mm+" "+yy);
			
			int sizeRoller = 20;
			
			// set center of calendar to half of size:
			GregorianCalendar cal = new GregorianCalendar(yy, mm-1, dd - sizeRoller/2);

			dates = new String[sizeRoller];  //"Wed, Aug 1";
			datesRecipeNodeFormat  = new String[sizeRoller];
			int dateWheelCurrentPosition = sizeRoller/2-1;
			for (int deltaDays=0 ; deltaDays<sizeRoller ; deltaDays++) {
				
				cal.add(Calendar.DAY_OF_MONTH, 1);  //offset calendar
				
				int currentWeekDayInt = cal.get(Calendar.DAY_OF_MONTH);
				String currentMonth = months[cal.get(Calendar.MONTH)];
				String weekday = weekdays[cal.get(Calendar.DAY_OF_WEEK)];
				
				dates[deltaDays] = weekday + "," +  currentMonth + " "+String.valueOf(currentWeekDayInt);
				
				// format datesRecipeNodeFormat  YYYY-MM-DD
				if (cal.get(Calendar.MONTH)+1<10) {
					// I think month starts at 1 for PHP to Chef
					datesRecipeNodeFormat[deltaDays] = cal.get(Calendar.YEAR)+"-0"+(cal.get(Calendar.MONTH)+1);
				} else {
					datesRecipeNodeFormat[deltaDays] = cal.get(Calendar.YEAR)+"-"+(cal.get(Calendar.MONTH)+1);
				}
				if (cal.get(Calendar.DAY_OF_MONTH) < 10){
					datesRecipeNodeFormat[deltaDays] = datesRecipeNodeFormat[deltaDays] + "-0" + (cal.get(Calendar.DAY_OF_MONTH));
				} else {
					datesRecipeNodeFormat[deltaDays] = datesRecipeNodeFormat[deltaDays] + "-" + (cal.get(Calendar.DAY_OF_MONTH));
				}
				
				//System.out.println("Chef.MealEditor onCreate weekday currentMonth currentWeekDayINt "+weekday+" "+currentMonth+" "+currentWeekDayInt);
				//System.out.println("Chef.MealEditor onCreate datesReciopeNodeFormat[deltaDays]  = "+datesRecipeNodeFormat[deltaDays]);
			}
			
			
			viewwidth = this.getWindowManager().getDefaultDisplay().getWidth();
			viewheight = this.getWindowManager().getDefaultDisplay().getHeight();
			
			// fixes phone in PORTRAIN, and no TITLE
			this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			
			// set up Layout
			mLinearLayout = new LinearLayout(this);
			mLinearLayout.setOrientation(LinearLayout.VERTICAL);
			mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
			mLinearLayout.setBackgroundResource(R.drawable.searchbackgroundpaper);
			
			// create inner layout for title, edittext, checkbox, search button
			LinearLayout innerLayout1 = new LinearLayout(this);
			innerLayout1.setOrientation(LinearLayout.VERTICAL);
			innerLayout1.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
			innerLayout1.setGravity(Gravity.CENTER);
			
			// make instance of searchtest, box, button. linked to Resources (R)
			// title:
			// add title
			Title myTitle = new Title(this,"Meal Editor",this.getWindowManager().getDefaultDisplay().getHeight());
			innerLayout1.addView(myTitle);
			
			// add padding after title before searchtest
			ImageView space = new ImageView(this);
			space.setImageResource(R.drawable.searchbackgroundpaper);
			int spaceheight = this.viewheight*2/100;
			int spacewidth = this.viewwidth;
			innerLayout1.addView(space,spacewidth,spaceheight);
			
			//this was the search button
			// add one recipe to list:
			buttonheight = this.getWindowManager().getDefaultDisplay().getHeight()/8;
			windowYfraction = (float) 0.80;
			flagYsize = (int) ((float)buttonheight *windowYfraction); //70/100;  ///2;
	    	flagXsize = (int)((float)this.getWindowManager().getDefaultDisplay().getWidth()*windowXfractionNotChef); //20/100; 
			recipe_info = new ArrayList<RecipePreviewButtonInfo>();
			RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this);
			// add image, default icon. NOT webpage. User has already downloaded image, or not for default icon	
			if (imageName!=null){
				myrecipe.setDrawableFileName(imageName);
				myrecipe.setType(RecipePreviewButtonInfo.FILEONDISK);
			} else {
				myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
				myrecipe.setResource(R.drawable.defaultrecipeimage);
			}
			myrecipe.setButtonText(recipeName);
			myrecipe.setXY(viewwidth, this.buttonheight);
			myrecipe.setXYFrame(this.flagXsize,this.flagYsize);
			myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
			myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
			myrecipe.addID(recipeid);
			myrecipe.addRating(rating);
			recipe_info.add(myrecipe);
			final ListView myListView = new ListView(this);
			myListView.setCacheColorHint(Color.TRANSPARENT);
			myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.FILL_PARENT));
			this.adapter_fileorresource = new RecipeButtonAdapter(this, R.layout.rowfileresource, recipe_info);
			myListView.setAdapter(this.adapter_fileorresource);
			// give adapter to layoutmanager
			innerLayout1.addView(myListView);			
			mLinearLayout.addView(innerLayout1);
			
			//// add click listener so user can view and/or delete this meal:
			//myListView.setDividerHeight(0);
	        myListView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
					// check if item is breakpoint, ignore click if breakpoint
					if (((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getType()==RecipePreviewButtonInfo.BREAK){
						// do nothing
					} else {
						int recipeid = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getID();
						callRecipeDisplay(recipeid);
					}
				}
			});
			
			
			//// add more padding after title before searchtest
			//space.setImageResource(R.drawable.searchbackgroundpaper);
			//innerLayout1.addView(space,spacewidth,spaceheight);
			
			// add a save button
			Button saveButton = new Button(this);
			saveButton.setText("save");
			saveButton.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					//Integer datePosition = dateWheel.getCurrentItem();
					//Integer typePosition = typeWheel.getCurrentItem();
					saveGoToPlanner();  //datePosition,typePosition);
				}
			});
			mLinearLayout.addView(saveButton);
						
			
			// create innerLayout2
			LinearLayout innerLayout2 = new LinearLayout(this);
			innerLayout2.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
			innerLayout2.setOrientation(LinearLayout.HORIZONTAL);
			innerLayout2.setGravity(Gravity.CENTER_HORIZONTAL);
			int backgroundleft = this.viewwidth * 1/100;
			int backgroundtop = this.viewheight * 5/100;
			int backgroundright = this.viewwidth * 1/100;
			int backgroundbottom = this.viewheight * 5/100;
			innerLayout2.setPadding(backgroundleft, backgroundtop, backgroundright, backgroundbottom);
			try {
				innerLayout2.setBackgroundResource(R.drawable.searchbackgroundspinner);
			} catch(OutOfMemoryError e) {
				innerLayout2.setBackgroundColor(Color.rgb(218, 227, 234));
			}
			
			// add Wheels
			dateWheel = new WheelView(this);
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.FILL_PARENT, 1);
			dateWheel.setLayoutParams(params);
			//dates = new String[5];
			//dates[0] = "Wed, Aug 1";
			//dates[1] = "Thu, Aug 2";
			//dates[2] = "Fri, Aug 3";
			//dates[3] = "Sat, Aug 4";
			//dates[4] = "Sun, Aug 5";
			dateWheel.setViewAdapter(new ArrayWheelAdapter<String>(this,dates));
			dateWheel.setCurrentItem(dateWheelCurrentPosition);
			//if (currentDate!=null) {
			//	// do something
			//} else {
			//	dateWheel.setCurrentItem(dateWheelCurrentPosition);
			//}
		    innerLayout2.addView(dateWheel);
		    
		    typeWheel  = new WheelView(this);
		    typeWheel.setLayoutParams(params);
			typeWheel.setViewAdapter(new ArrayWheelAdapter<String>(this,types));
			typeWheel.setCurrentItem(typeWheelCurrentPosition);
			//if (currentType!=null) {
			//	// do something
			//} else {
			//	typeWheel.setCurrentItem(0);
			//}
		    // add listeners
		    addChangingListener(dateWheel, "dates");
		    addChangingListener(typeWheel, "types");
		    //OnWheelChangedListener wheelListener = new OnWheelChangedListener() {
			//	public void onChanged(WheelView wheel, int oldValue, int newValue) {
			//		// wtf is this doing?
			//		//wheelChanged = true;
			//		//wheelChanged = false;
			//		System.out.println("***** MealEditor  oldValue="+oldValue+" newValue="+newValue);
			//		wheel.setCurrentItem(newValue);
			//	}
			//};
			innerLayout2.addView(typeWheel);			
			//dateWheel.addChangingListener(wheelListener);
			//typeWheel.addChangingListener(wheelListener);
			
			
			mLinearLayout.addView(innerLayout2);
			
			this.setContentView(mLinearLayout);
		}
	
	
	public void callRecipeDisplay(Integer recipeid) {
		setNewRecipeInformation();
		Intent i = new Intent(this, RecipeDisplay.class);
		i.putExtra("RecipeId2View", recipeid);
		i.putExtra("RecipeInformation", this.recipeInformationNew);
		startActivity(i);
	}
	
	private void addChangingListener(final WheelView wheel, final String label) {
		wheel.addChangingListener(new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				//wheel.setLabel(newValue != 1 ? label : label);
			}
		});
	}
	
	private void setNewRecipeInformation() {
		// format:   node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
		// If the wheels are in the original positions then recipeOLD=recipeNEW, but no need to really check.... I think.
		String type = types[typeWheel.getCurrentItem()];
		String YYYYMMDD = datesRecipeNodeFormat[dateWheel.getCurrentItem()];
		this.recipeInformationNew = recipeinformationOld.split("%%%%")[0]+"%%%%"+recipeinformationOld.split("%%%%")[1]+"%%%%"+recipeinformationOld.split("%%%%")[2];
		this.recipeInformationNew = this.recipeInformationNew + "%%%%"+type+"%%%%"+YYYYMMDD;
	}
	
	private void saveGoToPlanner() {
		//recreate this meal
		// recipeinformation format:  node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
		setNewRecipeInformation();
		//System.out.println("**** MealEditor.saveGoToPlanner  this.recipeInformationNew = "+this.recipeInformationNew);
		
		//int nodeid = Integer.valueOf(recipeinformationOld.split("%%%%")[0]);
		//int recipeid = Integer.valueOf(recipeinformationOld.split("%%%%")[1]);
		
		// save the settings persistent with db
		mDbHelper = new BackEndSQLite(this.mCtx);
		mDbHelper.open();
		int userid = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
		String username = mDbHelper.getUserSingle()[BackEndSQLite.out_int_username];
		String passwordmd5 = mDbHelper.getUserSingle()[BackEndSQLite.out_int_md5hashpass];
		if (nodeid==-1) {
			// new
			mDbHelper.manageMeals(this.recipeInformationNew, userid , "new");
		} else {
			mDbHelper.manageMeals(this.recipeInformationNew, userid , "update");
		}
		mDbHelper.close();
		
		// send to php
		BackEndPHPHandler myPHP = new BackEndPHPHandler();
		myPHP.deleteRecipeFromCalendar(userid, passwordmd5, nodeid);
		// in this case we are creating a new meal so pass nodeid=-1.
		myPHP.addRecipe2Calendar(userid, passwordmd5, -1, recipeid, types[typeWheel.getCurrentItem()], datesRecipeNodeFormat[dateWheel.getCurrentItem()], username);
		
		// go to meal planner
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}

	
    private class Title extends LinearLayout {
    	// displays "Recipe Bar" and title "Sour Cream Biscuits"
		Context innercontext;
		LinearLayout innerlayout;

		public Title(Context innercontext, String title, Integer screenHeight) {
			super(innercontext);
			innerlayout = new LinearLayout(innercontext);
			innerlayout.setOrientation(LinearLayout.VERTICAL);
			// add bar:
			ImageView recipeBarTitle = new ImageView(innercontext);
			recipeBarTitle.setImageResource(R.drawable.blanktitle);
			//set padding as a scale relative to the screenheight
			int padding = -1 * screenHeight * 7 / 100;
			recipeBarTitle.setPadding(0, padding, 0, padding);
			innerlayout.addView(recipeBarTitle);
			
			// set text
			TextView myTitle = new TextView(innercontext);
			myTitle.setText(title);
			myTitle.setGravity(Gravity.CENTER);
			myTitle.setTypeface(Typeface.SERIF);
			myTitle.setTextColor(Color.rgb(66, 41, 10));
			myTitle.setTextSize(30);
			innerlayout.addView(myTitle);
			
			addView(innerlayout);
		}
    }
    
}
