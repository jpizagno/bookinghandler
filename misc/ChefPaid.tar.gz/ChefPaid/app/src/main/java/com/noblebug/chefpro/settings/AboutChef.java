package com.noblebug.chefpro.settings;

import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AboutChef extends Activity {
	// this class displays about Chef, and a link to the webpage.
	// 4 June 2011 Jim Pizagno

	private float screen_width;
	private float screen_height;
	private Context Ctx;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// fix phone to PORTRAIT, and no TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		Ctx = this;
		
		Display display = getWindowManager().getDefaultDisplay();
		screen_width = (float) display.getWidth();
		screen_height = (float) display.getHeight();
		
		// Create a LinearLayout in which to add the ImageView
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setGravity(Gravity.CENTER);

		TextView textTitle = new TextView(this);
		textTitle.setText("Welcome to Chef");
		float size = screen_height*5/100;;
		textTitle.setTextSize(size);
		textTitle.setTextColor(Color.BLACK);
		textTitle.setGravity(Gravity.CENTER);
		mLinearLayout.addView(textTitle);
		
		TextView textVersion = new TextView(this);
		String app_ver = "0";
		try {
			app_ver = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (app_ver.equalsIgnoreCase("0")==false) {
			textVersion.setText("Version "+app_ver);
		}
		float size2 = screen_height*4/100;;
		textTitle.setTextSize(size2);
		textVersion.setTextColor(Color.BLACK);
		textVersion.setGravity(Gravity.CENTER);
		mLinearLayout.addView(textVersion);
		
		TextView t3 = new TextView(this);
		t3.setText(
		        Html.fromHtml(
		            "More Information at: " +
		            "<a href=\"http://www.chefslittlehelper.com\">www.chefslittlehelper.com</a> "));
		t3.setMovementMethod(LinkMovementMethod.getInstance());
		mLinearLayout.addView(t3);
		
	
		String text3 = "From your recipes to your grocery list, we are always "
			+ "striving to make it easy for you to find that great new recipe "
			+ "and help you make in any way we can. If you have any "
			+ "suggestions or comments, please feel free to contact us at "
			+ "chefslittlehelper@gmail.com, "
			+ "or visit us on the. We look forward to hearing from you soon";
		Button myButton1 = new Button(this);
		myButton1.setText(text3);
		mLinearLayout.addView(myButton1);

		TextView legalText = new TextView(this);
		legalText.setText("Legal");
		legalText.setTextSize(18);
		legalText.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(legalText);
		

		String text4 = "We do not own or claim the copyright or responsibility for "
			+ "the material posted on Chef by its users. Any text, or images posted "
			+ "are the complete responsibility of the user who has uploaded the "
			+ "content. Users are responsible for ensuring their uploaded content "
			+ "does not infringe on any copyright violations. User uploaded "
			+ "content must be copyrighted to the user performing the upload "
			+ "or under the permission of the original copyright owner. This "
			+ "includes any videos, slogans, text, music, images, or any other "
			+ "uploaded content.";
		Button myButton2 = new Button(this);
		myButton2.setText(text4);
		mLinearLayout.addView(myButton2);

		String text5 = "When you post user content to Chef, you authorize and "
			+ "direct us to make such copies thereof as we deem necessary in "
			+ "order to facilitate the posting and storage of the user content. By "
			+ "posting user content to Chef, you automatically grant, and you "
			+ "represent and warrant that you have the right to grant, to the "
			+ "company an irrevocable, perpetual, non-exclusive, transferable, "
			+ "fully paid, worldwide license to use, copy, publicly perform, "
			+ "publicly display, reformat, translate, excerpt (in whole or in "
			+ "part) and distribute such User content for any purpose, commercial, "
			+ "advertising, or otherwise, on or in connection with Chef or the "
			+ "promotion thereof, to prepare derivative works of, or incorporate "
			+ "into other works with proper attribution to you the original author. "
			+ "You may remove your user content from Chef at any time. If you choose "
			+ "to remove your user content, the license granted above will "
			+ "automatically expire, however you acknowledge that Chef may retain "
			+ "archived copies of your user content.";
		Button myButton3 = new Button(this);
		myButton3.setText(text5);
		mLinearLayout.addView(myButton3);

		String text6 = "Chef is not responsible for errors in recipes or cooking and "
			+ "baking tips, misleading content including photos of recipes, and "
			+ "shall not be held responsible for sickness, food allergies or death "
			+ "if recipe is made and consumed by users. Chef is not responsible for "
			+ "any tips or advice given on the site and other Chef Sevices by either "
			+ "another user or Chef. Chef does not check for accuracy on recipes, "
			+ "forum posts, cooking, baking tips or newsletter information. If the "
			+ "content submitted by a user or Chef is inaccurate Chef cannot be held "
			+ "liable for damages.";
		Button myButton4 = new Button(this);
		myButton4.setText(text6);
		mLinearLayout.addView(myButton4);

		
		ScrollView scroller = new ScrollView(this);
		scroller.setBackgroundResource(R.drawable.tanbackground);
		scroller.addView(mLinearLayout);
		setContentView(scroller);
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "").setIcon(home);
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Settings_ID:
			this.gotoSettings();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void gotoSettings() {
		Intent i = new Intent(this, SettingsDisplay.class);
		startActivity(i);
	}

	private void createTimers() {
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	private void gotoChef() {
		Intent i = new Intent(this, Home.class);
		setResult(RESULT_OK, i);
		finish();
	}

	// create fields
	private static final int Cookbook_ID = 0;
	private static final int Grocerylist_ID = 1;
	private static final int Search_ID = 2;
	private static final int Timers_ID = 3;
	private static final int Settings_ID = 4;
	private   final int Chef_ID = 5;
	private LinearLayout mLinearLayout;
}
