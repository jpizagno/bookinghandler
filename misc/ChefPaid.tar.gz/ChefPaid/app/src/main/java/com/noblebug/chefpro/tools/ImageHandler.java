package com.noblebug.chefpro.tools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.drawable.Drawable;

public class ImageHandler {
	//
	 // This class handles images that are put in /data/data/com.noblebug.chefpro/
	 //
	public void deleteimage(String imagename) {
		// String
		// filepath=Environment.getExternalStorageDirectory().getAbsolutePath();
		String filepath = "/data/data/com.noblebug.chefpro/";
		File file = new File(filepath + "/" + imagename);
		// File file = new File(imagename);
		file.delete();
	}

	public Drawable getimageDrawable(String imagename) {
		// gets an image, returning Drawable
		String filepath = "/data/data/com.noblebug.chefpro/";
		Drawable myDrawable = Drawable.createFromPath(filepath+ "/" + imagename);
		return myDrawable;
	}
	
	public Bitmap getimage(String imagename) {
		// gets an image, returns a Bitmap.  hopefully this is not used, as Bitmaps suck
		String filepath = "/data/data/com.noblebug.chefpro/";
		Bitmap myBitmap = BitmapFactory.decodeFile(filepath + "/" + imagename);
		return myBitmap;
	}
	
	public String downloadChefImage(Integer recipehere_user) {
		// downloads an images of a chef, and stores it at /data/data/com.noblebug.chef/
		String answer;  // return NOT downloaded: answer="None" , downloaded:  answer="picture-9085.png"
		String url = "http://www.chefslittlehelper.com/API/android/1.0.0/picturesearch.php?uids=???";
		url=url.replace("???", String.valueOf(recipehere_user));
		// check to see if this image exists:
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		String result = "None";
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			result = stream2text.GetText(response);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		//
		//NOTE trying result.equals("None") does NOT seem to work.
		// 		instead, try for result.split("/").size()>1
		//              b/c: size=5 for "9058:sites/default/files/pictures/picture-9058.png"
		//
		if (result.split("/").length<2) {
			// has NO image for this chef
			answer = "None";
		} else {
			// has an image for this chef
			// result format example:  9058:sites/default/files/pictures/picture-9058.png
			String urlString = "http://www.chefslittlehelper.com/sites/default/files/pictures/???";
			String[] temp = result.split("/");
			urlString = urlString.replace("???", String.valueOf(temp[temp.length-1]));
			String imagename3 = downloadFile(urlString);
			answer = imagename3;
		}
		// return 0=downloaded 1=notdownloaded
		return answer;
	}

	public String downloadFile(String fileUrl) {

		fileUrl = fileUrl.replace(" ", "%20");

		String[] temp = fileUrl.split("/");
		this.imagename = temp[temp.length - 1];
		URL myFileUrl = null;
		try {
			myFileUrl = new URL(fileUrl);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		try {
			HttpURLConnection conn = (HttpURLConnection) myFileUrl
					.openConnection();
			conn.setDoInput(true);
			conn.connect();
			int length = conn.getContentLength();

			InputStream is = conn.getInputStream();


			bmImg = BitmapFactory.decodeStream(is);
			// this.imView.setImageBitmap(bmImg);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			// String
			// filepath=Environment.getExternalStorageDirectory().getAbsolutePath();

			String filepath = "/data/data/com.noblebug.chefpro/";
			FileOutputStream fos = new FileOutputStream(filepath + "/"
					+ imagename);
			
			bmImg.compress(CompressFormat.JPEG, 75, fos);
			fos.flush();
			fos.close();
		} catch (Exception e) {
			// Log.e("MyLog", e.toString());;
			System.out.println(e.toString());
		}
		return imagename;
	}

	// fields
	private Bitmap bmImg;
	public String imagename;

}
