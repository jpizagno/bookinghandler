package com.noblebug.chefpro.search;

import java.util.ArrayList;
import java.util.List;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.cookbook.RecipePreviewButtonInfo;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.recipe.Recipe;
import com.noblebug.chefpro.recipe.RecipeDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.RecipeButtonAdapter;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout.LayoutParams;

public class SearchResultsDisplay extends Activity {
	// This class displays the search results.  It could be made better by moving the 
	// recipe preview to general tools activity. It is displaying mostly webviews.
	// 4 June 2011 Jim Pizagno
	
	
	private int buttonheight;
	private float windowYfraction;
	private float windowXfractionNotChef;
	//private Bitmap WindowFrame;
	private int windowXposition;
	private int windowYposition;
	private int width;
	private int flagYsize;
	private int flagXsize;
	private int textX;
	private int textY;
	private BackEndSQLite mDbHelper;
	private String RecipeOrder;
	private int recipesLoaded;
	private ScrollView scroller;
	private int webviewScalePerc;
	private ArrayList<RecipePreviewButtonInfo> recipe_info;
	private RecipeButtonAdapter adapter_fileorresource;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// This will force AsyncTask to be initialized in the main thread.   Allows Toast messages
		try {
			Class.forName("android.os.AsyncTask");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// fix phone in PORTRAIT , and no TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// get userid
		userid = getIntent().getIntExtra("userid", 4);

		// get result of PHP search:
		SearchResultsString = getIntent().getStringExtra("searchresults");

	
		// call method to fill RecipeMap
		parseResults2Recipes(SearchResultsString);

		// make and define the clear windowframe
    	buttonheight = this.getWindowManager().getDefaultDisplay().getHeight()/8;
    	width = this.getWindowManager().getDefaultDisplay().getWidth();
    	windowYfraction = (float) 0.80;
    	windowXfractionNotChef = (float) 0.25;
    	// flag and window size:
    	flagYsize = (int) ((float)buttonheight *windowYfraction); //70/100;  ///2;
    	flagXsize = (int)((float)this.getWindowManager().getDefaultDisplay().getWidth()*windowXfractionNotChef); //20/100; 
		// window position:
		windowXposition = flagXsize*1/6;
    	windowYposition = buttonheight*1/10;
    	// text position:
    	textX = this.getWindowManager().getDefaultDisplay().getWidth()*30/100;  // *2/5;*2/5;
		textY = buttonheight*55/100;
		//float temp = (float) ((30.0/854.0) * (float) this.getWindowManager().getDefaultDisplay().getHeight());
		//if (temp>100) {
		//	webviewScalePerc = (int) 100;  //must be between 0-100. percentage
		//} else {
		//	webviewScalePerc = (int) temp;  //must be between 0-100. percentage
		//}
		webviewScalePerc =100;
		
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setBackgroundResource(R.drawable.cookbookbackground);
		
		// add title
		LinearLayout innerLayout = new LinearLayout(this);
		innerLayout.setGravity(Gravity.CENTER);
		innerLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.WRAP_CONTENT));
		TextView title = new TextView(this);
		title.setText("Search Results");
		title.setTextColor(Color.WHITE);
		title.setBackgroundResource(R.drawable.blanktitle);
		title.setGravity(Gravity.CENTER);
		Typeface myType = Typeface.create(Typeface.SERIF, Typeface.NORMAL);
		title.setTypeface(myType);
		if (this.getWindowManager().getDefaultDisplay().getHeight() > 600) {  
			// this If()else statement accounts for devices with different sizes
			title.setTextSize(36);
		} else {
			title.setTextSize(18);
		}
		innerLayout.addView(title, this.getWindowManager().getDefaultDisplay().getWidth(), 
				this.getWindowManager().getDefaultDisplay().getHeight()*10/100);
		mLinearLayout.addView(innerLayout);
		
		
		recipe_info = new ArrayList<RecipePreviewButtonInfo>(); // collection of recipes
		for (int i=0;i<RecipesList.size();i++) {
			Recipe temprecipe = RecipesList.get(i);
			if (temprecipe.Imagehttp==null) {
				// then use resource
			    RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this);
			    myrecipe.addRating(temprecipe.rating);
			    myrecipe.setType(RecipePreviewButtonInfo.DEFAULT);
				myrecipe.setResource(R.drawable.defaultrecipeimage);
				myrecipe.addID(temprecipe.recipeid);
				myrecipe.setButtonText(temprecipe.recipename);
				myrecipe.setXYFrame(this.flagXsize, this.flagYsize);
				myrecipe.setXY(this.getWindowManager().getDefaultDisplay().getWidth(), this.buttonheight);
				myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
				myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
				recipe_info.add(myrecipe);
			} else {
				RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this);
				myrecipe.addRating(temprecipe.rating);
				myrecipe.setType(RecipePreviewButtonInfo.WEBVIEW);
				myrecipe.addID(temprecipe.recipeid);
				myrecipe.setButtonText(temprecipe.recipename);
				//String url = "<img src=\""+temprecipe.Imagehttp+"\" width=\"100%\" height=\"100%\" >";
				String url =" <img src=\""+temprecipe.Imagehttp
				        +"\" width=\""+String.valueOf(this.flagXsize)+"\" height=\""
				        +String.valueOf(this.flagYsize)+"\" >";
				myrecipe.setWebViewAddress(url, this.webviewScalePerc);
				// set this button's physical dimensions
				myrecipe.setXY(this.width, this.buttonheight);
				myrecipe.setXYFrame(this.flagXsize, this.flagYsize);
				myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
				myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
				recipe_info.add(myrecipe);
			}
		}
		// give collection to instance of adapter
		final ListView myListView = new ListView(this);
		myListView.setCacheColorHint(Color.TRANSPARENT);
		myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		this.adapter_fileorresource = new RecipeButtonAdapter(this, R.layout.rowwebview, recipe_info);
		myListView.setAdapter(this.adapter_fileorresource);
		mLinearLayout.addView(myListView);
		
	    // make clickable
	    myListView.setClickable(true);
        myListView.setFocusable(true);
        myListView.setDividerHeight(0);
        myListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
            	int recipeid = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getID();
            	String stringFields = "RecipeNAME";
            	BackEndPHPHandler myPHP = new BackEndPHPHandler();
            	try {
					// get full recipe information from BackEndPHPHandler
					myPHP.fetchStringRecipe(recipeid, userid);
					stringFields = myPHP.RecipeString;
					if (stringFields != null) {
						callRecipeDisplay(stringFields);
					} else {
						System.out.println("SearchResultsDiaplay::onCreate stringFields==null");
					}
            	} catch (Exception e) {
            		Toast.makeText(getApplicationContext(), "Could not download recipeid = " + String.valueOf(recipeid)+" stringFields = "+stringFields, Toast.LENGTH_LONG).show();
            		String comment = "::from SearchResultsDisplay.onCreate could not dowload recipeid:: "+recipeid+" ::contentsStringRecipe:"+myPHP.contentsStringRecipe;
            		String priority = "WARNING";
            		myPHP.exceptionlog(userid,comment,priority);
            	}
			}
		});
        setContentView(mLinearLayout);
	}


    public String setManySpaces2OneSpace(String input){
    	// this method is used to remove too many white spaces in a string.
    	// if upper2LowerCase has too many white spaces, then the code bombs
    	input.trim();
    	String temp5 = input.replace("     "," ");
    	String temp4 = temp5.replace("    "," ");
    	String temp3 = temp4.replace("   "," ");
    	String outstring = temp3.replace("  "," ");
    	return outstring;
    }
    
    public String upper2LowerCase(String input){
    	// this method convert the string to First letter upper case, other letteers lowercase.
    	// it allows a more even scaling of the words in elideText
    	String outString = "";
    	input = setManySpaces2OneSpace(input);
    	String[] words = input.split(" ");
    	for (int i=0;i<words.length;i++) {
    		String firstLetter = words[i].substring(0,1);  // Get first letter
    		String remainder   = words[i].substring(1); 
    		String capitalized = firstLetter.toUpperCase() + remainder.toLowerCase();
    		outString = outString +" "+capitalized;
    	}
    	return outString;
    }
    
	public String elideText(String texttmp, Integer screenwidth){
		String text = upper2LowerCase(texttmp);
		String elidedtext;
		int length = (int)(-0.0125* (float)screenwidth) + 26; 
		if (length>text.length()){
			elidedtext = text;
		} else {
			elidedtext = text.substring(0, length) + "...";
		}
		return elidedtext;
	}
	

	protected void callRecipeDisplay(String stringFields) {
		// send this string to the RecipeDisplay
		Intent i = new Intent(this, RecipeDisplay.class);
		i.putExtra("RecipeStringFields", stringFields);
		startActivityForResult(i, 0);
	}

	public void parseResults2Recipes(String result) {
		String[] resultarray = result.replace("^^", "%%%").split("%%%");
		// System.arraycopy(result.split("^^"), 0, resultarray, 0, numrecipes);
		for (int i = 0; i < resultarray.length; i++) {
			try {
				Recipe temprecipe = new Recipe();
				String[] temp = resultarray[i].split("::");
				temprecipe.recipename = temp[0];  //name
				temprecipe.recipeid = Integer.parseInt(temp[1].trim().replace(":", ""));  //recipeid
				if (Float.valueOf(temp[2].trim()).floatValue() < (float) 0.0) {
					temprecipe.rating = (float) 0.0;        //rating
				} else {
					temprecipe.rating = Float.valueOf(temp[2].trim()).floatValue()
							/ ((float) 100.0) * (float) 5.0;   //rating 
				}
				if (temp.length == 4) { // have image
					if (temp[3].length() > 1) {
						temprecipe.Imagehttp = temp[3];
					} else {
						temprecipe.Imagehttp = null;
					}
				} else {
					temprecipe.Imagehttp = null;
				}
				RecipesList.add(temprecipe);
			} catch (Exception e) {
				// send this recipe to the webpage, as it is bombing a lot:
				// exceptionlog(int userid, String comment, String priority)
				BackEndPHPHandler myPHP = new BackEndPHPHandler();
				String comment = "::from SearchResultsDisplay.parseResults2Recipes could not parse result = "+result;
	    		String priority = "WARNING";
	    		myPHP.exceptionlog(userid,comment,priority);
			}
		}
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "").setIcon(home);
		menu.add(0, Contact_ID, 0, "Contact Us");
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Contact_ID:
			contact_us();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void gotoChef() {
		Intent i = new Intent(this, Home.class);
		setResult(RESULT_OK, i);
		finish();
	}
	
	private void contact_us() {
		// email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
		// users to provide feedback.
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity RecipeDisplay");
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
		}
	}

	private void createTimers() {
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	// on stop clear RecipeMap
	@Override
	protected void onStop() {
		super.onStop();
		RecipesList.clear();
		SearchResultsString = null;
	}

	// create fields
	private static final int Cookbook_ID = 0;
	private static final int Grocerylist_ID = 1;
	private static final int Search_ID = 2;
	private static final int Timers_ID = 3;
	private static final int Chef_ID = 4;
	private static final int Contact_ID = 11;
	List<Recipe> RecipesList = new ArrayList<Recipe>();
	public String SearchResultsString = null;
	Integer userid = null;
	private LinearLayout mLinearLayout;
}
