package com.noblebug.chefpro.tools;

import java.util.ArrayList;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.cookbook.RecipePreviewButtonInfo;
import com.noblebug.chefpro.search.FramedDefault;
import com.noblebug.chefpro.search.FramedWebView;

public class RecipeButtonAdapter extends ArrayAdapter<RecipePreviewButtonInfo> {
	// class that is an adapter for the RecipePreview button. 
	// it needs the collection of RecipePreviewButtonInfo.
	// on getView() it finds out what object was clicked, and then inflates the
	// appropriate method.
	// 4June2011 JimPizagno
	
    private ArrayList<RecipePreviewButtonInfo> items;
	private Context Ctx;

    public RecipeButtonAdapter(Context context, int textViewResourceId, ArrayList<RecipePreviewButtonInfo> items) {
            super(context, textViewResourceId, items);
            this.Ctx = context;
            this.items = items;
    }
    
    @Override 
    public boolean isEnabled(int position) { 
    	// this method prevents the Break points/buttons in Listview from turning green/yellow when clicked.
    	RecipePreviewButtonInfo o = items.get(position);
    	if (o.getType()==o.BREAK) {
    		return false; 
    	} else { 
    		return true; 
    	} 
    } 

    
    public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            RecipePreviewButtonInfo o = items.get(position);
            if (o != null) {
            	// figure out what this object is, and then inflate the proper XML file
            	    if (o.getType()==o.BREAK) {
            	    	// This is a separator, and always part of cookbook
            	    	LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            	    	v = vi.inflate(R.layout.rowbreakpoint, null);
            	    	TextView tt = (TextView) v.findViewById(R.id.breaktext);
            	    	tt.setTextColor(Color.rgb(66, 41, 10));
            	    	System.out.println("******* RecipeButtonAdapter::getView tt="+tt);
            	    	tt.setText(o.getBreakText());
            	    	v.setClickable(false);  // do not allow user to click on a break'
            	    	v.setFocusable(false);
            	    	v.setBackgroundColor(Color.TRANSPARENT);
            	    }
            		if (o.getType()==o.RESOURCE) {
                        LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        if (o.partofCookbook) {
                        	v = vi.inflate(R.layout.rowcookbook, null);
                        } else {
                        	v = vi.inflate(R.layout.rowfileresource, null);
                        	StarView myStarviewtmp = new StarView(o.Ctx, o.getRating(), Color.TRANSPARENT, o.getX());
		                    LinearLayout myinner = (LinearLayout) v.findViewById(R.id.innerlayout);
		                    myinner.addView(myStarviewtmp);    
                        }
            			TextView tt = (TextView) v.findViewById(R.id.toptext);
    	                if (tt != null) {
    	                      tt.setText(o.getButtonText());             
    	                      tt.setTextColor(Color.rgb(66, 41, 10));
    	                }
	                    ImageView myIcon = (ImageView) v.findViewById(R.id.icon);
    	                
	                    if (myIcon!=null) {
	                    	myIcon.setBackgroundDrawable(o.getResource());
	                    } 
            		}
            		if (o.getType()==o.FILEONDISK) {
                        LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        if (o.partofCookbook) {
                        	v = vi.inflate(R.layout.rowcookbook, null);
                        } else {
                        	v = vi.inflate(R.layout.rowfileresource, null);
                        }
            			TextView tt = (TextView) v.findViewById(R.id.toptext);
    	                if (tt != null) {
    	                      tt.setText(o.getButtonText());  
    	                      tt.setTextColor(Color.rgb(66, 41, 10));
    	                }
	                    ImageView myIcon = (ImageView) v.findViewById(R.id.icon);
	                   
	                    if (myIcon!=null) {
	                    	myIcon.setBackgroundDrawable(o.getDrawableFile());
	                    } 
	                    if (o.partofCookbook==false) {
		                    StarView myStarviewtmp = new StarView(o.Ctx, o.getRating(), Color.TRANSPARENT, o.getX());
		                    LinearLayout myinner = (LinearLayout) v.findViewById(R.id.innerlayout);
		                    myinner.addView(myStarviewtmp);          
                        }
            		}
            		if (o.getType()==o.DEFAULT){
            			LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        v = vi.inflate(R.layout.rowdefaultrecipe, null);
            			TextView tt = (TextView) v.findViewById(R.id.toptext);
    	                if (tt != null) {
    	                      tt.setText(o.getButtonText());  
    	                      tt.setTextColor(Color.rgb(66, 41, 10));
    	                }
            			FramedDefault myDefault = (FramedDefault) v.findViewById(R.id.frameddefault);
            			myDefault.FrameSizeX = o.getFrameX();
            			myDefault.FrameSizeY = o.getFrameY();
            			StarView myStarviewtmp = new StarView(o.Ctx, o.getRating(), Color.TRANSPARENT, o.getX());
	                    LinearLayout myinner = (LinearLayout) v.findViewById(R.id.innerlayout2);
	                    myinner.addView(myStarviewtmp);   
            		}
            		if (o.getType()==o.WEBVIEW) {
            			LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        v = vi.inflate(R.layout.rowwebview, null);
            			TextView tt = (TextView) v.findViewById(R.id.toptext);
    	                if (tt != null) {
    	                      tt.setText(o.getButtonText());  
    	                      tt.setTextColor(Color.rgb(66, 41, 10));
    	                }
            			FramedWebView myWeb = (FramedWebView) v.findViewById(R.id.framedwebview);
            			if (myWeb==null){
            				System.out.println("**** OrderAdapter myWeb null");
            			}
            			myWeb.FrameSizeX = o.getFrameX();
            			myWeb.FrameSizeY = o.getFrameY();
            			myWeb.setWebViewStuff(o.getwebviewScalePerc());
            			//myWeb.loadUrl(o.getWebViewAddress());
            			//
        				myWeb.loadData(o.getWebViewAddress(), "image/jpeg", "utf-8");
        				StarView myStarviewtmp = new StarView(o.Ctx, o.getRating(), Color.TRANSPARENT, o.getX());
	                    LinearLayout myinner = (LinearLayout) v.findViewById(R.id.innerlayout2);
	                    myinner.addView(myStarviewtmp);   
            		} 
            }
            LinearLayout myLayout = new LinearLayout(getContext());
            myLayout.addView(v,o.getX(),o.getY());
            if (o.getType()==o.BREAK) {
            	myLayout.setClickable(false);
            	myLayout.setFocusable(false);
            	myLayout.setBackgroundColor(Color.TRANSPARENT);
            }
            return myLayout;
            //return v;
    }
}
