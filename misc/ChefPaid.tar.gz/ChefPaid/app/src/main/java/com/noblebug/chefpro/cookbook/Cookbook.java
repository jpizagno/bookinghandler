package com.noblebug.chefpro.cookbook;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import android.content.Context;
import android.database.Cursor;
import com.noblebug.chefpro.SQLite.BackEndSQLite;

public class Cookbook {
	//
	 // The cookbok object. It creates the list of chefs,categories,cuisines.
	 // it needs a context from an Activity upon instantiation because it opens the database.
	 // 12May2011 Jim
	 //
	
	// constructor gets context from Activity, so it can open database
	public Cookbook(Context context) {
		this.mContext = context;
	}

	public Map<String, String> getChefs(){
		return ChefNameUid;
	}
	
	public Set<String> getCuisinesSet() {
		return myCuisinesSet;
	}
	
	public Set<String> getCategorySet() {
		return myCategorySet;
	}
	
	public void setupValues() {
		// creates myCategorySet,myCuisineSet,myChefsSet
		
		// open database
		mDbHelper = new BackEndSQLite(this.mContext);
		mDbHelper.open();

		// get categories for myCategorySet in cookbook
		myCategorySetunOrdered.clear();
		Cursor cursorCategories = mDbHelper.getCategories();
		for (int i=0;i<cursorCategories.getCount();i++){
			cursorCategories.moveToPosition(i);
			String category = cursorCategories.getString(
					cursorCategories.getColumnIndexOrThrow(BackEndSQLite.KEY_CATEGORY));
			myCategorySetunOrdered.add(category);
		}
		cursorCategories.close();
		myCategorySet = new TreeSet(myCategorySetunOrdered);
		
		// get all cuisines in cookbook, put in myCuisineslist
		myCuisinesSetunOrdered.clear();
		Cursor cursorCuisines = mDbHelper.getCuisines();
		for (int i=0;i<cursorCuisines.getCount();i++){
			cursorCuisines.moveToPosition(i);
			String cuisine = cursorCuisines.getString(
					cursorCuisines.getColumnIndexOrThrow(BackEndSQLite.KEY_CUISINE));
			//System.out.println("*** Cookbook:onCreate cuisine = "+cuisine);
			myCuisinesSetunOrdered.add(cuisine);
		}
		cursorCuisines.close();
		myCuisinesSet = new TreeSet(myCuisinesSetunOrdered);
		myCuisinesSetunOrdered.clear();
		
		
		// create ChefNameUid.  query DB for username,userid load into collection
		// if chefID=-1, then use default imagename.
		ChefNameUid.clear();
		Cursor cursorChefs = mDbHelper.getChefsUidDownloaded();
		for (int i=0;i<cursorChefs.getCount();i++){
			cursorChefs.moveToPosition(i);
			String chefname = cursorChefs.getString(cursorChefs
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFNAME));
			Integer chefid = cursorChefs.getInt(cursorChefs
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEUSERID));
			Integer chefimagedownloaded = cursorChefs.getInt(cursorChefs
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFIMAGEDOWNLOADED));
			String chefimagename = cursorChefs.getString(cursorChefs
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFIMAGENAME));
			String value = String.valueOf(chefid)+"::"+String.valueOf(chefimagedownloaded);
			value=value+"::"+chefimagename;
			ChefNameUid.put(chefname, value);
		}
		cursorChefs.close();
		
		/*
		 * this method loads the myCookbookALLadapter and myCategoriesAdapter so
		 * only one pass through Cursor is required. LATER: fill itla here as
		 * well.
		 */
		// create adapter for the all list
		//Category2Rid myCategory2Rid = new Category2Rid();

		
		Cursor DBcursor = mDbHelper.getRecipes4Cookbook();
		for (int i = 0; i < DBcursor.getCount(); i++) {
			// get imagehttp, recipename
			DBcursor.moveToPosition(i);
			String name = DBcursor.getString(DBcursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPENAME));
			int recipeid = DBcursor.getInt(DBcursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID));
			AllRecipesInCookBook.put(name, recipeid);
		}
		// close cursor:
		DBcursor.close();
		
		// close database
		mDbHelper.close();
	}

	// create fields, variables, and Map
	private BackEndSQLite mDbHelper;
	//IconifiedTextListAdapter itla;
	private Context mContext;

	// this Map ensures that only one cuisine/country/"USA" is displayed.
	// static Map<String,Integer> CuisinesAlreadyAdded = new
	// HashMap<String,Integer>();
	//private Map<String, Integer> CuisinesInCookBook = new HashMap<String, Integer>();
	//private Map<String, Integer> categoryChecker = new HashMap<String, Integer>();
	public Map<String, Integer> AllRecipesInCookBook = new HashMap<String, Integer>();
	private Map<String, String> ChefNameUid = new HashMap<String, String>();
	private Set<String> myCuisinesSetunOrdered = new HashSet<String>();
	private Set<String> myCategorySetunOrdered = new HashSet<String>();
	private TreeSet myCuisinesSet;
	private TreeSet myCategorySet;
}
