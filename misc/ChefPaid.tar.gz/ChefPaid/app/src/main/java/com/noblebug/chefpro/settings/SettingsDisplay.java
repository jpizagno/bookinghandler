package com.noblebug.chefpro.settings;


import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.NewUser;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class SettingsDisplay extends Activity {
	// this class displays the settings for an Activity.
	// 4 June 2011. Jim Pizagno
	
	private int screenWidth;
	private BackEndSQLite mDbHelper;
	private String userid;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		
		// set orientation to POTRAIT, no TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// get Settings Object from Controller:
		appState = ((ChefController) getApplicationContext());
		mySettings = appState.getSettings();

		// Create a LinearLayout in which to add the ImageView
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		//mLinearLayout.setBackgroundResource(R.drawable.grocerypaperbackground);

		LinearLayout topButtonsLayout = new LinearLayout(this);
		topButtonsLayout.setOrientation(LinearLayout.HORIZONTAL);

		//ADD TITLE
		screenWidth = this.getWindowManager().getDefaultDisplay().getWidth();
		final SettingsTitle myTitle = new SettingsTitle(this);
		myTitle.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
		            {
		            	float x = ev.getX();
		            	float percentX = x/screenWidth;
		            	if(percentX>0.76){
		            		myTitle.pushed=true;
		            		myTitle.pushButton();
		            		myTitle.invalidate();
		            	}
		            	break;
		            }
		            case MotionEvent.ACTION_UP:
		            {
		            	myTitle.pushed=false;
		            	gotoAboutChef();
		            	break;
		            }
		        }
				return true;
			}
		});
		mLinearLayout.addView(myTitle);
		

		LayoutParams WrapContentParams = new LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

		mLinearLayout.addView(topButtonsLayout, WrapContentParams);

		// 4 June 2011. Next 3 code blocks deal with WAKELOCK and Quantity List.
		//		They are not working, so do not implement for now.
		//TextView recipetitle = new TextView(this);
		//recipetitle.setText("Recipe");
		//recipetitle.setTextColor(Color.DKGRAY);
		//recipetitle.setPadding(5, 5, 5, 5);
		//mLinearLayout.addView(recipetitle);

		//QuantityGroceryList = new CheckBox(this);
		//QuantityGroceryList.setText("Use Quantity In Grocery Lists");
		//QuantityGroceryList.setTextColor(Color.DKGRAY);
		//mLinearLayout.addView(QuantityGroceryList, WrapContentParams);

		DisableSleep = new CheckBox(this);
		DisableSleep.setText("Disable Sleep");
		DisableSleep.setTextColor(Color.DKGRAY);
		String[] temp = mDbHelper.getUserSingle();
		userid = temp[3];
		try {
			//
			if(mDbHelper.getWakeLockState(userid)) {
				DisableSleep.setChecked(true);
				appState.setDisableSleep(true);
			} else {
				DisableSleep.setChecked(false);
				appState.setDisableSleep(false);
			}
		} catch (Exception e) {
			mDbHelper.setWakeLockInitial(userid);
	        e.printStackTrace();
	    }
		DisableSleep.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	if (DisableSleep.isChecked()) {
        			appState.setDisableSleep(true);
        			mDbHelper.setWakeLock(userid,0);
        		} else {
        			appState.setDisableSleep(false);
        			mDbHelper.setWakeLock(userid,1);
        		}
            }
        });
		
		mLinearLayout.addView(DisableSleep, WrapContentParams);

		TextView grocerytitle = new TextView(this);
		grocerytitle.setText("Grocery List");
		grocerytitle.setTextColor(Color.DKGRAY);
		grocerytitle.setPadding(5, 5, 5, 5);
		mLinearLayout.addView(grocerytitle);

		Button sectionOrder = new Button(this);
		sectionOrder.setText("Section Order       >");
		mLinearLayout.addView(sectionOrder, WrapContentParams);
		sectionOrder.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				gotoSectionsEditor();
			}
		});

		TextView StartingPagetitle = new TextView(this);
		StartingPagetitle.setText("Starting Page");
		StartingPagetitle.setTextColor(Color.DKGRAY);
		StartingPagetitle.setPadding(5, 5, 5, 5);
		mLinearLayout.addView(StartingPagetitle);

		Button recipePage = new Button(this);
		recipePage.setText("Set Starting Page");
		recipePage.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				startingPageSelector();
			}
		});
		mLinearLayout.addView(recipePage);

		TextView Logintitle = new TextView(this);
		Logintitle.setText("Login");
		Logintitle.setTextColor(Color.DKGRAY);
		Logintitle.setPadding(5, 5, 5, 5);
		mLinearLayout.addView(Logintitle);

		Button loginbutton = new Button(this);
		// call newUser activity when clicked:
		loginbutton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// go to newuser activity
				createNewUser();
			}
		});
		
		if(mDbHelper.getUserSingle()[0].equalsIgnoreCase("notUsingWeb")) {
			loginbutton.setText("click to login in to www.chefslittlehelper.com");
		} else {
			loginbutton.setText("User Name:  "+mDbHelper.getUserSingle()[BackEndSQLite.out_int_username]);
		}
		
		mLinearLayout.addView(loginbutton);

		// create scroller view
		ScrollView scroller = new ScrollView(this);
		// put linearlayout in scroller view
		scroller.setScrollbarFadingEnabled(true);
		//scroller.setBackgroundResource(R.drawable.grocerypaperbackground);
		scroller.setBackgroundResource(R.drawable.tanbackground);
		scroller.addView(mLinearLayout);

		// Add the scroller (with mLinearLayout inside) to Activity
		setContentView(scroller);
	}
	
    private class SettingsTitle extends RelativeLayout {
		private Button aboutButton;
		private int width;
		private int height;
		private boolean pushed = false;
		private int buttonResource;
		
		public SettingsTitle(Context context) {
			super(context);
			// set dimensions
    		Display display = getWindowManager().getDefaultDisplay();
			width = display.getWidth();
			height =  display.getHeight() / 8;
			
			// add clearbutton and icon
			RelativeLayout mRelativeLayout = new RelativeLayout(context);
	        
			this.setBackgroundResource(R.drawable.blanktitle);
			
	        // add background  "Settings" and icon
			TextView title = new TextView(context);
			title.setText("Settings");
			Typeface myType = Typeface.create(Typeface.SERIF, Typeface.NORMAL);
			title.setTypeface(myType);
			if (display.getHeight() > 600) {  
				// this If()else statement accounts for devices with different sizes
				title.setTextSize(30);
			} else {
				title.setTextSize(18);
			}
			int padtop2 = height/6;
			LinearLayout innerLayout2 = new LinearLayout(context);
			innerLayout2.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
					LayoutParams.WRAP_CONTENT));
			innerLayout2.setGravity(Gravity.CENTER);
			innerLayout2.addView(title);
			innerLayout2.setPadding(0, padtop2, 0, 0);
			mRelativeLayout.addView(innerLayout2);

	        // add AboutButton
			aboutButton = new Button(context);
			if(pushed==false){
				buttonResource = R.drawable.about;
				aboutButton.setBackgroundResource(R.drawable.about);
			} else {
				buttonResource = R.drawable.aboutclicked;
			}
			aboutButton.setBackgroundResource(buttonResource);
			aboutButton.setFocusable(false);
			aboutButton.setClickable(false);
			int padleft = width*75/100; //aboutButton.getWidth();
			int padtop = height/5;
			int widthbutton = width *20/100;
			int heightbutton = height * 60/100;
			LinearLayout innerlayout = new LinearLayout(context);
			innerlayout.addView(aboutButton,widthbutton,heightbutton);
			innerlayout.setPadding(padleft, padtop, 0, 0);
			mRelativeLayout.addView(innerlayout);
    		
	        addView(mRelativeLayout);
		}
    	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
    		this.setMeasuredDimension(width,height);
    	} 
		public void pushButton(){
			pushed=true;
			buttonResource =  R.drawable.aboutclicked; //cookbookbuttonpushed;
			this.invalidate();
		}
    }
	
	
	private void startingPageSelector() {
		final CharSequence[] items = new CharSequence[5]; //Home,Cookbook,GroceryList,Search,Timers
		items[0]="Home";
		items[1]="Cookbook";
		items[2]="Grocery List";
		items[3]="Search";
		items[4]="Timers";
		final boolean[] checked = new boolean[5];

		final AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Select Starting Page");
		int arg1=-1;		
		
		builder.setSingleChoiceItems(items, arg1,  new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// check which starting page
				checked[which]=true;
			}
		});

		AlertDialog alert = builder.create();
		
		alert.setButton2("Set Starting Page",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						for (int i = 0; i < checked.length; i++) {
							if (checked[i]) {
								appState.setStartingPage((String) items[i]);
							}
						}
					}
				});

		alert.show();
	}

	
	private void myFinish() {
		// method to get all information 
		if (mDbHelper.isDatabaseOpen==false){
			mDbHelper.open();
		}
		//String temp = mDbHelper.getUserSingle();
		//String userid = temp.split("_")[3];
		//if (QuantityGroceryList.isChecked() == true) {
		//	appState.setQuantityGroceryList(true);
		//} else {
		//	appState.setQuantityGroceryList(false);
		//}
		//if (DisableSleep.isChecked() == true) {
		//	appState.setDisableSleep(true);
		//	//mDbHelper.setWakeLock(userid,0);
		// else {
		if (DisableSleep.isChecked()) {
			appState.setDisableSleep(true);
			mDbHelper.setWakeLock(userid,0);
		} else {
			appState.setDisableSleep(false);
			mDbHelper.setWakeLock(userid,1);
		}
		//}
		mDbHelper.close();
	}
	
	private void createNewUser() {
		// call new user activity
		myFinish();
		Intent i_newuser = new Intent(this, NewUser.class);
		startActivity(i_newuser);
	}

	protected void gotoAboutChef() {
		myFinish();
		Intent i = new Intent(this, AboutChef.class);
		startActivity(i);
	}

	protected void gotoSectionsEditor() {
		myFinish();
		Intent i = new Intent(this, SectionsEditor.class);
		startActivity(i);
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
//		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
//		menu.add(0, Chef_ID, 0, "").setIcon(home);
		
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Settings_ID:
			this.gotoSettings();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void gotoSettings() {
		myFinish();
		Intent i = new Intent(this, SettingsDisplay.class);
		startActivity(i);
	}

	private void createTimers() {
		myFinish();
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		myFinish();
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		myFinish();
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		myFinish();
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	private void gotoChef() {
		myFinish();
		Intent i = new Intent(this, Home.class);
		setResult(RESULT_OK, i);
		finish();
	}
	@Override
	public void onBackPressed() {
		this.myFinish();
		this.gotoChef();
	}

	// create fields
	private static final int Cookbook_ID = 0;
	private static final int Grocerylist_ID = 1;
	private static final int Search_ID = 2;
	private static final int Timers_ID = 3;
	private static final int Settings_ID = 4;
	private ChefController appState;
	private LinearLayout mLinearLayout;
	private Settings mySettings;
	CheckBox QuantityGroceryList;
	CheckBox DisableSleep;
	//CheckBox ShowQuantBadge;
}
