package com.noblebug.chefpro.recipe;

import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.tools.ImageHandler;
import android.database.Cursor;

public class Recipe {
	//
	 // This is a recipe class and should have nothing but all recipe info, and
	 // getter/setter methods! for a given Recipe-object
	// 4 June 2011. Jim Pizagno.  
	 //

	// set fields of Recipe from 3 cursors.
	// cursors are created in database.
	// database calls this method
	public void setFieldsFrom3Cursors(Cursor cursorRecipe,
			Cursor cursorIngredients, Cursor cursorInstructions) {
		if (cursorRecipe.getCount()==0) {
			// this could be from trying to add the OddsNEnds recipe.
			// if cursors are empty then BackEndSQLite will try to create a recipe if id=null:
			this.recipeid=null;
			this.recipename=null;// close cursors:
			cursorRecipe.close();
			cursorIngredients.close();
			cursorInstructions.close();
		} else {
			// sets fields from Cursors
			// set values in new Recipe Object!
			this.user = cursorRecipe.getInt(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEUSERID));
			this.chefimagedownloaded = cursorRecipe.getInt(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFIMAGEDOWNLOADED));
			this.chefimagename = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFIMAGENAME));
			this.recipename = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPENAME));
			this.cuisine = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CUISINE));
			this.recipeid = cursorRecipe.getInt(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID));
			this.chefname = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFNAME));
			this.category = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CATEGORY));
			// category in lower case:
			this.category.toLowerCase();
			this.serves = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_SERVES));
			this.partofcookbook = cursorRecipe.getInt(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_PARTOFCOOKBOOK));
			this.rating = cursorRecipe.getFloat(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RATING));
			this.Imagehttp = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_IMAGEHTTP));
			if (this.Imagehttp==null){
				this.PictureNameOnDisk = null;
			} else {
				String[] temp = this.Imagehttp.split("/");
				this.PictureNameOnDisk = temp[temp.length - 1];
			}
			this.description = cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_DESCRIPTION));
			this.changed = Integer.getInteger(cursorRecipe.getString(cursorRecipe
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHANGED)));
			this.bookmarked = Integer.getInteger(cursorRecipe
					.getString(cursorRecipe
							.getColumnIndexOrThrow(BackEndSQLite.KEY_BOOKMARKED)));
	
			this.NumInstructions = cursorInstructions.getCount(); // returns number
																	// of rows in
																	// cursor=num
																	// steps
			this.instructionsArray = new String[NumInstructions];
			for (int m = 0; m < NumInstructions; m++) {
				cursorInstructions.moveToPosition(m);
				instructionsArray[m] = cursorInstructions
						.getString(cursorInstructions
								.getColumnIndexOrThrow(BackEndSQLite.KEY_INSTRUCTIONS));
			}
	
			this.NumIngredients = cursorIngredients.getCount();
			this.ingredientsArray = new String[NumIngredients];
			for (int m = 0; m < NumIngredients; m++) {
				// ingrednumber_number_fraction_unit_desc
				cursorIngredients.moveToPosition(m);
				String temp2 = cursorIngredients.getString(cursorIngredients
						.getColumnIndexOrThrow(BackEndSQLite.KEY_INGREDIENTNUMBER));
				String temp3 = cursorIngredients.getString(cursorIngredients
						.getColumnIndexOrThrow(BackEndSQLite.KEY_QUANTITY));
				String temp4 = cursorIngredients.getString(cursorIngredients
						.getColumnIndexOrThrow(BackEndSQLite.KEY_FRACTION));
				String temp5 = cursorIngredients.getString(cursorIngredients
						.getColumnIndexOrThrow(BackEndSQLite.KEY_UNIT));
				String temp6 = cursorIngredients.getString(cursorIngredients
						.getColumnIndexOrThrow(BackEndSQLite.KEY_ITEM));
				ingredientsArray[m] = temp2 + "_" + temp3 + "_" + temp4 + "_"
						+ temp5 + "_" + temp6;
			}
	
			// close cursors:
			cursorRecipe.close();
			cursorIngredients.close();
			cursorInstructions.close();
		}
	}

	public void setFieldsFromString(String internetResult, int recipeID) {
		// this method sets the recipe fields from internetResult
		// internetResult comes after a Search.  
		// example string:
		//Jerk Seasoning^^5^^Chef Yuka^^1300239559^^100^^NONE^^Sauce^^Jamaican
		//^^This is a great seasoning for any meat. You can store it in an airtight 
		// container in a cool, dry place. This recipe yield for 1/4 cup.
		//  ^^^^http://www.chefslittlehelper.com/sites/default/files/userpics_public/Jerk Seasoning 
		//  (Chef Yuka)_0.jpg^^
		// 8^^2^^^^Tablespoon^^dried minced onion ^^2^^1/2^^Teaspoon^^dried thyme ^^
		// 2^^^^Teaspoon^^ground allspice ^^2^^^^Teaspoon^^ground black pepper ^^^^
		// 1/2^^Teaspoon^^ground cinnamon ^^^^1/2^^Teaspoon^^cayenne pepper ^^^^
		// 1/2^^Teaspoon^^salt ^^2^^^^Tablespoon^^vegetable oil ^^2^^In a small bowl, 
		// mix all ingredients except the oil.^^Coat meat lightly with oil, then rub 
		//seasoning onto meat or mix the seasoning with the oil and rub meat.^^
		// 
		// so parse on "^^" then on "^^^^" for instructions
		//System.out.println("******* Recipe::setFieldsFromString internetResult = "+internetResult+" recipeID="+String.valueOf(recipeID));
		this.recipeid = recipeID;
		int tempcount = 0;
		internetResult = internetResult.replace("^^", "%%%");
		String[] temp = internetResult.split("%%%");
		this.recipename = temp[0];
		tempcount = tempcount + 1;
		//System.out.println("*** Recipe::setFieldsFromString recipename = "+temp[0]);
		this.user = Integer.valueOf(temp[1]);
		tempcount = tempcount + 1;
		//System.out.println("*** Recipe::setFieldsFromString  userid = "+temp[1]);
		this.chefname = temp[2];
		tempcount = tempcount + 1;
		//System.out.println("*** Recipe::setFieldsFromString  chefname = "+temp[2]);
		this.changed = Integer.valueOf(temp[3]);
		tempcount = tempcount + 1;
		//System.out.println("*** Recipe::setFieldsFromString  changed = "+temp[3]);
		if (temp[4].equalsIgnoreCase("NONE") == false && temp[4].equalsIgnoreCase("null") == false) {
			this.rating = (float) (Float.valueOf(temp[4].trim()) / 20.0);
		} else {
			this.rating = (float) 0.0;
		}
		tempcount = tempcount + 1;
		tempcount = tempcount + 1; //skip temp[5]
		this.category = temp[6];
		tempcount = tempcount + 1;
		this.cuisine = temp[7];
		tempcount = tempcount + 1;
		this.description = temp[8];
		this.serves = temp[9];
		tempcount = tempcount + 1;
		this.Imagehttp = temp[10].replace(" ","%20");
		tempcount = tempcount + 1;
		this.NumIngredients = Integer.valueOf(temp[11]);
		tempcount = tempcount + 1;
		this.ingredientsArray = null; // clear just in case
		this.ingredientsArray = new String[this.NumIngredients];
		// ingredient format: // ingrednumber_number_fraction_unit_desc
		//number fraction unit description:  1_2_1/2_teaspoon_driedThyme
		for (int i=0;i<this.NumIngredients;i++){
			tempcount = tempcount + 1;
			String ingredient = String.valueOf(i)+"_"+temp[tempcount];
			tempcount = tempcount + 1;
			ingredient = ingredient + "_"+temp[tempcount];
			tempcount = tempcount + 1;
			ingredient = ingredient + "_"+temp[tempcount];
			tempcount = tempcount + 1;
			ingredient = ingredient + "_"+temp[tempcount];
			ingredientsArray[i]=ingredient;
		}
		tempcount = tempcount + 1;
		this.NumInstructions = Integer.valueOf(temp[tempcount]);
		this.instructionsArray = null; // clear just in case
		this.instructionsArray = new String[this.NumInstructions];
		for (int i=0;i<this.NumInstructions;i++) {
			tempcount = tempcount + 1;
			instructionsArray[i] = temp[tempcount];
		}		
	}
	
	// given a string parse by "::" to get fields
	public String Fields2String() {
		// put necessary fields in long String.
		// separated by ::
		// recipehere.recipeid::recipehere.recipename::recipehere.rating::temprecipe.Imagehttp::
		// ::recipehere.chefname::recipehere.cuisine::recipehere.category::
		// ::recipehere.serves::recipehere.description::
		// ::recipe.NumIngredients::recipehere.ingredientsArray::
		// ::recipehere.NumInstructions::recipehere.instructionsArray
		// 
		// WARNING:  fields can end with : as in 31653:  "Easy Serves:".
		String strout = null;
		strout = String.valueOf(this.recipeid);
		strout = strout + "::" + this.recipename + "::"
				+ String.valueOf(this.rating);
		strout = strout + "::" + this.Imagehttp + "::" + this.chefname;
		strout = strout + "::" + String.valueOf(this.user);
		strout = strout + "::" + this.cuisine + "::" + this.category;
		strout = strout + "::" + this.serves + "::" + this.description.replace(":", ".");
		strout = strout + "::" + String.valueOf(this.changed);
		strout = strout + "::" + String.valueOf(this.NumIngredients);
		for (int i = 0; i < this.NumIngredients; i++) {
			strout = strout + "::" + ingredientsArray[i].replace(":", ".");
		}
		strout = strout + "::" + this.NumInstructions;
		for (int i = 0; i < this.NumInstructions; i++) {
			strout = strout + "::" + instructionsArray[i].replace(":", ".");
		}
		return strout;
	}

	
	// url for user:
	//"http://www.chefslittlehelper.com/sites/default/files/pictures/picture-usrid.jpg";
	// so me=4 , on disk shoudl be:  picture-4.jpg
	//
	// define filds in recipe
	// define everything in a recipe
	public Integer user; // also userid for this recipe.  
	public Integer chefimagedownloaded; // 0=true 1=false
	public String chefimagename; //ex: picture-9058.png
	public String recipename = null;
	public Integer recipeid = null;
	public String chefname;
	public String cuisine;
	public String category;
	public String serves;
	public String[] instructionsArray;
	public int NumInstructions = 0;
	public String[] ingredientsArray = null; // split("_")
	public int NumIngredients = 0;
	public Cursor instructionsCursor;
	public Integer partofcookbook; // 0=true 1=false
	public Integer partofgrocerylist=1; // default is not part of grocerylist (=1)
	public Integer bookmarked; // 0=true 1=false
	public float rating; // default is zero=unrated. number of stars
	public String Imagehttp = null;
	public Integer changed = null;
	//
	 // changed is the timestamp of the last time it was changed. It's in seconds
	 // since 1970 I think. Sometime around then anyway. It's useful to know for
	 // know what you have local is out of date or not. Especially used in the
	 // syncing of the user's recipes.
	 //
	public String description;
	public String PictureNameOnDisk = null; // just end of Imagehttp.split("/")
}
