package com.noblebug.chefpro.search;

import com.noblebug.chefpro.R;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class SearchSettings extends Activity {

	// this page is used to set the Search settings.
	// it also overrides the back press to call the items and go to Search results.
	// the current text/cuisine/category/images in SearchDisplay is given and pass back.
	// 4 June 2011

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// get userid
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		userid = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
		
		sendtoSettings = (String) this.getIntent().getCharSequenceExtra("sendtoSettings");
		
		// create layout
		LinearLayout mLinearLayout = new LinearLayout(this);
		mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		
		// add buttons
		dairyfreebox = new CheckBox(this); //(CheckBox) findViewById(R.id.dairyfreebox);
		dairyfreebox.setText("Dairy Free");
		dairyfreebox.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(dairyfreebox);
		eggfreebox = new CheckBox(this); //findViewById(R.id.eggfreebox);
		eggfreebox.setText("Egg Free");
		eggfreebox.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(eggfreebox);
		glutenfreebox = new CheckBox(this); //findViewById(R.id.glutenfreebox);
		glutenfreebox.setText("Gluten Free");
		glutenfreebox.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(glutenfreebox);
		nutfreebox = new CheckBox(this); //findViewById(R.id.nutfreebox);
		nutfreebox.setText("Nut Free");
		nutfreebox.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(nutfreebox);

		// set chose order text
		TextView myText = new TextView(this);
		myText.setPadding(0, 10, 0, 0);
		myText.setText("Choose Ordering");
		myText.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(myText);
		
		// get order boxes
		alphabox = new CheckBox(this); //findViewById(R.id.alphabox);
		alphabox.setText("Alphabetical Order");
		alphabox.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(alphabox);
		latestbox = new CheckBox(this); //findViewById(R.id.latestbox);
		latestbox.setText("Order By Entry Date");
		latestbox.setTextColor(Color.DKGRAY);
		mLinearLayout.addView(latestbox);
		alphabox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (isChecked) {
					latestbox.setChecked(false);
				}
			}
		});
		latestbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (isChecked) {
					alphabox.setChecked(false);
				}
			}
		});
		// get current settings from DB
		String[] tempsettings = mDbHelper.getSearchSettings(userid).split("::");
		if (tempsettings[0].equalsIgnoreCase("latest")){
			latestbox.setChecked(true);
			alphabox.setChecked(false);
		}
		if (tempsettings[0].equalsIgnoreCase("alpha")){
			latestbox.setChecked(false);
			alphabox.setChecked(true);
		}
		if (tempsettings[1].equalsIgnoreCase("YES")){
			dairyfreebox.setChecked(true);
		}
		if (tempsettings[2].equalsIgnoreCase("YES")){
			eggfreebox.setChecked(true);
		}
		if (tempsettings[3].equalsIgnoreCase("YES")){
			glutenfreebox.setChecked(true);
		}
		if (tempsettings[4].equalsIgnoreCase("YES")){
			nutfreebox.setChecked(true);
		}
		
		ScrollView myScroller = new ScrollView(this);
		myScroller.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		myScroller.setBackgroundResource(R.drawable.grocerypaperbackground);
		myScroller.addView(mLinearLayout);
		setContentView(myScroller);
	}
	
	@Override
	public void onBackPressed() {
		finishSettings();
	   return;
	}
	
	public void finishSettings() {
		String order = "latest";
		if (latestbox.isChecked()) {
			order = "latest";
		}
		if (alphabox.isChecked()) {
			order = "alpha";
		}
		String dairyfree;
		if (dairyfreebox.isChecked()) {
			dairyfree = "YES";
		} else {
			dairyfree = "NO";
		}
		String eggfree;
		if (eggfreebox.isChecked()) {
			eggfree = "YES";
		} else {
			eggfree = "NO";
		}
		String glutenfree;
		if (glutenfreebox.isChecked()) {
			glutenfree = "YES";
		} else {
			glutenfree = "NO";
		}
		String nutfree;
		if (nutfreebox.isChecked()) {
			nutfree = "YES";
		} else {
			nutfree = "NO";
		}

		// add to DB
		if (mDbHelper.isDatabaseOpen) {
			String settings = order+"::"+dairyfree+"::"+eggfree+"::"+glutenfree+"::"+nutfree;
			mDbHelper.setSearchSettings(userid,settings);
			mDbHelper.close();
		}
			
		// call SearchDislplay
		Intent i = new Intent(this, SearchDisplay.class);
		i.putExtra("sendtoSettings", sendtoSettings);
		startActivity(i);
	}
	
	private BackEndSQLite mDbHelper = null;
	private Integer userid;
	private CheckBox dairyfreebox;
	private CheckBox eggfreebox;
	private CheckBox glutenfreebox;
	private CheckBox nutfreebox;
	private CheckBox alphabox;
	private CheckBox latestbox;
	private String sendtoSettings;
}
