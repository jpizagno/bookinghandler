package com.noblebug.chefpro;

import java.util.Date;
import java.util.List;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GroceryList;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.planner.Planner;
import com.noblebug.chefpro.recipe.Recipe;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.settings.AboutChef;
import com.noblebug.chefpro.settings.SettingsDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.MD5Hash;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Home extends Activity {
	//
	 // The Home activity. It displays graphics, and also syncs the grocery list and cookbook with the webpage.
	 // 12May2011 Jim
	 //
	
	
	private ProgressDialog myProgressDialog;
	private int increment;
	private int screenheight;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// collect some garbage:
		System.gc();

		// give context to chefcontroller
		// also create objects
		ChefController appState = ((ChefController) getApplicationContext());
		// appState.createObjects(this);

		this.screenheight = this.getWindowManager().getDefaultDisplay().getHeight();
		
		// check for open internet
		appState.check4InternetConnection(this);
		
		//setContentView(R.layout.main);
   		LinearLayout mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		
		// get parameters for the window.
	    Display display = getWindowManager().getDefaultDisplay();
		int statusBarHeight = 0;
		int screen_height = display.getHeight();
		int screen_width = display.getWidth();
		//System.out.println("***** height  width = "+String.valueOf(screen_height)+" "+String.valueOf(screen_width));
		if(screen_height==569){
			statusBarHeight = 50;
		} else if (screen_height==480){
			statusBarHeight = 480-430;
		}
		//System.out.println("view width height = "+String.valueOf(screen_width)+" "+String.valueOf(screen_height-statusBarHeight));
	    final float view_width = (float) screen_width;
	    final float view_height = (float) (screen_height-statusBarHeight);
		
		final DrawView myButtonWidget = new DrawView(this,view_width,view_height);
		myButtonWidget.imagecase = myButtonWidget.imagecasedefault;
		myButtonWidget.setClickable(true);
		myButtonWidget.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
				//System.out.println("ev.getX ev.getY = "+String.valueOf(ev.getX())+" "+String.valueOf(ev.getY()));
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
		            	// users touches the screen so change graphic
						float x = ev.getX();
						float y = ev.getY();
						myButtonWidget.imagecase = getClickLocation(y);
						//if (x>0.80*view_width && x<0.99*view_width && y>0.01*view_height && y<0.1*view_height){
						//	// settings
						//	myButtonWidget.imagecase = myButtonWidget.imagecasesetting;
						//}
						//if (x>0.1*view_width && x<0.9*view_width && y>view_height*60/100 && y<=view_height*70/100){
						//	// grocerylist:  
						//	myButtonWidget.imagecase = myButtonWidget.imagecasegrocery;
						//}
						//if (x>0.1*view_width && x<0.9*view_width && y>view_height*70/100 && y<view_height*80/100){
						//	// cookbook  
						//	myButtonWidget.imagecase = myButtonWidget.imagecookbook;
						//}
						//if (x>0.1*view_width && x<0.9*view_width && y>view_height*80/100 && y<view_height){
						//	// recipe search
						//	myButtonWidget.imagecase = myButtonWidget.imagerecipesearch;
						//}
						myButtonWidget.invalidate();
						break;
		            case MotionEvent.ACTION_UP:
		            	// user releases the graphic, so call appropriate method
		            	//String str;
		            	if (myButtonWidget.imagecase.equalsIgnoreCase(myButtonWidget.imagecasesetting)) {
		            		//str = "calling method setting";
		            		myButtonWidget.imagecase = myButtonWidget.imagecasedefault;
		            		gotoSettings();
		            		//oast.makeText(getBaseContext(), str, Toast.LENGTH_SHORT).show();
		            	}
		            	if (myButtonWidget.imagecase.equalsIgnoreCase(myButtonWidget.imagecookbook)) {
		            		//str = "calling method cookbook";
		            		myButtonWidget.imagecase = myButtonWidget.imagecasedefault;
		            		createCookbook();
		            		//Toast.makeText(getBaseContext(), str, Toast.LENGTH_SHORT).show();
		            	}
		            	if (myButtonWidget.imagecase.equalsIgnoreCase(myButtonWidget.imagecasegrocery)) {
		            		//str = "calling method grocery";
		            		myButtonWidget.imagecase = myButtonWidget.imagecasedefault;
		            		createGroceryList();
		            		//Toast.makeText(getBaseContext(), str, Toast.LENGTH_SHORT).show();
		            	}
		            	if (myButtonWidget.imagecase.equalsIgnoreCase(myButtonWidget.imagerecipesearch)) {
		            		//str = "calling method recipesearch";
		            		myButtonWidget.imagecase = myButtonWidget.imagecasedefault;
		            		createSearch();
		            		//Toast.makeText(getBaseContext(), str, Toast.LENGTH_SHORT).show();
		            	}
						break;
		        }
				return true;
			}
		});
		mLinearLayout.addView(myButtonWidget);
        
		mLinearLayout.setBackgroundResource(R.drawable.maindefault);
		
		// set the mLinearLayout to display
		setContentView(mLinearLayout);
		
		
		// create database here. even if empty
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		
		//old:  Cursor allUsersCursor = mDbHelper.getAllUsers();
		if (mDbHelper.getNumUsers()==0) {  //allUsersCursor.getCount() == 0) {
			System.out.println("**** CHef:home  count = "+mDbHelper.getNumUsers());
			// lets add a user id if the user is new
			// nothing entered
			// NEW USER  set userid=-1
			String username = "notUsingWeb";
			password = "notUsingWeb";
			Integer userid = -1;
			mDbHelper.addUserAppend(username, password, userid);
			appState.setDefaultAisleList();
			
			mDbHelper.setDefaultSearchSettings(-1);
			appState.setAllTimersZero();
		} // else already entered a new user. Still can be userid=-1 or userid>0
		//allUsersCursor.close();
		//// get UserID/password, send to appState
		////System.out.println("**** home: setUIDandPASWD()");
		////String temp = mDbHelper.getUserIDpassword();
		String[] temp = mDbHelper.getUserSingle(); //username+"_"+password+"_"+md5password+"_"+useridout
		UID = temp[3];
		password = temp[1];
		appState.setUIDandPASSWD(UID, password);

		String[] Aislelist = appState.getAisleList();
		mDbHelper.updateAislelist(Integer.valueOf(UID), Aislelist);
		
		// create objects after grocerylist
		appState.createObjects(this);
		
		// GROCERY LIST stuff:
		//
		String HomeGroceryList = null;
		if (appState.internetConnectionOpen==true && Integer.valueOf(UID)>-1) {
			// get grocerylist from web:
			BackEndPHPHandler myPHPHandler = new BackEndPHPHandler();
			//System.out.println("***** home:  sendWeb2GroceryList()");
			myPHPHandler.sendWeb2GroceryList(UID);
			HomeGroceryList = myPHPHandler.sendWeb2GroceryListResult;
		} 

		// reset myGroceryList, feed backto appsate
		//System.out.println("**** home:  get myGroceryList");
		GroceryList myGroceryList = appState.getGrocerylist();
		// myGroceryList.fillAdapters(appState.getAisleList());
		if (HomeGroceryList!=null) {
			myGroceryList.matchDatabaseWithHomeGroceryList(HomeGroceryList);
		}
		myGroceryList.fillAdapters(appState.getAisleList());
		//System.out.println("***** home:  setGroceryList()");
		appState.setGroceryList(myGroceryList);

		
		// next sync the cookbook:
		//I also added cookbookUpdate.php to the android api folder. Here's how to call it:
		//NSString *url = @"http://www.chefslittlehelper.com/API/iPad/1.1.0/cookbookupdate.php?uid=";
		//url = [url stringByAppendingString:userInfo.uid];
		//url = [url stringByAppendingFormat:@"&password=%@",userInfo.hash];
		//url = [url stringByAppendingFormat:@"&updateTime=%f",settings.recipesUpdateTime];
		//
		//It'll return three lists of recipe id's separated by , and ^. e.g.
		//
		//10466,27000,26998^^112^1292291013
		//The first list is recipes updated since the time provided, 
		//the second is a list of recipes not updated since the time provided, 
		//the third list is a list of all the bookmarks and the last is the new update time. 
		//Let me know if you have any questions.
		// get all recipes:		
		if (appState.internetConnectionOpen==true && UID.equalsIgnoreCase("-1")==false) {
			//Integer[] recipeIDs = mDbHelper.getAllRecipesCookbook();
			// get md5password
			MD5Hash myMD5hasher = new MD5Hash();
			String md5password = myMD5hasher.getMd5Hash(password);
			// get time since last update
			Long recipeLastUpdateTime = mDbHelper.getRecipeLastUpdateTime(Integer.valueOf(UID)); // should be in user settings
			// send to PHP:
			BackEndPHPHandler myPHPHandler2 = new BackEndPHPHandler();
			//System.out.println("***** home:  sendWeb2GroceryList()");
			myPHPHandler2.syncCookbook(UID,md5password,recipeLastUpdateTime);
			List<Integer> recipesNeedUpdating = myPHPHandler2.recipesNeedUpdating;
			if (recipesNeedUpdating!=null) {
				//System.out.println("****** Home::onCreate recipesNeedUpdating.length = "+String.valueOf(recipesNeedUpdating.size()));
				if(recipesNeedUpdating.size()>0) {
					progressBarUpdateRecipes(recipesNeedUpdating);
				}
			}
			mDbHelper.updateRecipeLastUpdateTime(Integer.valueOf(UID), myPHPHandler2.lastupdateTime);
			// sync with webpage:
//          If it's a bookmark then call bookmarkstoweb.php.
			List<Integer> recipeIDs_bookmarked = mDbHelper.getAllRecipesNotThisUser(Integer.valueOf(UID));
			myPHPHandler2.bookmarkstoweb(Integer.valueOf(UID),recipeIDs_bookmarked,md5password);
		}
		
		// close database
		//mDbHelper.close();
	}

	protected String getClickLocation(float y) {
		// determine the location of the click using screen height and screen width
		String myReturn = "default";
		if (y>0.01*this.screenheight && y<0.1*this.screenheight) {
			myReturn = "setting";
		} else {
			// for lower buttons, need different locations for different screen sizes
			if (this.screenheight<500) {
				if ( y>this.screenheight*60/100 && y<=this.screenheight*70/100){
					// grocerylist:  
					myReturn = "grocery";
				}
				if (y>this.screenheight*70/100 && y<this.screenheight*83/100){
					// cookbook  
					myReturn ="cookbook";
				}
				if ( y>this.screenheight*83/100 && y<this.screenheight){
					// recipe search
					myReturn = "recipesearch";
				}
			} else {
				// this works good for 800-like screens
				if ( y>this.screenheight*60/100 && y<=this.screenheight*70/100){
					// grocerylist:  
					myReturn = "grocery";
				}
				if (y>this.screenheight*70/100 && y<this.screenheight*80/100){
					// cookbook  
					myReturn ="cookbook";
				}
				if ( y>this.screenheight*80/100 && y<this.screenheight){
					// recipe search
					myReturn = "recipesearch";
				}
			}
		}
		return myReturn;
	}

	private void progressBarUpdateRecipes(final List<Integer> recipesNeedUpdating) {
		// This method displays a progress bar while recipes are updating. it is called
		// whenever a recipe has already been added to the phone, but is updated by the user.
		myProgressDialog = new ProgressDialog(this);
		myProgressDialog.setCancelable(true);
		myProgressDialog.setMessage("Updating Recipes...");
		// set the progress to be horizontal
		myProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        // reset the bar to the default value of 0
		myProgressDialog.setProgress(0);
        // get the maximum value
        // convert the text value to a integer
        final int maximum = recipesNeedUpdating.size();
        increment = 1;
        // set the maximum value
        myProgressDialog.setMax(maximum);
        // display the progressbar
        myProgressDialog.show();
        // create a thread for updating the progress bar
        Thread background = new Thread (new Runnable() {
           public void run() {
               // enter the code to be run while displaying the progressbar.
			   //
			   // This example is just going to increment the progress bar:
			   // So keep running until the progress value reaches maximum value
			   //while (myProgressDialog.getProgress()<= myProgressDialog.getMax()) {
        	   Looper.prepare();
				for (int i=0;i<maximum;i++) {
				   int recipeidtmp = (int) recipesNeedUpdating.get(i);
				   //Iterator<Integer> it = recipesNeedUpdating.iterator();
				   //while (it.hasNext()) {
				   // first want to delete entire recipe to avoid problems:
				   mDbHelper.deleteRecipe(recipeidtmp);
				   // then add the updated recipe
				   addRecipe2Cookbook(recipeidtmp,Integer.valueOf(UID));
				   progressHandler.sendMessage(progressHandler.obtainMessage());
			   }
			   Looper.myLooper().quit();
			   Looper.loop();
			   Looper.myLooper().quit();
			   myProgressDialog.dismiss();
			   // from CookbookSelectorDisplay example:  gotoCookbook();
           }
        });
        // start the background thread
        background.start();
	}
	// handler for the background updating
    Handler progressHandler = new Handler() {
        public void handleMessage(Message msg) {
        	myProgressDialog.incrementProgressBy(increment);
        }
    };
	
	private void addRecipe2Cookbook(Integer recipeid, Integer userid) {
		// add this recipe ID to the Cookbook in the mDbHelper2 database.
		// database mDbHelper2 shoudl already be open, and closed later
		BackEndPHPHandler myPHP3 = new BackEndPHPHandler();
		try {
			myPHP3.fetchStringRecipe(recipeid, userid);
			// display this recipe's information
			Recipe recipe2Update = myPHP3.RecipeFromFetchString;
			recipe2Update.partofcookbook=0;
			if (mDbHelper.hasRecipeBYId(recipe2Update.recipeid)==true) {
				// just UPDATE the recipe
				mDbHelper.updateRecipe(recipe2Update);
			} else {
				// ADD the recipe
				mDbHelper.addRecipe(recipe2Update);
			}
		} catch (Exception e) {
    		//Toast.makeText(getApplicationContext(), "Could not download recipeid = " + String.valueOf(recipeid)+" stringFields = "+stringFields, Toast.LENGTH_LONG).show();
    		String comment = "::from Home.addRecipe2Cookbook could not dowload recipeid:: "+recipeid+" ::contentsStringRecipe:"+myPHP3.contentsStringRecipe;
    		String priority = "WARNING";
    		myPHP3.exceptionlog(userid,comment,priority);
    	}
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		// example without bitmap:
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable mealplanner = this.getResources().getDrawable(R.drawable.mealplanner);
		menu.add(0, Planner_ID, 0, "").setIcon(mealplanner);;
		menu.add(0, AboutChef_ID, 0, "About Chef");
		menu.add(0, Contact_ID, 0, "Contact Us");
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Planner_ID:
			goto_planner();
			return true;
		case Contact_ID:
			contact_us();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Settings_ID:
			this.gotoSettings();
			return true;
		case AboutChef_ID:
			this.gotoAboutChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}
	
	private void goto_planner() {
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}
	
	protected void gotoAboutChef() {
		// call method for aboutchef()
		mDbHelper.close();
		Intent i = new Intent(this, AboutChef.class);
		startActivity(i);
	}
	
	private void contact_us() {
		// email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
		// users to provide feedback.
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity Home");
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void gotoSettings() {
		// go to the setting page, starts another activity.
		mDbHelper.close();
		Intent i = new Intent(this, SettingsDisplay.class);
		startActivity(i);
	}

	private void createTimers() {
		// go to the timers page, starts the Timers activity
		mDbHelper.close();
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		// go to the search page, starts the search activity
		mDbHelper.close();
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		// create the grocery list acitivty
		mDbHelper.close();
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		mDbHelper.close();
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		//i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}
	
	private class DrawView extends View {
		// this is the image that is created.  it has all of the buttons.
    	final public String imagecasedefault = "default";
    	final public String imagecasegrocery = "grocery";
    	final public String imagecookbook = "cookbook";
    	final public String imagerecipesearch = "recipesearch";
    	final public String imagecasesetting = "setting";
		private String imagecase;
    	public DrawView(Context context,float screenWidthtmp, float screenHeighttmp) {
			super(context);
			imagecase = "default";
    	}

    	protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			// figure out which image is being created.
			if (this.imagecase.equalsIgnoreCase(imagecasesetting)) {
				this.setBackgroundResource(R.drawable.mainsettingclicked);
			} else if (this.imagecase.equalsIgnoreCase(imagecasegrocery)) {
				this.setBackgroundResource(R.drawable.maingroceryclick);
			} else if (this.imagecase.equalsIgnoreCase(imagecookbook)){
				this.setBackgroundResource(R.drawable.maincookbookclicked);
			} else if (this.imagecase.equalsIgnoreCase(imagerecipesearch)){
				this.setBackgroundResource(R.drawable.mainrecipesearchclicked);
			} else {
				// go to default if not set.
				this.setBackgroundResource(R.drawable.maindefault);
			}
    	}
    }

	// create fields
	private final int Cookbook_ID = 0;
	private final int Grocerylist_ID = 1;
	private final int Search_ID = 2;
	private final int Timers_ID = 3;
	private final int Settings_ID = 4;
	private final int Planner_ID = 7;
	private static final int AboutChef_ID = 10;
	static final int Contact_ID = 11;
	private BackEndSQLite mDbHelper;
	private String UID;
	private String password;
}