package com.noblebug.chefpro.planner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;
import com.noblebug.chefpro.R;

public class rightarrow extends View {
	public Integer FrameSizeX;
	public Integer FrameSizeY;
	public Paint paint;
	
	public rightarrow(Context context)
    {
        super(context);
        paint=new Paint();
    }
    public rightarrow(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        paint=new Paint();
    }
    public rightarrow(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        paint=new Paint();
    }
	
    protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		int xstart = this.FrameSizeX*6/10-this.FrameSizeX/4; //0+5; // this value is really padding
		int ystart = this.getTop()+this.FrameSizeX/10;
		int width = this.FrameSizeX/2; 
		Point p1 = new Point(xstart, ystart); 
		Point p2 = new Point(p1.x, p1.y + width);
		Point p3 = new Point(p1.x + width, p1.y + (width / 2));
		Path path = new Path();
		path.moveTo(p1.x, p1.y);
		path.lineTo(p2.x, p2.y);
		path.lineTo(p3.x, p3.y);
		Paint p = new Paint();
		p.setStyle(Style.FILL);
		p.setColor(Color.rgb(66, 41, 10));
		canvas.drawPath(path, p);
	}
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
		this.setMeasuredDimension(FrameSizeX,FrameSizeY);
	} 

}