package com.noblebug.chefpro.tools;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.recipe.Recipe;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class NewUser extends Activity {

	// class is called for a new user.
	// it is currently called from the Cookbook Menu.
	// it logs in by checking chefslittleherlp.com, and 
	// sets default information for the user.
	// 4 June 2011


	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// fix phone to PORTRAIT mode, and remove TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		appState = ((ChefController) getApplicationContext());
		
		Ctx=this;
		
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		
		LinearLayout mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		
		// add Chef logo
		ImageView logo = new ImageView(this);
		logo.setImageResource(R.drawable.logo);
		mLinearLayout.addView(logo);
		
		// add text(s):
		TextView intro = new TextView(this);
		intro.setTextColor(Color.DKGRAY);
		intro.setText("Welcome to Chef.  Chef gives you access to your recipes " +
				"from your phone, allows you to search our database of over 13,000 " +
				"recipes, and easily create customized grocery lists with the touch of a button. " +
				"Build your own cookbook with the recipes you enter along with any of the recipes " +
				"other chefs have uploaded." +
				"You may be a new user.  Please enter your information below.");
		intro.setPadding(0, 10, 0, 5);
		mLinearLayout.addView(intro);
		
		// add Edittext username
		LinearLayout mInnerLayout1 = new LinearLayout(this);
		mInnerLayout1.setOrientation(LinearLayout.HORIZONTAL);
		TextView usertxt = new TextView(this);
		usertxt.setTextColor(Color.BLACK);
		usertxt.setGravity(Gravity.LEFT);
		usertxt.setText("Enter Username:  ");
		mInnerLayout1.addView(usertxt);
		txtusername = new EditText(this);
		txtusername.setPadding(0, 5, 0, 5);
		txtusername.setImeOptions(EditorInfo.IME_ACTION_NEXT);
		mInnerLayout1.addView(txtusername,new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
		mLinearLayout.addView(mInnerLayout1);
		
		// add passowrd put "Enter Password" Text next to password/Edit Text
		LinearLayout mInnerLayout2 = new LinearLayout(this);
		mInnerLayout2.setOrientation(LinearLayout.HORIZONTAL);
		TextView passtxt = new TextView(this);
		passtxt.setTextColor(Color.BLACK);
		passtxt.setGravity(Gravity.LEFT);
		passtxt.setText("Enter Password:  ");
		mInnerLayout2.addView(passtxt);
		txtpassword = new EditText(this);
		txtpassword.setPadding(0,5,0,5);
		txtpassword.setInputType(InputType.TYPE_CLASS_TEXT
				| InputType.TYPE_TEXT_VARIATION_PASSWORD);
		mInnerLayout2.addView(txtpassword,new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
		mLinearLayout.addView(mInnerLayout2);

		
		// add button
		btnaddnewuserinfo = new Button(this);
		btnaddnewuserinfo.setPadding(0, 5, 0, 5);
		btnaddnewuserinfo.setText("Login");
		mLinearLayout.addView(btnaddnewuserinfo);
		
		// add button
		btnnowebuser = new Button(this);
		btnnowebuser.setPadding(0, 5, 0, 5);
		btnnowebuser.setText("Click Here if you want to use Chef without loging in to the Webpage.");
		mLinearLayout.addView(btnnowebuser);
		
		// add scroller
		ScrollView myScroller = new ScrollView(this);
		myScroller.setBackgroundResource(R.drawable.grocerypaperbackground);
		myScroller.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		myScroller.setScrollbarFadingEnabled(true);
		myScroller.addView(mLinearLayout);
		
		setContentView(myScroller);
		
		btnnowebuser.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				username = "notUsingWeb";
				password = "notUsingWeb";
				Integer userid = -1;
				mDbHelper.addUserAppend(username, password, userid);
				// set default searchSettings
				mDbHelper.setDefaultSearchSettings(userid);
				Date myDate = new Date();
				mDbHelper.insertRecipeLastUpdateTime(userid, myDate.getTime()/1000);
				mDbHelper.insertStartingPage(String.valueOf(userid));
				mDbHelper.close();
				gotoChef();
			}
		});
		
		//btnaddnewuserinfo.setOnClickListener(myProgressBarShower);
		btnaddnewuserinfo.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(appState.check4InternetConnection(Ctx)) {
					String succesUserLogIn = getUserid(); // get the user id, checks user password
					if (succesUserLogIn.equalsIgnoreCase("good")) {
						progressBarUpdateRecipes(recipesAllnewuser);
					} else {
						if (appState.internetConnectionOpen==false) {
							//Toast.makeText(getBaseContext(),
							//		"This device does not appear to be connected to the internet.  To confirm " +
							//		"your account at www.chefslittlehelper.com, you need to be " +
							//		"connected to the internet.", Toast.LENGTH_LONG).show();
						} else {
							Toast.makeText(getBaseContext(),succesUserLogIn, Toast.LENGTH_LONG).show();
						}
					}
				}
			}
		});
	}
	
	public void bookmarkstoweb() {
		username = txtusername.getText().toString();
		username = username.replace(" ", "%20");      // may need to replace the space
		password = txtpassword.getText().toString();
		MD5Hash myMD5hasher = new MD5Hash();
		String md5password = myMD5hasher.getMd5Hash(password);
		BackEndPHPHandler myPHPhandler = new BackEndPHPHandler();
		String useridResult = myPHPhandler.uidResult.trim();
		Integer userid = Integer.valueOf(useridResult.replace("^^","%%%").split("%%%")[1]);
		// now send bookmarks to web:
		List<Integer> recipeIDs_bookmarked = mDbHelper.getAllRecipesNotThisUser(userid);
		myPHPhandler.bookmarkstoweb(userid, recipeIDs_bookmarked , md5password);
	}
	
	
	OnClickListener myProgressBarShower = new OnClickListener(){
		// @Override
		public void onClick(View arg0) {
			appState.check4InternetConnection(Ctx);
			if(appState.internetConnectionOpen==true) {
				myProgressDialog = ProgressDialog.show(NewUser.this,	
						"Please wait...", "Logging you in", true);
				new Thread() {
					public void run() {
						try{
							Looper.prepare();
							// call everything:
							getUserid();
							Looper.myLooper().quit();
							Looper.loop();
							Looper.myLooper().quit();
						} catch (Exception e) {	
							e.printStackTrace();
						}
						// Dismiss the Dialog 
						myProgressDialog.dismiss();
					}
				}.start();
			} else {
				Toast.makeText(getBaseContext(),
						"This device does not appear to be connected to the internet.  To confirm " +
						"your account at www.chefslittlehelper.com, you need to be " +
						"connected to the internet.", Toast.LENGTH_LONG).show();
			}
		}
	};
	private int increment;
	
	
	private void getAllRecipesForUserFromChef() {
		// this method should get all of the recipes for the current user, who just logged in.
		// get recipes regardless of time, and should be done every time a user logs in.
		appState.check4InternetConnection(Ctx);
		if (appState.internetConnectionOpen==true) {	
				if (mDbHelper==null) {
					mDbHelper = new BackEndSQLite(this);
				}
				if (!mDbHelper.isDatabaseOpen) {
					mDbHelper.open();
				}
				
				//Integer[] recipeIDs = mDbHelper.getAllRecipesCookbook();
				// get md5password
				MD5Hash myMD5hasher = new MD5Hash();
				String md5password = myMD5hasher.getMd5Hash(password);
				// get time since last update
				Long recipeLastUpdateTime = mDbHelper.getRecipeLastUpdateTime(Integer.valueOf(UID)); // should be in user settings
				// send to PHP:
				BackEndPHPHandler myPHPHandler2 = new BackEndPHPHandler();
				myPHPHandler2.syncAllCookbook(UID,md5password,recipeLastUpdateTime);

				recipesAllnewuser = myPHPHandler2.recipesAll;
				
				mDbHelper.updateRecipeLastUpdateTime(Integer.valueOf(UID), myPHPHandler2.lastupdateTime);
		} else {
			Toast.makeText(getBaseContext(), "This device does not appear to be connected to the internet.",
					Toast.LENGTH_LONG).show();
		}
	}

	private void progressBarUpdateRecipes(final List<Integer> recipesNeedUpdating) {
		myProgressDialog = new ProgressDialog(this);
		myProgressDialog.setCancelable(true);
		myProgressDialog.setMessage("Downloading recipes ... ");
		// set the progress to be horizontal
		myProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        // reset the bar to the default value of 0
		myProgressDialog.setProgress(0);
        // get the maximum value
        // convert the text value to a integer
        final int maximum = recipesNeedUpdating.size();
        increment = 1;
        // set the maximum value
        myProgressDialog.setMax(maximum);
        // display the progressbar
        myProgressDialog.show();
        // create a thread for updating the progress bar
        Thread background = new Thread (new Runnable() {
           public void run() {
               // enter the code to be run while displaying the progressbar.
			   //
			   // This example is just going to increment the progress bar:
			   // So keep running until the progress value reaches maximum value
			   // while (myProgressDialog.getProgress()<= myProgressDialog.getMax()) {
        	   Looper.prepare();
        	   for (int i=0;i<maximum;i++) {
        	   		int recipeidtmp = (int) recipesNeedUpdating.get(i);
        	   		Iterator<Integer> it = recipesNeedUpdating.iterator();
				   //while (it.hasNext()) {
				   // first want to delete entire recipe to avoid problems:
        	   		//System.out.println("***** NewUser::progressBarUpdateRecipes recipeidtmp="+String.valueOf(recipeidtmp));
        	   		if (!mDbHelper.isDatabaseOpen) {
        	   			mDbHelper.open();
        	   		}
				   mDbHelper.deleteRecipe(recipeidtmp);
				   // then add the updated recipe
				   addRecipe2Cookbook(recipeidtmp,Integer.valueOf(UID));
				   progressHandler.sendMessage(progressHandler.obtainMessage());
			   }
			   Looper.myLooper().quit();
				Looper.loop();
				Looper.myLooper().quit();
				myProgressDialog.dismiss();
			   gotoChef();
           }
        });
        // start the background thread
        background.start();
	}
	// handler for the background updating
    Handler progressHandler = new Handler() {
        public void handleMessage(Message msg) {
        	myProgressDialog.incrementProgressBy(increment);
        }
    };
	
	
	private String getUserid(){
		// get strings and add to database
		String userlogedin = "error";
		username = txtusername.getText().toString();
		username = username.replace(" ", "%20");      // may need to replace the space
		password = txtpassword.getText().toString();
		MD5Hash myMD5hasher = new MD5Hash();
		String md5password = myMD5hasher.getMd5Hash(password);
		BackEndPHPHandler myPHPhandler = new BackEndPHPHandler();
		myPHPhandler.validateuser(username, md5password);
		String useridResult = myPHPhandler.uidResult.trim();
		if(useridResult.equalsIgnoreCase("Invalid user")==true ){
			Toast.makeText(getBaseContext(), "Invalid UserName/Password",
					Toast.LENGTH_LONG).show();
			userlogedin = "Invalid user";
		} else if (useridResult.equalsIgnoreCase("Incorrect password.")==true) {
			Toast.makeText(getBaseContext(), "Incorrect password.",
					Toast.LENGTH_LONG).show();
			userlogedin = "Incorrect password.";
		}else {
		//if (useridResult.replace("^^","%%%").split("%%%").length>1) {
			userlogedin = "good";
			Integer userid = Integer.valueOf(useridResult.replace("^^","%%%").split("%%%")[1]);
			UID = String.valueOf(userid);
			if (!mDbHelper.isDatabaseOpen){
				mDbHelper.open();
			}
			mDbHelper.addUserSingle(username, password, userid, md5password);
			// set default searchSettings
			// set default searchSettings
			mDbHelper.setDefaultSearchSettings(userid);
			// default Aisle list
			appState.setDefaultAisleList();
			// write default Aislist to Database:
			mDbHelper.updateAislelist(Integer.valueOf(UID),appState.getAisleList());
			Date myDate = new Date();
			mDbHelper.insertRecipeLastUpdateTime(userid, myDate.getTime()/1000);
			mDbHelper.insertStartingPage(UID);
			mDbHelper.setWakeLockInitial(UID);
			mDbHelper.close();
			//mDbHelper.setWakeLock(UID,1);
			// user may have a NEW phone, but be an OLD chef user.
			// so download everything in the syncCookbookroutine:
			getAllRecipesForUserFromChef(); 
			
			//sync planner on web and phone
			syncPlannerWebPhone(userid,md5password);
		} 
		return userlogedin;
	}
	
	private void syncPlannerWebPhone(int userid, String md5password) {
		//sync planner on web and phone.
		// do it in this order 
		// 1) get list of meals in phone 
		// 2) query web for meals 
		// 3) add phone meals to web 
		// 4) add web meals to collection  
		// 5) add all meals to phone
		
		// Get meals from phone 
		mDbHelper.open();
		List allmeals = mDbHelper.getAllMeals(-1); // the userid is now new
		//System.out.println("***** Chef.NewUser syncPlannerWebPhone allmeals.size = "+allmeals.size());
		
		
		// get meals from web result, added later
		// need to get all months and years
		String resultPHP = "";
		BackEndPHPHandler myPHP = new BackEndPHPHandler();
		Calendar _calendar = Calendar.getInstance(Locale.getDefault());
		int year_now = _calendar.get(Calendar.YEAR);
		for (int year=year_now ; year<year_now+1 ; year++) { 
			for (int month=0 ; month<12 ; month++) {
				String resulttmp = myPHP.getMealByMonth(String.valueOf(userid), year, month);  //parsedDate); // return a list of meals at this month
				if (resulttmp.equalsIgnoreCase("None")==false) {
					resultPHP = resultPHP + "<br>" + resulttmp;
					//System.out.println("***** Chef.NewUser syncPlannerWebPhone resulttmp = " +resulttmp);
					//System.out.println("***** Chef.NewUser syncPlannerWebPhone resultPHP = "+resultPHP);
				}
			}
		}
		
		// meals from phone to web
		// in this case we are creating a new meal so pass nodeid=-1.
		// format:  36424%%%%18678%%%%Chicken & Broccoli Casserole or (Make your own casserole)%%%%Dinner%%%%2012-07-12
		Iterator myIt = allmeals.iterator();
		while (myIt.hasNext()) {
			String mealHere = (String) myIt.next();
			int recipeid = Integer.valueOf(mealHere.split("%%%%")[1]);
			String type = mealHere.split("%%%%")[3];
			String YYYYMMDD = mealHere.split("%%%%")[4];
			//System.out.println("***** Chef.NewUser syncPlannerWebPhone userid, md5password, recipeid, type, YYYYMMDD, username = "+userid+" "+ md5password+" "+ recipeid+" "+ type+" "+ YYYYMMDD+" "+ username);
			myPHP.addRecipe2Calendar(userid, md5password, -1, recipeid, type, YYYYMMDD, username);
		}		
		
		// Add PHP results to list:
		if(resultPHP.equalsIgnoreCase("None")==false) {
			String[] tmps = resultPHP.split("<br>");
			for (int i=0;i<tmps.length;i++){
				// item format:  36424^^18678^^Chicken & Broccoli Casserole or (Make your own casserole)^^Dinner^^2012-07-12
				String item = tmps[i].replace("^^", "%%%%");
				//System.out.println("***** Chef.NewUser syncPlannerWebPhone tmps = "+tmps);
				//System.out.println("***** Chef.NewUser syncPlannerWebPhone item  = "+item);
				if (allmeals.contains(item)==false) {
					// this meal not yet added so add (not sure how this comes up but.. just checking
					allmeals.add(item);
				}
			}
		}
	
		
		// add web meals to phone.
		myIt = allmeals.iterator();
		while (myIt.hasNext()) {
			String mealHere = (String) myIt.next();
			//System.out.println("***** Chef.NewUser syncPlannerWebPhone mealhere = "+mealHere);
			mDbHelper.manageMeals(mealHere, userid,"new");   // want these to be peristen.
		}

		mDbHelper.close();		
	}

	private void gotoChef() {
		mDbHelper.close();
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}
	
	private void addRecipe2Cookbook( Integer recipeid, Integer userid) {
		// add this recipe ID to the Cookbook in the mDbHelper2 database.
		// database mDbHelper2 shoudl already be open, and closed later
		BackEndPHPHandler myPHP3 = new BackEndPHPHandler();
		try {
			//System.out.println("****** NewUser::addRecipe2Cookbook recipeid="+String.valueOf(recipeid)+" userid="+String.valueOf(userid));
			myPHP3.fetchStringRecipe(recipeid, userid);
			//Why is this Toast here.  Toast.makeText(getBaseContext(), myPHP3.contentsStringRecipe,
			//		Toast.LENGTH_LONG).show();
			Recipe recipe2Update = myPHP3.RecipeFromFetchString;
			recipe2Update.partofcookbook=0;
			// download the image(s) chef or recipe image:
			downloadImages(recipe2Update, mDbHelper);
			if (mDbHelper.hasRecipeBYId(recipe2Update.recipeid)==true) {
				mDbHelper.updateRecipe(recipe2Update);
			} else {
				// ADD the recipe
				mDbHelper.addRecipe(recipe2Update);
			}
		} catch (Exception ex) {
			// maybe the recipe bombs
			ex.printStackTrace();
			String comment = "::from NewUser.addRecipe2Cookbook could not dowload recipeid:: "+recipeid+" ::contentsStringRecipe:"+myPHP3.contentsStringRecipe;
    		String priority = "WARNING";
    		myPHP3.exceptionlog(userid,comment,priority);
		}
	}
	
	public void downloadImages(Recipe recipehere, BackEndSQLite mDbHelper2) {
		// this method downloads (if needed) the recipe image and chef image
		if (recipehere.Imagehttp.startsWith("http")==true) {
			// download file
			if (appState.internetConnectionOpen==true) {
				ImageHandler myImgHandler = new ImageHandler();
				myImgHandler.downloadFile(recipehere.Imagehttp);
				recipehere.PictureNameOnDisk = myImgHandler.imagename;
			} else {
				Toast.makeText(getBaseContext(), "This device may not be connected to the internet",
						Toast.LENGTH_SHORT).show();
			}
		} else {
			// no image with this recipe, dont download.
			recipehere.PictureNameOnDisk=null;
		}
		//
		// get chef image if needed:
		// cannot check if a particular recipe has its chefimagedownloaded because
		// one chef can have multiple recipes.  so check database for recipes that have
		// that chef AND have it downloaded:
		if(mDbHelper2.chefImageDownaloded(recipehere.chefname)==false) {
			// chef image not downloaded so downloaded.
			if (appState.internetConnectionOpen==true) {
				ImageHandler myImgHandler = new ImageHandler();
				//String urlString = "http://www.chefslittlehelper.com/sites/default/files/pictures/picture-???.jpg";
				//urlString = urlString.replace("???", String.valueOf(recipehere.user));
				String answer=myImgHandler.downloadChefImage(recipehere.user);
				if (answer.equals("None")) {
					// no image
					recipehere.chefimagedownloaded=1;
					recipehere.chefimagename="None";
				} else {
					recipehere.chefimagedownloaded=0;
					recipehere.chefimagename = answer;
				}
			} else {
				// no open connection
				Toast.makeText(getBaseContext(), "This device may not be connected to the internet",
						Toast.LENGTH_SHORT).show();
				recipehere.chefimagedownloaded=1;
			}
		} else {
			recipehere.chefimagedownloaded=0;
		}
	}
	
	// fields:
	private Button btnaddnewuserinfo;
	private EditText txtusername;
	private EditText txtpassword;
	public String username;
	public String password;
	public String UID;
	private BackEndSQLite mDbHelper;
	private EditText txtuserid;
	ProgressDialog myProgressDialog = null;
	private Context Ctx;
	List<Integer> recipesAllnewuser = null;
	private ChefController appState;
	private Button btnnowebuser;
	private boolean userLoggedInSuccess = false;
}
