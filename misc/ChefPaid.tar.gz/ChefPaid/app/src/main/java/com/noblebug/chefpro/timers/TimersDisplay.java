package com.noblebug.chefpro.timers;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.planner.Planner;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.settings.AboutChef;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.os.PowerManager;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class TimersDisplay extends Activity {

	// This activity displays 4 timers.  It is not well written.
	// The functionality is interwoven in a complicated way that 
	// makes it difficult to update.  The functionality is okay.
	// Currently, 4 June 20111, it displays four timers, flashes when 
	// finished, flashes when it starts.  The user will recieve a 
	// toast message and Service when finished.
	// 4 june 2011, Jim Pizagno
	

	private BackEndSQLite mDbHelper;
	private String userid;
	public TimersDisplay() {
		mCtx = this;
	}

	// this displays a timer.
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// try wake lock:
		// open DB
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		// get userID:
		String[] temp = mDbHelper.getUserSingle();
		userid = temp[3];
		try {
			//
			if(mDbHelper.getWakeLockState(userid)) {
				PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
				wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
				Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
			}
		} catch (Exception e) {
			mDbHelper.setWakeLockInitial(userid);
	        e.printStackTrace();
	    }
		//if(mDbHelper.getWakeLockState(userid)) {
		//	PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		//	wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
		//	Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
		//}
		// close DB:
		mDbHelper.close();
		
		mMediaPlayer1 = new MediaPlayer();
		mMediaPlayer2 = new MediaPlayer();
		mMediaPlayer3 = new MediaPlayer();
		mMediaPlayer4 = new MediaPlayer();
		
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		Display display = getWindowManager().getDefaultDisplay();
		screen_width = display.getWidth();
		screen_height = display.getHeight();
		
		// make timer buttons:
		// (Context context, int screenWidth, int screenHeight, String itemtmp, String timetmp)
		timerbutton1 = new TimerButton(this,screen_width,screen_height,"item","00:00:00");
		timerbutton1.setBackgroundInt(R.drawable.timer);
		timerbutton2 = new TimerButton(this,screen_width,screen_height,"item","00:00:00");
		timerbutton2.setBackgroundInt(R.drawable.timer);
		timerbutton3 = new TimerButton(this,screen_width,screen_height,"item","00:00:00");
		timerbutton3.setBackgroundInt(R.drawable.timer);
		timerbutton4 = new TimerButton(this,screen_width,screen_height,"item","00:00:00");
		timerbutton4.setBackgroundInt(R.drawable.timer);
		
		// get appState
		appState = ((ChefController) getApplicationContext());
		
		// get Timers information
		setupTimer(1);
		setupTimer(2);
		setupTimer(3);
		setupTimer(4);
		
		// setup clicklistener for timerbutton1
		timerbutton1.setClickable(true);
		//timerbutton1.setOnTouchListener(myThread1);
		timerbutton1.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
		            {
						float x = ev.getX();
						float y = ev.getY();
						if (timerbutton1.time.equalsIgnoreCase("00:00:00")==true |
								timerbutton1.time.equalsIgnoreCase("done!")==true) {  
							// no longer ticking so automatically go to TimerEdit
							timerEditActivity(1);
						} else  {
							// figure out what to do:  Edit(x<0.75*screenSize) or Pause
							if (x > (float)screen_width*0.75 ) {
								//text = "edit";
								timerEditActivity(1);
							} else {
								if(timerbutton1.time.equalsIgnoreCase("00:00:00")==false) {
									if (stillticking.get(1)==true){
										// timer still ticking. so now pause
										stillticking.put(1,false);
										//text = "cancel";
										counter1.cancel();
										// update appstate
										// give time back to controller
										appState.setTimer1time(counter1.MillisecondsTillDone, 
												datemillisec.get(1), stillticking.get(1), timerbutton1.item);
										myServiceTest1.stopservice("paused");
										myServiceTest1.stillticking=false;
										timerbutton1.setBackgroundInt(R.drawable.timer);
										timerbutton1.invalidate();
									} else {
										timerbutton1.setBackgroundInt(R.drawable.timerdepressed);
										timerbutton1.invalidate();
										counter1.cancel();
										//text = "restart";
										// get info from controller:
										String temp = appState.getTimer1timeDate1();
										stillticking.put(1, Boolean.valueOf(temp.split("::")[2]));
										timermillisec.put(1,Long.valueOf(temp.split("::")[0]));
										datemillisec.put(1,Long.valueOf(temp.split("::")[1]));
										item.put(1, temp.split("::")[3]);
										startCounter1(timermillisec.get(1));
										stillticking.put(1, true);
										myServiceTest1.MillisecondsTillDone=timermillisec.get(1);
										myServiceTest1.item=temp.split("::")[3];
										myServiceTest1.stillticking=true;
									}	
									//Toast.makeText(getBaseContext(), text, Toast.LENGTH_SHORT).show();
								} //end if(HHMMSS=false
							} // end(x > (float)screen_width*0.75)
						}
		            }
		        }
		        return true;
			}
		});

		// setup clicklistener for timerbutton2
		timerbutton2.setClickable(true);
		timerbutton2.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
		            {
						float x = ev.getX();
						float y = ev.getY();
						if (timerbutton2.time.equalsIgnoreCase("00:00:00")==true |
								timerbutton2.time.equalsIgnoreCase("done!")==true) {  
							// no longer ticking so automatically go to TimerEdit
							timerEditActivity(2);
						} else  {
							if (x > (float)screen_width*0.75 ) {
								//text = "edit";
								timerEditActivity(2);
							} else {
								if(timerbutton2.time.equalsIgnoreCase("00:00:00")==false) {
									if (stillticking.get(2)==true){
										stillticking.put(2,false);
										//text = "cancel";
										counter2.cancel();
										// update appstate
										// give time back to controller
										appState.setTimer2time(counter2.MillisecondsTillDone, 
												datemillisec.get(2), stillticking.get(2), timerbutton2.item);
										myServiceTest2.stopservice("paused");
										myServiceTest2.stillticking=false;
										timerbutton2.setBackgroundInt(R.drawable.timer);
										timerbutton2.invalidate();
									} else {
										timerbutton2.setBackgroundInt(R.drawable.timerdepressed);
										timerbutton2.invalidate();
										counter2.cancel();
										//text = "restart";
										// get info from controller:
										String temp = appState.getTimer2timeDate2();
										stillticking.put(2, Boolean.valueOf(temp.split("::")[2]));
										timermillisec.put(2,Long.valueOf(temp.split("::")[0]));
										datemillisec.put(2,Long.valueOf(temp.split("::")[1]));
										item.put(2, temp.split("::")[3]);
										startCounter2(timermillisec.get(2));
										stillticking.put(2, true);
										myServiceTest2.MillisecondsTillDone=timermillisec.get(2);
										myServiceTest2.item=temp.split("::")[3];
										myServiceTest2.stillticking=true;
									}	
									//Toast.makeText(getBaseContext(), text, Toast.LENGTH_SHORT).show();
								} //end if(HHMMSS=false
							} // end(x > (float)screen_width*0.75)
						}
		            }
		        }
		        return true;
			}
		});
		// setup clicklistener for timerbutton2
		timerbutton3.setClickable(true);
		timerbutton3.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
		            {
						float x = ev.getX();
						float y = ev.getY();
						if (timerbutton3.time.equalsIgnoreCase("00:00:00")==true |
								timerbutton3.time.equalsIgnoreCase("done!")==true) {  
							// no longer ticking so automatically go to TimerEdit
							timerEditActivity(3);
						} else  {
							if (x > (float)screen_width*0.75 ) {
								//text = "edit";
								timerEditActivity(3);
							} else {
								if(timerbutton3.time.equalsIgnoreCase("00:00:00")==false) {
									if (stillticking.get(3)==true){
										stillticking.put(3,false);
										//text = "cancel";
										counter3.cancel();
										// update appstate
										// give time back to controller
										appState.setTimer3time(counter3.MillisecondsTillDone, 
												datemillisec.get(3), stillticking.get(3), timerbutton3.item);
										myServiceTest3.stopservice("paused");
										myServiceTest3.stillticking=false;
										timerbutton3.setBackgroundInt(R.drawable.timer);
										timerbutton3.invalidate();
									} else {
										timerbutton3.setBackgroundInt(R.drawable.timerdepressed);
										timerbutton3.invalidate();
										counter3.cancel();
										//text = "restart";
										// get info from controller:
										String temp = appState.getTimer3timeDate3();
										stillticking.put(3, Boolean.valueOf(temp.split("::")[2]));
										timermillisec.put(3,Long.valueOf(temp.split("::")[0]));
										datemillisec.put(3,Long.valueOf(temp.split("::")[1]));
										item.put(3, temp.split("::")[3]);
										startCounter3(timermillisec.get(3));
										stillticking.put(3, true);
										myServiceTest3.MillisecondsTillDone=timermillisec.get(3);
										myServiceTest3.item=temp.split("::")[3];
										myServiceTest3.stillticking=true;
									}	
									//Toast.makeText(getBaseContext(), text, Toast.LENGTH_SHORT).show();
								} //end if(HHMMSS=false
							} // end(x > (float)screen_width*0.75)
						}
		            }
		        }
		        return true;
			}
		});
		// setup clicklistener for timerbutton2
		timerbutton4.setClickable(true);
		timerbutton4.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
		            {
						float x = ev.getX();
						float y = ev.getY();
						if (timerbutton4.time.equalsIgnoreCase("00:00:00")==true |
								timerbutton4.time.equalsIgnoreCase("done!")==true) {  
							// no longer ticking so automatically go to TimerEdit
							timerEditActivity(4);
						} else  {
							if (x > (float)screen_width*0.75 ) {
								//text = "edit";
								timerEditActivity(4);
							} else {
								if(timerbutton4.time.equalsIgnoreCase("00:00:00")==false) {
									if (stillticking.get(4)==true){
										stillticking.put(4,false);
										//text = "cancel";
										counter4.cancel();
										// update appstate
										// give time back to controller
										appState.setTimer4time(counter4.MillisecondsTillDone, 
												datemillisec.get(4), stillticking.get(4), timerbutton4.item);
										myServiceTest4.stopservice("paused");
										myServiceTest4.stillticking=false;
										timerbutton4.setBackgroundInt(R.drawable.timer);
										timerbutton4.invalidate();
									} else {
										timerbutton4.setBackgroundInt(R.drawable.timerdepressed);
										timerbutton4.invalidate();
										counter4.cancel();
										//text = "restart";
										// get info from controller:
										String temp = appState.getTimer4timeDate4();
										stillticking.put(4, Boolean.valueOf(temp.split("::")[2]));
										timermillisec.put(4,Long.valueOf(temp.split("::")[0]));
										datemillisec.put(4,Long.valueOf(temp.split("::")[1]));
										item.put(4, temp.split("::")[3]);
										startCounter4(timermillisec.get(4));
										stillticking.put(4, true);
										myServiceTest4.MillisecondsTillDone=timermillisec.get(4);
										myServiceTest4.item=temp.split("::")[3];
										myServiceTest4.stillticking=true;
									}	
									//Toast.makeText(getBaseContext(), text, Toast.LENGTH_SHORT).show();
								} //end if(HHMMSS=false
							} // end(x > (float)screen_width*0.75)
						}
		            }
		        }
		        return true;
			}
		});
		
		
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT));
		
		// add Title
		TitleView myTitle = new TitleView(this,R.drawable.timersheader,
				this.getWindowManager().getDefaultDisplay().getWidth(),
				this.getWindowManager().getDefaultDisplay().getHeight());
		mLinearLayout.addView(myTitle);
		
		// add Timerbutton views:
		// left right top bottom
		int maxHeight = screen_height * 1/50;
		TextView myPadding1 = new TextView(this);
		myPadding1.setMaxHeight(maxHeight*2);
		mLinearLayout.addView(myPadding1);
		mLinearLayout.addView(timerbutton1);
		TextView myPadding2 = new TextView(this);
		myPadding2.setMaxHeight(maxHeight);
		mLinearLayout.addView(myPadding2);
		mLinearLayout.addView(timerbutton2);
		TextView myPadding3 = new TextView(this);
		myPadding3.setMaxHeight(maxHeight);
		mLinearLayout.addView(myPadding3);
		mLinearLayout.addView(timerbutton3);
		TextView myPadding4 = new TextView(this);
		myPadding4.setMaxHeight(maxHeight);
		mLinearLayout.addView(myPadding4);
		mLinearLayout.addView(timerbutton4);
	
		ScrollView scroller = new ScrollView(this);
		scroller.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		scroller.setScrollbarFadingEnabled(true);
		scroller.setBackgroundResource(R.drawable.timerbackground);
		// put linearlayout in scroller view
		scroller.addView(mLinearLayout);
		// Add the scroller (with mLinearLayout inside) to Activity
		setContentView(scroller);
	}

	
	private void setupTimer(int timeri) {
		// this method sets up the timers. and is called at onCreate() and maybe at later times
		// get the timer info from the controller:
		String temp = null;  //"0::0::flase::fail";
		if(timeri==1) {
			temp = appState.getTimer1timeDate1();
			stillticking.put(1, Boolean.valueOf(temp.split("::")[2]));
			timermillisec.put(1, Long.valueOf(temp.split("::")[0]));
			myServiceTest1 = new BackgroundService(this, timermillisec.get(1), temp.split("::")[3], 1);
		}
		if(timeri==2) {
			temp = appState.getTimer2timeDate2();
			stillticking.put(2, Boolean.valueOf(temp.split("::")[2]));
			timermillisec.put(2, Long.valueOf(temp.split("::")[0]));
			myServiceTest2 = new BackgroundService(this, timermillisec.get(2), temp.split("::")[3], 2);
		}
		if(timeri==3) {
			temp = appState.getTimer3timeDate3();
			stillticking.put(3, Boolean.valueOf(temp.split("::")[2]));
			timermillisec.put(3, Long.valueOf(temp.split("::")[0]));
			myServiceTest3 = new BackgroundService(this, timermillisec.get(3), temp.split("::")[3], 3);
		}
		if(timeri==4) {
			temp = appState.getTimer4timeDate4();
			stillticking.put(4, Boolean.valueOf(temp.split("::")[2]));
			timermillisec.put(4, Long.valueOf(temp.split("::")[0]));
			myServiceTest4 = new BackgroundService(this, timermillisec.get(4), temp.split("::")[3], 4);
		}
		
		
		if (stillticking.get(timeri)==false){             
			// may be PAUSED or may be null here.
			if (timermillisec.get(timeri)==(long)0.0) { // null
				timermillisec.put(timeri, (long) 0.0);
				datemillisec.put(timeri, (long) 0.0);
				item.put(timeri, "item");
			} else {  // paused
				datemillisec.put(timeri, Calendar.getInstance().getTimeInMillis());
				item.put(timeri, temp.split("::")[3]);
				if (timeri==1) {
					timerbutton1.item = item.get(timeri);
					timerbutton1.time = longtime2Stringtime(timermillisec.get(timeri));
					counter1 = new OneCounter(timermillisec.get(timeri), 1000, 1);
					myServiceTest1 = new BackgroundService(this, timermillisec.get(timeri), item.get(timeri), timeri);
				}
				if (timeri==2) {
					timerbutton2.item = item.get(timeri);
					timerbutton2.time = longtime2Stringtime(timermillisec.get(timeri));
					counter2 = new OneCounter(timermillisec.get(timeri), 1000, 2);
					myServiceTest2 = new BackgroundService(this, timermillisec.get(timeri), item.get(timeri), timeri);
				}
				if (timeri==3) {
					timerbutton3.item = item.get(timeri);
					timerbutton3.time = longtime2Stringtime(timermillisec.get(timeri));
					counter3 = new OneCounter(timermillisec.get(timeri), 1000, 3);
					myServiceTest3 = new BackgroundService(this, timermillisec.get(timeri), item.get(timeri), timeri);
				}
				if (timeri==4) {
					timerbutton4.item = item.get(timeri);
					timerbutton4.time = longtime2Stringtime(timermillisec.get(timeri));
					counter4 = new OneCounter(timermillisec.get(timeri), 1000, 4);
					myServiceTest4 = new BackgroundService(this, timermillisec.get(timeri), item.get(timeri), timeri);
				}
			}
		} else {
			timermillisec.put(timeri, Long.valueOf(temp.split("::")[0]));
			datemillisec.put(timeri, Long.valueOf(temp.split("::")[1]));
			item.put(timeri,temp.split("::")[3]);
		}
		// check is still ticking
		if(stillticking.get(timeri)==true){
			// check if time has passed.  get current time.
			// it may have been stopped, and controller (which has time) and elapsed time may be different
			Long currentdate = Calendar.getInstance().getTimeInMillis();
			Long diff = datemillisec.get(timeri) + timermillisec.get(timeri) - currentdate;

			// set myDrawView fields:
			if(timeri==1) {
				timerbutton1.item = item.get(timeri);
			}
			if(timeri==2) {
				timerbutton2.item = item.get(timeri);
			}
			if(timeri==3) {
				timerbutton3.item = item.get(timeri);
			}
			if(timeri==4) {
				timerbutton4.item = item.get(timeri);
			}
			
			if (diff<=(long)0.0) {  // time passed, timer should have rung
				// already went off
				// message time passes for timer1
				if (timeri==1) {
					message(1);
					// reset to zero
					appState.setTimer1time((long)0.0, (long)0.0, false,timerbutton1.item);
				}
				if (timeri==2) {
					message(2);
					// reset to zero
					appState.setTimer2time((long)0.0, (long)0.0, false,timerbutton2.item);
				}
				if (timeri==3) {
					message(3);
					// reset to zero
					appState.setTimer3time((long)0.0, (long)0.0, false,timerbutton3.item);
				}
				if (timeri==4) {
					message(4);
					// reset to zero
					appState.setTimer4time((long)0.0, (long)0.0, false,timerbutton4.item);
				}
				
			} else { // still time left
				//calc current time.  should be just diff
				if (timeri==1) {
					this.startCounter1(diff);
				}
				if (timeri==2) {
					this.startCounter2(diff);
				}
				if (timeri==3) {
					this.startCounter3(diff);
				}
				if (timeri==4) {
					this.startCounter4(diff);
				}
			}
		} // else do nothing!
	}

	private String longtime2Stringtime(Long timer1millisec2) {
		String returnString = "returnfailed";
		long secs =timer1millisec2 / 1000;
		long hours = secs / 3600, remainder = secs % 3600, minutes = remainder / 60, seconds = remainder % 60;
		String disHour = (hours < 10 ? "0" : "") + hours, disMinu = (minutes < 10 ? "0"
				: "")
				+ minutes, disSec = (seconds < 10 ? "0" : "") + seconds;

		returnString = disHour + ":" + disMinu + ":" + disSec;
		return returnString;
	}

	@Override
	protected void onResume() {
	super.onResume();
		if (wl==null) {
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			// get userID:
			String[] temp = mDbHelper.getUserSingle();
			userid = temp[3];
			if(mDbHelper.getWakeLockState(userid)) {
				PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
				wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
				Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
			}
			// close DB:
			mDbHelper.close();
		} else {
			wl.acquire();
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (wl==null) {
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			// get userID:
			String[] temp = mDbHelper.getUserSingle();
			userid = temp[3];
			if(mDbHelper.getWakeLockState(userid)) {
				PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
				wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
				wl.release();
				Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
			}
			// close DB:
			mDbHelper.close();
		} else {
			wl.release();
		}
		mMediaPlayer1 = null;
		mMediaPlayer2 = null;
		mMediaPlayer3 = null;
		mMediaPlayer4 = null;
		// stop current timer
		// may not be instantiated
		// we can stop them b/c controller remembers everything
		if(counter1!=null){
			//counter1.cancel();
		}
		if(counter2!=null){
			//counter2.cancel();
		}
		if(counter3!=null){
			//counter3.cancel();
		}
		if(counter4!=null){
			//counter4.cancel();
		}
	}
	@Override
	protected void onStop() {
		super.onStop();
		//wl.release();
		mMediaPlayer1 = null;
		mMediaPlayer2 = null;
		mMediaPlayer3 = null;
		mMediaPlayer4 = null;
		// stop current timer
		// may not be instantiated
		if(counter1!=null){
			//counter1.cancel();
		}
		if(counter2!=null){
			//counter2.cancel();
		}
		if(counter3!=null){
			//counter3.cancel();
		}
		if(counter4!=null){
			//counter4.cancel();
		}
	}
	
	protected void timerEditActivity(int timerint) {
		// cancel all timer's because they are saved in Chefcontroller
		if(counter1!=null){
			counter1.cancel();
		}
		if(counter2!=null){
			counter2.cancel();
		}
		if(counter3!=null){
			counter3.cancel();
		}
		if(counter4!=null){
			counter4.cancel();
		}
		
		// timerint = 1,2,3,4 for one of timer
		// call timer editor class. activityforResult()
		// upon result resume time
		// call timeredit
		Intent i = new Intent(this, TimerEdit.class);
		String item = "broken at timerEditActivity";
		String time = "broken at timerEditActiivty";
		if(timerint==1){
			item = timerbutton1.item;
			time = timerbutton1.time;
		}
		if(timerint==2){
			item = timerbutton2.item;
			time = timerbutton2.time;
		}
		if(timerint==3){
			item = timerbutton3.item;
			time = timerbutton3.time;
		}
		if(timerint==4){
			item = timerbutton4.item;
			time = timerbutton4.time;
		}

		i.putExtra("time", time);
		i.putExtra("item", item);
		i.putExtra("timerint", timerint);
		startActivityForResult(i, timerint);
	}

	private class TimerButton extends View {
		// this class builds the graphics for the timer
		private Integer height;
		private Integer width;
		private String item = "item";
		private String time = "00:00:00";
		private Paint painttime;
		private Paint painttext;
		private int xstart_item;
		private int ystart_item;
		private int xstart_time;
		private int ystart_time;
		private int backgroundint;
		private float chevronleft;
		private float chevrontop;
		private Bitmap chevronbitmap;
		
		
		
		// constructor
		public TimerButton(Context context, int screenWidth, int screenHeight, String itemtmp, String timetmp) {
			super(context);
			// add info
			width = screenWidth *  1;
			height = screenHeight /6;
			time=timetmp;
			item=itemtmp;
			xstart_item = width * 5 / 100;
			ystart_item = height * 60/100;
			xstart_time = width * 40 / 100; 
			ystart_time = height * 60/100; 
			painttext = new Paint();
			painttext.setColor(Color.BLACK);
			painttext.setFakeBoldText(true);
			// phone: Size=50 good for 848pix screen
			// emlator: 18
			if (screen_height>600) {  
				// this If()else statement accounts for devices with different sizes
				painttext.setTextSize(36);
			} else {
				painttext.setTextSize(18);
			}
			painttext.setAntiAlias(true);

			painttime = new Paint();
			painttime.setColor(Color.BLACK);
			painttime.setFakeBoldText(true);
			if (screen_height>600) {
				painttime.setTextSize(36);
			} else  {
				painttime.setTextSize(18);
			}
			painttime.setAntiAlias(true);
			
			// define chevron params
			chevronleft = (float) (width*0.8);
			chevrontop = (float) (height*0.25);
			float size = (float) (height*0.5);
			chevronbitmap = scaleOldBitmap(
					BitmapFactory.decodeResource(context.getResources(), R.drawable.chevron), 
					size, size); 
		}	
		
		// methods to update time and 
		public void setTime(String timetmp){
			time=timetmp;
			this.invalidate();
		}
		public void setItem(String itemtmp) {
			item=itemtmp;
			this.invalidate();
		}		
		public String getTime(String timetmp){
			return time;
		}
		public String getItem(String itemtmp) {
			return item;
		}
		
		protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			// add timer button
			this.setBackgroundResource(backgroundint);
			//add item
			canvas.drawText(item, xstart_item, ystart_item, painttext);
			// add time
			canvas.drawText(time, xstart_time, ystart_time, painttime);
			// add chevron
			canvas.drawBitmap(chevronbitmap, chevronleft, chevrontop, null);

			// have onDraw invalidate(re-call onDraw/call itself/) to keep ticking
			this.invalidate();
		}
		
		public void setBackgroundInt(int backgroundinttmp){
			backgroundint = backgroundinttmp;
		}
		
		// onMeasure to define size
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
    		this.setMeasuredDimension(width,height);
    	} 
	}

	public Bitmap scaleOldBitmap(Bitmap decodeResource, float desiredwidth, float desiredheight) {
        int width = decodeResource.getWidth();
        int height = decodeResource.getHeight();
        
        // calculate the scale 
        float scaleWidth = desiredwidth / ((float) width);
        float scaleHeight = desiredheight / ((float) height);
        
        // createa matrix for the manipulation
        Matrix matrix = new Matrix();
        // resize the bit map
        matrix.postScale(scaleWidth, scaleHeight);

        // recreate the new Bitmap
        Bitmap resizedBitmap = Bitmap.createBitmap(decodeResource, 0, 0, 
                          width, height, matrix, true); 
		return resizedBitmap;
	}

	
	// get result of TimerEdit
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			Intent intent) {
		// called after timer edit. it gets the return values, and rebuilds any clocks not edited.
		super.onActivityResult(requestCode, resultCode, intent);
		Bundle extras = intent.getExtras();
		//
		 // mIntent.putExtra("item", item); string
		 // mIntent.putExtra("milliseconds", milliseconds); long
		 // mIntent.putExtra("position", position); int
		 //
		String itemtemp = extras.getString("item");
		long millisecondstemp = extras.getLong("milliseconds");
		int timerint = extras.getInt("timerint");

		if(timerint==1){
			if(stillticking.get(2)==true){
				this.setupTimer(2);
			}
			if(stillticking.get(3)==true){
				this.setupTimer(3);
			}
			if(stillticking.get(4)==true){
				this.setupTimer(4);
			}
			if(millisecondstemp>0.1) {  // do not run timer if time is zero
				timerbutton1.item = itemtemp;
				timerbutton1.time = longtime2Stringtime(millisecondstemp);
				timerbutton1.setTime(timerbutton1.time);
				timerbutton1.setItem(timerbutton1.item);
				counter1 = new OneCounter(millisecondstemp, 1000, 1);
				// give time back to controller
				appState.setTimer1time(millisecondstemp, 
						Calendar.getInstance().getTimeInMillis(), false, timerbutton1.item);
				String temp = appState.getTimer1timeDate1();
				stillticking.put(1, Boolean.valueOf(temp.split("::")[2]));
				timermillisec.put(1,Long.valueOf(temp.split("::")[0]));
				datemillisec.put(1,Long.valueOf(temp.split("::")[1]));
				item.put(1, temp.split("::")[3]);
				// start counter
				myServiceTest1.MillisecondsTillDone=millisecondstemp;
				myServiceTest1.item=itemtemp;
			}
		}
		if(timerint==2){
			if(stillticking.get(1)==true){
				this.setupTimer(1);
			}
			if(stillticking.get(3)==true){
				this.setupTimer(3);
			}
			if(stillticking.get(4)==true){
				this.setupTimer(4);
			}
			if(millisecondstemp>0.1) {
				timerbutton2.item = itemtemp;
				timerbutton2.time = longtime2Stringtime(millisecondstemp);
				timerbutton2.setTime(timerbutton2.time);
				timerbutton2.setItem(timerbutton2.item);
				counter2 = new OneCounter(millisecondstemp, 1000, 2);
				// give time back to controller
				appState.setTimer2time(millisecondstemp, 
						Calendar.getInstance().getTimeInMillis(), false, timerbutton2.item);
				String temp = appState.getTimer2timeDate2();
				stillticking.put(2, Boolean.valueOf(temp.split("::")[2]));
				timermillisec.put(2,Long.valueOf(temp.split("::")[0]));
				datemillisec.put(2,Long.valueOf(temp.split("::")[1]));
				item.put(2, temp.split("::")[3]);
				// start counter
				myServiceTest2.MillisecondsTillDone=millisecondstemp;
				myServiceTest2.item=itemtemp;
			}
		}
		if(timerint==3){
			if(stillticking.get(1)==true){
				this.setupTimer(1);
			}
			if(stillticking.get(2)==true){
				this.setupTimer(2);
			}
			if(stillticking.get(4)==true){
				this.setupTimer(4);
			}
			if(millisecondstemp>0.1){
				timerbutton3.item = itemtemp;
				timerbutton3.time = longtime2Stringtime(millisecondstemp);
				timerbutton3.setTime(timerbutton3.time);
				timerbutton3.setItem(timerbutton3.item);
				counter3 = new OneCounter(millisecondstemp, 1000, 3);
				// give time back to controller
				appState.setTimer3time(millisecondstemp, 
						Calendar.getInstance().getTimeInMillis(), false, timerbutton3.item);
				String temp = appState.getTimer3timeDate3();
				stillticking.put(3, Boolean.valueOf(temp.split("::")[2]));
				timermillisec.put(3,Long.valueOf(temp.split("::")[0]));
				datemillisec.put(3,Long.valueOf(temp.split("::")[1]));
				item.put(3, temp.split("::")[3]);
				// start counter
				myServiceTest3.MillisecondsTillDone=millisecondstemp;
				myServiceTest3.item=itemtemp;
			}
		}
		if(timerint==4){
			if(stillticking.get(1)==true){
				this.setupTimer(1);
			}
			if(stillticking.get(2)==true){
				this.setupTimer(2);
			}
			if(stillticking.get(3)==true){
				this.setupTimer(3);
			}
			if(millisecondstemp>0.1) {
				timerbutton4.item = itemtemp;
				timerbutton4.time = longtime2Stringtime(millisecondstemp);
				timerbutton4.setTime(timerbutton4.time);
				timerbutton4.setItem(timerbutton4.item);
				counter4 = new OneCounter(millisecondstemp, 1000, 4);
				// give time back to controller
				appState.setTimer4time(millisecondstemp, 
						Calendar.getInstance().getTimeInMillis(), false, timerbutton4.item);
				String temp = appState.getTimer4timeDate4();
				stillticking.put(4, Boolean.valueOf(temp.split("::")[2]));
				timermillisec.put(4,Long.valueOf(temp.split("::")[0]));
				datemillisec.put(4,Long.valueOf(temp.split("::")[1]));
				item.put(4, temp.split("::")[3]);
				// start counter
				myServiceTest4.MillisecondsTillDone=millisecondstemp;
				myServiceTest4.item=itemtemp;
			}
		}
	}

	public void startCounter1(long millisecondstemp) {
		counter1 = new OneCounter(millisecondstemp, 1000, 1);
		counter1.start();
		stillticking.put(1,true);
		this.myServiceTest1.MillisecondsTillDone = millisecondstemp;
		this.myServiceTest1.item = counter1.item;
		this.myServiceTest1.timerint=1;
		this.myServiceTest1.stillticking=true;
		this.myServiceTest1.startservice();
	}
	public void startCounter2(long millisecondstemp) {
		counter2 = new OneCounter(millisecondstemp, 1000, 2);
		counter2.start();
		stillticking.put(2,true);
		this.myServiceTest2.MillisecondsTillDone = millisecondstemp;
		this.myServiceTest2.item = counter2.item;
		this.myServiceTest2.timerint=2;
		this.myServiceTest2.stillticking=true;
		this.myServiceTest2.startservice();
	}
	public void startCounter3(long millisecondstemp) {
		counter3 = new OneCounter(millisecondstemp, 1000, 3);
		counter3.start();
		stillticking.put(3,true);
		this.myServiceTest3.MillisecondsTillDone = millisecondstemp;
		this.myServiceTest3.item = counter3.item;
		this.myServiceTest3.timerint=3;
		this.myServiceTest3.stillticking=true;
		this.myServiceTest3.startservice();
	}
	public void startCounter4(long millisecondstemp) {
		counter4 = new OneCounter(millisecondstemp, 1000, 4);
		counter4.start();
		stillticking.put(4,true);
		this.myServiceTest4.MillisecondsTillDone = millisecondstemp;
		this.myServiceTest4.item = counter4.item;
		this.myServiceTest4.timerint=4;
		this.myServiceTest4.stillticking=true;
		this.myServiceTest4.startservice();
	}
	
	public void message(final int timerint) {
		AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
		if (timerint==1){
			builder.setTitle(timerbutton1.item + " is done!");
		}
		if (timerint==2){
			builder.setTitle(timerbutton2.item + " is done!");
		}
		if (timerint==3){
			builder.setTitle(timerbutton3.item + " is done!");
		}
		if (timerint==4){
			builder.setTitle(timerbutton4.item + " is done!");
		}

		AlertDialog alert = builder.create();

		alert.setButton2("okay!", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				// do something
				stopring(timerint);
			}
		});

		alert.show();
	}
	
	// inner class with methods
	private class OneCounter extends CountDownTimer {
		// this is the counter class.  It is instantiated with a timer in milliseconds
		//    (countDownInterval=1000 is 1 sec), where the onTick() method is called every
		//    countDownInterval.  when the counter reaches 0s, onFinish() is called.
		public long MillisecondsTillDone;
		private boolean alarmstarted;
		public int timerint;
		public String item;

		public OneCounter(long millisInFuture, long countDownInterval, int timerinttemp) {
			super(millisInFuture, countDownInterval);
			timerint = timerinttemp;
			if (timerint==1) {
				item = timerbutton1.item;
			}
			if (timerint==2) {
				item = timerbutton1.item;
			}
			if (timerint==3) {
				item = timerbutton1.item;
			}
			if (timerint==4) {
				item = timerbutton1.item;
			}
		}

		@Override
		public void onFinish() {
			if(timerint==1){
				timerbutton1.time = "done!";
				// set controller
				appState.setTimer1time((long)0.0, (long)0.0, false, timerbutton1.item);
				message(1);
				myServiceTest1.stopservice();
				//ring(1);
				TimersDisplay.this.notify(timerbutton1.item);
			}
			if(timerint==2){
				timerbutton2.time = "done!";
				// set controller
				appState.setTimer2time((long)0.0, (long)0.0, false, timerbutton2.item);
				message(2);
				myServiceTest2.stopservice();
				//ring(2);
				TimersDisplay.this.notify(timerbutton2.item);
			}
			if(timerint==3){
				timerbutton3.time = "done!";
				// set controller
				appState.setTimer3time((long)0.0, (long)0.0, false, timerbutton3.item);
				message(3);
				myServiceTest3.stopservice();
				//ring(3);
				TimersDisplay.this.notify(timerbutton3.item);
			}
			if(timerint==4){
				timerbutton4.time = "done!";
				// set controller
				appState.setTimer4time((long)0.0, (long)0.0, false, timerbutton4.item);
				message(4);
				myServiceTest4.stopservice();
				//ring(4);
				TimersDisplay.this.notify(timerbutton4.item);
			}
		}

		@Override
		public void onTick(long millisUntilFinished) {
			//System.out.println("*** OneCounter:  onTick ");
			long secs = millisUntilFinished / 1000;
			long hours = secs / 3600, remainder = secs % 3600, minutes = remainder / 60, seconds = remainder % 60;
			String disHour = (hours < 10 ? "0" : "") + hours, disMinu = (minutes < 10 ? "0"
					: "")
					+ minutes, disSec = (seconds < 10 ? "0" : "") + seconds;

			// mTime.setText(name+": "+disHour+":"+disMinu+":"+disSec);
			// timer1.setTime(disHour+":"+disMinu+":"+disSec);
			this.MillisecondsTillDone = millisUntilFinished;
			// mTextTimer.notifyDataSetChanged();
			if(timerint==1){
				timerbutton1.time = disHour + ":" + disMinu + ":" + disSec;
				// give time back to controller
				appState.setTimer1time(this.MillisecondsTillDone, 
						Calendar.getInstance().getTimeInMillis(), true, timerbutton1.item);
				timerbutton1.setBackgroundInt(R.drawable.timer);
				timerbutton1.invalidate();
			}
			if(timerint==2){
				timerbutton2.time = disHour + ":" + disMinu + ":" + disSec;
				// give time back to controller
				appState.setTimer2time(this.MillisecondsTillDone, 
						Calendar.getInstance().getTimeInMillis(), true, timerbutton2.item);
				timerbutton2.setBackgroundInt(R.drawable.timer);
				timerbutton2.invalidate();
			}
			if(timerint==3){
				timerbutton3.time = disHour + ":" + disMinu + ":" + disSec;
				// give time back to controller
				appState.setTimer3time(this.MillisecondsTillDone, 
						Calendar.getInstance().getTimeInMillis(), true, timerbutton3.item);
				timerbutton3.setBackgroundInt(R.drawable.timer);
				timerbutton3.invalidate();
			}
			if(timerint==4){
				timerbutton4.time = disHour + ":" + disMinu + ":" + disSec;
				// give time back to controller
				appState.setTimer4time(this.MillisecondsTillDone, 
						Calendar.getInstance().getTimeInMillis(), true, timerbutton4.item);
				timerbutton4.setBackgroundInt(R.drawable.timer);
				timerbutton4.invalidate();
			}
		}
	}
	
	public void notify(String item){
		Intent intent = new Intent(this,TimersDisplay.class);
		NotificationManager mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		Notification notification = new Notification(R.drawable.cheflogo,item+" is done!", System.currentTimeMillis());
		notification.setLatestEventInfo(this,"Chef","Message from Chef:  "+item+" is done!",
				PendingIntent.getActivity(this.getBaseContext(), 0, intent,PendingIntent.FLAG_CANCEL_CURRENT));
		mNotificationManager.notify(1, notification);
	}
	
	public void stopring(int timer) {
		if (timer==1) {
			if(mMediaPlayer1!=null) {
				mMediaPlayer1.stop();
			}
		}
		if (timer==2) {
			if(mMediaPlayer2!=null) {
				mMediaPlayer2.stop();
			}
		}
		if (timer==3) {
			if(mMediaPlayer3!=null) {
				mMediaPlayer3.stop();
			}
		}
		if (timer==4) {
			if(mMediaPlayer4!=null) {
				mMediaPlayer4.stop();
			}
		}
	}
	
	public void ring(int timer){
		System.out.println("****** TimersDisplay::ring ");
		// this starts a Mediaplayer to ring. it is called at onFinish() by OneCounter
		 Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM); 
		 if(alert == null){
	         // alert is null, using backup
	         alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
	         if(alert == null){  
	        	 // I can't see this ever being null (as always have a default notification) but just incase
	             // alert backup is null, using 2nd backup
	             alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);               
	         }
	     }
		if(timer==1 && mMediaPlayer1!=null) {
			 try {
				mMediaPlayer1.setDataSource(this, alert);
			} catch (IllegalArgumentException e1) {
				e1.printStackTrace();
			} catch (SecurityException e1) {
				e1.printStackTrace();
			} catch (IllegalStateException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 final AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
			 if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
			            mMediaPlayer1.setAudioStreamType(AudioManager.STREAM_ALARM);
			            mMediaPlayer1.setLooping(true);
			            try {
			            	mMediaPlayer1.prepare();
						} catch (IllegalStateException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						mMediaPlayer1.start();
			  }
		}
		if(timer==2 && mMediaPlayer2!=null) {
			 try {
				mMediaPlayer2.setDataSource(this, alert);
			} catch (IllegalArgumentException e1) {
				e1.printStackTrace();
			} catch (SecurityException e1) {
				e1.printStackTrace();
			} catch (IllegalStateException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 final AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
			 if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
			            mMediaPlayer2.setAudioStreamType(AudioManager.STREAM_ALARM);
			            mMediaPlayer2.setLooping(true);
			            try {
			            	mMediaPlayer2.prepare();
						} catch (IllegalStateException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						mMediaPlayer2.start();
			  }
		}
		if(timer==3 && mMediaPlayer3!=null) {
			 try {
				mMediaPlayer3.setDataSource(this, alert);
			} catch (IllegalArgumentException e1) {
				e1.printStackTrace();
			} catch (SecurityException e1) {
				e1.printStackTrace();
			} catch (IllegalStateException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 final AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
			 if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
			            mMediaPlayer3.setAudioStreamType(AudioManager.STREAM_ALARM);
			            mMediaPlayer3.setLooping(true);
			            try {
			            	mMediaPlayer3.prepare();
						} catch (IllegalStateException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						mMediaPlayer3.start();
			  }
		}
		if(timer==4 && mMediaPlayer4!=null) {
			 try {
				mMediaPlayer4.setDataSource(this, alert);
			} catch (IllegalArgumentException e1) {
				e1.printStackTrace();
			} catch (SecurityException e1) {
				e1.printStackTrace();
			} catch (IllegalStateException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 final AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
			 if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
			            mMediaPlayer4.setAudioStreamType(AudioManager.STREAM_ALARM);
			            mMediaPlayer4.setLooping(true);
			            try {
			            	mMediaPlayer4.prepare();
						} catch (IllegalStateException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						mMediaPlayer4.start();
			  }
		}
	}
	
	private class TitleView extends View {
		Integer resourceInt;
		Integer width;
		Integer height;
		public TitleView(Context innercontext,Integer resourceInttemp,Integer screenWidth, Integer screenHeight){
    		super(innercontext);
    		resourceInt=resourceInttemp;
    		width = screenWidth;
    		height = screenHeight * 10 / 100;
		}
	   	protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			this.setBackgroundResource(resourceInt);
    	}
    	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
    		this.setMeasuredDimension(width,height);
    	} 
	}
	
	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);		
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		//Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		//menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "").setIcon(home);
		Drawable mealplanner = this.getResources().getDrawable(R.drawable.mealplanner);
		menu.add(0, Planner_ID, 0, "").setIcon(mealplanner);;
		
		menu.add(0, AboutChef_ID, 0, "About Chef");
		menu.add(0, Contact_ID, 0, "Contact Us");
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Planner_ID:
			goto_planner();
			return true;
		case Contact_ID:
			contact_us();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		case AboutChef_ID:
			this.gotoAboutChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private static final int AboutChef_ID = 10;
	protected void gotoAboutChef() {
		Intent i = new Intent(this, AboutChef.class);
		startActivity(i);
	}
	
	private void goto_planner() {
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}
	
	
	private void gotoChef() {
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}

	private void contact_us() {
		// email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
		// users to provide feedback.
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity TimersDisplay");
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void createTimers() {
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		//i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}
	
	
	// try to create a Service:
	public class BackgroundService extends Service {
		private OneCounter counterBackground;
		private Context Ctx;
		public int timerint;
		public long MillisecondsTillDone;
		public String item;
		public boolean stillticking=false;
	    
		public BackgroundService(Context Ctxtmp, long MillisecondsTillDonetmp, String itemtmp, int timerinttmp){
			Ctx=Ctxtmp;
			timerint=timerinttmp;
			MillisecondsTillDone = MillisecondsTillDonetmp;
			item=itemtmp;
			counterBackground = new OneCounter(MillisecondsTillDone, 1000, 5);
		}
		public void onCreate() {
			super.onCreate();
			startservice();
		}
		public void startservice() {
			counterBackground.start();
			;}
		public void stopservice() {
			String str = "Message from Chef:  "+item+" is done!";
			Toast.makeText(Ctx, str, Toast.LENGTH_SHORT).show();
			// cancel the backgroud counter:
			counterBackground.cancel();
		}
		public void stopservice(String temp) {
			// do not ping, just stop timer.  this is called when timer is paused:
			counterBackground.cancel();
		}
		@Override
		public IBinder onBind(Intent arg0) {
			// this does nothing, but is needed
			return null;
		}
	}


	// fields
	private  final int Cookbook_ID = 0;
	private  final int Grocerylist_ID = 1;
	private  final int Search_ID = 2;
	private  final int Timers_ID = 3;
	private  final int Chef_ID = 4;
	private final int Planner_ID = 7;
	static final int Contact_ID = 11;
	OneCounter counter2;
	OneCounter counter3;
	OneCounter counter4;
	private LinearLayout mLinearLayout;
	// make timer buttons:
	// (Context context, int screenWidth, int screenHeight, String itemtmp, String timetmp)
	TimerButton timerbutton1;
	TimerButton timerbutton2;
	TimerButton timerbutton3;
	TimerButton timerbutton4;
	//private Boolean stillticking1;
	Map<Integer, Boolean> stillticking = new HashMap<Integer, Boolean>();
	//private Long timer1millisec;
	Map<Integer, Long> timermillisec = new HashMap<Integer, Long>();
	//private Long date1millisec;
	Map<Integer, Long> datemillisec = new HashMap<Integer, Long>();
	//private String item1;
	Map<Integer, String> item = new HashMap<Integer, String>();
	OneCounter counter1;
	int screen_width;
	int screen_height;
	Context mCtx;
	private ChefController appState;
	private BackgroundService myServiceTest1;
	private BackgroundService myServiceTest2;
	private BackgroundService myServiceTest3;
	private BackgroundService myServiceTest4;
	private MediaPlayer mMediaPlayer1 = null;
	private MediaPlayer mMediaPlayer2 = null;
	private MediaPlayer mMediaPlayer3 = null;
	private MediaPlayer mMediaPlayer4 = null;
	private PowerManager.WakeLock wl;
}
