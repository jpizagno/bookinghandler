package com.noblebug.chefpro.tools;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;

public class InputStreamText {
	// gets text given an inputstream used in PHP scripts
	// 4 June 2011 Jim Pizagno

	public String GetText(InputStream in) throws UnsupportedEncodingException {
		String temp = "";
		byte[] utf8Bytes = temp.getBytes("UTF16");
	    String text = new String(utf8Bytes,"UTF8");
		InputStreamReader streamreader;
		try {
			streamreader = new InputStreamReader(in, "UTF8");
			BufferedReader reader = new BufferedReader(streamreader);  //new InputStreamReader(in));
			StringBuilder sb = new StringBuilder();
			
			String line = null;
			try {
				while ((line = reader.readLine()) != null) {
					sb.append(line + "\n");
				}	
				text = sb.toString();
			} catch (Exception ex) {
			} finally {
				try {
					in.close();
				} catch (Exception ex) {
			}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return text;
	}

	public String GetText(HttpResponse response) throws UnsupportedEncodingException {
		String temp = "";
		byte[] utf8Bytes = temp.getBytes("UTF16");
	    String text = new String(utf8Bytes,"UTF8");
		try {
			text = GetText(response.getEntity().getContent());
		} catch (Exception ex) {
		}
		return text;
	}
}
