package com.noblebug.chefpro.grocerylist;

import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.planner.Planner;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.settings.AboutChef;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.ListOfLists;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class GrocerylistDisplay extends Activity  {
	// class builds GroceryList, handles title, selector, and adapters.
	// 4 June 2011
	
	// all this class does is display the Tabs (which actually start
	// GrocerylistSingle
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// do some cleaning before creating object(s)
		System.gc();
		
		// fix orientation of phone to Portrait, do not display TITLE bar at top.
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		mCtx = this;
		
		appState = ((ChefController) getApplicationContext());
		myGroceryList = appState.getGrocerylist();
		if (myGroceryList==null){  // sometimes the grocerylist is null (after ~ 1day)
			appState.createObjects(this);
			myGroceryList = appState.getGrocerylist();
		} 
		adapter = myGroceryList.getAdapterAisle();
		myGroceryList.fillAdapters(appState.AisleList);
		appState.setGroceryList(myGroceryList);
		
		//get State:
		grocerylistState = getIntent().getStringExtra("grocerylistState");
        final SelectorView mySelector = new SelectorView(this);
    	if (getIntent().hasExtra("grocerylistState")==true) {
    		grocerylistState = (String) getIntent().getExtras().get("grocerylistState");
    		mDbHelper = new BackEndSQLite(this);
    		mDbHelper.open();
    		int UserID = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
    		userid = UserID;
    		mDbHelper.setGrocerylistState(String.valueOf(UserID), grocerylistState);
    		mDbHelper.close();
    		mySelector.setState(grocerylistState);
        	mySelector.invalidate();
    	} else {
    		// get grocerylistState:
    		mDbHelper = new BackEndSQLite(this);
    		mDbHelper.open();
    		int UserID = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
    		userid = UserID;
    		grocerylistState = mDbHelper.getGrocerylistState(String.valueOf(UserID));
    		mDbHelper.close();
        	mySelector.setState(grocerylistState);
    	}
		// get adapter for list of lists:
		// get adapter from grocery object.
		// depending on which format is needed.
		if (grocerylistState.equalsIgnoreCase("aisle")) {
			adapter = myGroceryList.getAdapterAisle();
		}
		if (grocerylistState.equalsIgnoreCase("recipe")) {
			adapter = myGroceryList.getAdapterRecipe();
		}
		if (grocerylistState.equalsIgnoreCase("custom")) {
			adapter = myGroceryList.getAdapterCuston();
			// addIngredientsToAdapterCustom();
		}
    	
		// define layout
		LinearLayout mLinearLayout = new LinearLayout(this);
        mLinearLayout.setOrientation(LinearLayout.VERTICAL);
        mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
        mLinearLayout.setBackgroundResource(R.drawable.grocerypaperbackground);
        
        // get screen size
        int height = this.getWindowManager().getDefaultDisplay().getHeight();
        
        // add title
        ImageView titleImage = new ImageView(this);
		titleImage.setImageResource(R.drawable.grocerylisttitle);
		int padding = -1 * height / 42;
		titleImage.setPadding(0, padding, 0, padding);
		mLinearLayout.addView(titleImage);
		
        // add selector
		mySelector.setClickable(true);
		mySelector.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
		        switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_UP:
		            {
		            	float screenSize = mySelector.getWidth();
		            	float x = ev.getX();
		            	float percentX = x/screenSize;
		            	if(percentX<=0.33){
		            		callSelf("aisle");
		            	}
		            	if(percentX>0.33 && percentX<=0.66){
		            		callSelf("recipe");
		            	}
		            	if(percentX>0.66){
		            		callSelf("custom");
		            	}
		            	break;
		            }
		        }
				return true;
			}
		});
		mLinearLayout.addView(mySelector);
        
        // create list view
		ListView myListView = new ListView(this);
		myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
        
        // create onClickListener to StrikeThrough AND save text....
        myListView.setClickable(true);
        myListView.setFocusable(true);
        myListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View view,
					int position, long ID) {

				TextView text = (TextView) view.findViewById(R.id.list_item_title);
				int paintFlag = text.getPaintFlags();
				System.out.println("*** GroceryListDisplay:onCreate paintFlag="+paintFlag);
				System.out.println("*** Paint.STRIKE_THRU_TEXT_FLAG="+Paint.STRIKE_THRU_TEXT_FLAG);
				if (text.getPaintFlags() == 257 || text.getPaintFlags() == 1281 || text.getPaintFlags() ==Paint.STRIKE_THRU_TEXT_FLAG ) {
					// uncrossed.... so cross through
					text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
					myGroceryList.checkItem((String) text.getText()); 
					crossItemInDB(userid, (String) text.getText());
				} else {
					// crossed through so uncross
					text.setPaintFlags(text.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
					myGroceryList.UncheckItem((String) text.getText()); 
					removeIteminDB(userid, (String) text.getText());
				}

			}
		});
 
		// add adatpter
		myListView.setAdapter(adapter);
        mLinearLayout.addView(myListView);
        
        setContentView(mLinearLayout);

	}
	
	private void crossItemInDB(int userid, String textToStrike) {
		// strike text in DATABASE
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		mDbHelper.setCrossItems(userid,textToStrike);
		mDbHelper.close();
	}
	
	private void removeIteminDB(int userid, String text) {
		// this item was un-striked through. fix db.
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		mDbHelper.unsetCrossItems(userid,text);
		mDbHelper.close();
	}
	
    private class SelectorView extends View {
    	// displays the selector "aisle","recipe","custom" after title, and before grocery list
    	private String grocerylistState="aisle";
		private Drawable myDrawable;
		private Context innercontext;
		private Integer width;
		private Integer height;
		
		public void setState(String temp){
			grocerylistState=temp;
			
			Display display = getWindowManager().getDefaultDisplay();
			width = display.getWidth();
			height = display.getHeight() / 12;
			
			// load drawable
	   		if(grocerylistState.equalsIgnoreCase("aisle")){
	   			myDrawable = this.getResources().getDrawable(R.drawable.grocerylistaisle);
    		}
    		if(grocerylistState.equalsIgnoreCase("recipe")){
    			myDrawable = this.getResources().getDrawable(R.drawable.grocerylistrecipe);
    		}
    		if(grocerylistState.equalsIgnoreCase("custom")){
    			myDrawable = this.getResources().getDrawable(R.drawable.grocerylistcustom);
    		}
		}
    	public SelectorView(Context innercontext){
    		super(innercontext);
    	}
    	protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			this.setBackgroundDrawable(myDrawable);
    	}
    	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
    		this.setMeasuredDimension(width,height);
    	} 
    }
    
	private void callSelf(String  grocerylistState) {
		// save state
		Intent i = new Intent(this, GrocerylistDisplay.class);
		i.putExtra("grocerylistState", grocerylistState);
		startActivity(i);
	}
	
	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		
		BackEndSQLite mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		if (mDbHelper.hasAnyRecipes()==true) {
			//
			 // For some reason that I do not understand, if the user adds an item to the grocery
			 // list BEFORE going to the cookbook, then the cookbook will crash when it starts
			 // for the first time. If the user goes to the cookbook first, and adds recipes then
			 // this addItem works.  THIS NEEDS TO BE FIXED! It seems that the alert dialogs get
			 // confused in the Cookbook and Grocerylist
			 //
			menu.add(0, AddItem_ID, 0, "Add Item");
		}
		mDbHelper.close();
		
		menu.add(0, ClearChecked_ID, 0, R.string.btnclearchecked);
		menu.add(0, ClearALL_ID, 0, R.string.btnclearall);
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		
		menu.add(0, Cookbook_ID, 0, "Cookbook").setIcon(cookbook);
		menu.add(0, Search_ID, 0, "Search").setIcon(search);
		menu.add(0, Timers_ID, 0, "Timers").setIcon(timers);
		menu.add(0, Chef_ID, 0, "Home").setIcon(home);
		menu.add(0, AboutChef_ID, 0, "About Chef");
		if ( userid > -1) {
			// only add Planner when user is logged in
			Drawable mealplanner = this.getResources().getDrawable(R.drawable.mealplanner);
			menu.add(0, Planner_ID, 0, "Meal Planner").setIcon(mealplanner);;
		}
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Planner_ID:
			goto_planner();
			return true;
		case AddItem_ID:
			this.addItem();
			return true;
		case ClearChecked_ID:
			this.clearCheckedItems();
			return true;
		case ClearALL_ID:
			this.clearAllItems();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		case AboutChef_ID:
			this.gotoAboutChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}
	
	private static final int AboutChef_ID = 10;
	protected void gotoAboutChef() {
		Intent i = new Intent(this, AboutChef.class);
		startActivity(i);
	}
	
	private void goto_planner() {
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}
	
	private void addItem() {
		// allow use to add an item. it should go into OddsN'Ends recipe
		myGroceryList = appState.getGrocerylist();
		
		AlertDialog.Builder alert = new AlertDialog.Builder(this);

		alert.setTitle("Add Item");
		alert.setMessage("Enter Item to add to your grocery list");
		
		final AutoCompleteTextView input = new AutoCompleteTextView(this);
		Resources res = getResources();
		String[] grocerylist_suggestions_array = res.getStringArray(R.array.grocerylist_suggestions_array);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, grocerylist_suggestions_array);
		input.setAdapter(adapter);
		alert.setView(input);
		
		
		alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int whichButton) {
			String temp = input.getText().toString();
			temp = temp.trim();
			myGroceryList.addUserItem(temp);
			myGroceryList.fillAdapters(appState.AisleList);
			appState.setGroceryList(myGroceryList);
			appState.check4InternetConnection(mCtx);
			String UID = appState.getUIDandPASSWD().split("_")[0];
			if (appState.internetConnectionOpen==true && UID.equalsIgnoreCase("-1")==false){
				myGroceryList.grocerylist2web();
			}
			reDisplayGroceryList();
		  }
		});

		alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
		  public void onClick(DialogInterface dialog, int whichButton) {
		    // Canceled.
		  }
		});

		alert.show();
	}
	
	private void reDisplayGroceryList(){
		Intent i = new Intent(this, GrocerylistDisplay.class);
		startActivity(i);
	}
	
	private void clearAllItems() {
		// clear all items in grocery list, regardless of wether or not grocery item is crossed
		myGroceryList.clearAllGroceryListAdapters();
		appState.check4InternetConnection(this);
		if (appState.internetConnectionOpen==true) {
			myGroceryList.grocerylist2web();
		}
		appState.setGroceryList(myGroceryList);
		Intent i = new Intent(this, GrocerylistDisplay.class);
		startActivity(i);
	}

	private void clearCheckedItems() {
		// clean only items that are checkd.  
		myGroceryList.clearCheckedItems();
		appState.check4InternetConnection(this);
		if (appState.internetConnectionOpen==true){
			myGroceryList.grocerylist2web();
		}
		appState.setGroceryList(myGroceryList);
		Intent i = new Intent(this, GrocerylistDisplay.class);
		startActivity(i);

	}

	// methods that call other activities, mostly called by menu:
	private void gotoChef() {
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}
	private void createTimers() {
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}
	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}
	private void createGroceryList() {
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}
	private void createCookbook() {
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		startActivity(i_cookbook);
	}
	
	@Override
	public void onBackPressed() {
		// want to go to Chef so user does not see an old grocery list with deleted items
		this.gotoChef();
	}
	
	private   final int Cookbook_ID = 0;
	private   final int Grocerylist_ID = 1;
	private   final int Search_ID = 2;
	private   final int Timers_ID = 3;
	private   final int Chef_ID = 4;
	private   final int ClearALL_ID = 5;
	private   final int ClearChecked_ID = 6;
	private   final int AddItem_ID = 7;
	private final int Planner_ID = 17;
	private String grocerylistState = "aisle"; // or 
	private ChefController appState;
	private GroceryList myGroceryList;
	private ListOfLists adapter;
	private Context mCtx;
	private BackEndSQLite mDbHelper;
	private int userid;
}
