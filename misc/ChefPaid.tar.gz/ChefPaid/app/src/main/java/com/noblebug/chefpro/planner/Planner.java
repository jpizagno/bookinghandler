package com.noblebug.chefpro.planner;

import android.app.Activity;
import android.os.Bundle;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Planner extends Activity implements OnClickListener
	{
		private static final String tag = "SimpleCalendarViewActivity";
		private Button mealPlannerTitle;
		private TextView currentMonth;
		private ImageView prevMonth;
		private ImageView nextMonth;
		private GridView calendarView;
		private GridCellAdapter adapter;
		private Calendar _calendar;
		public int month, year, day;
		private final DateFormat dateFormatter = new DateFormat();
		private BackEndSQLite mDbHelper;
		public String user;
		public Context plannerCtx;
		private List<String> recipesThisMonth = new ArrayList<String>();
		private ListView mainListView;
		private ArrayList mealListDayClicked = new ArrayList();
		private ChefController appState;
		private static final String dateTemplate = "MMMM yyyy";

		/** Called when the activity is first created. */
		@Override
		public void onCreate(Bundle savedInstanceState)
			{
				super.onCreate(savedInstanceState);
				
				// fix phone in POTRAIT (not landscape), and remove TITLE.
				this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
				this.requestWindowFeature(Window.FEATURE_NO_TITLE);
				
				setContentView(R.layout.simple_calendar_view);

				plannerCtx = this;
				
				// use app state to check for internet connection
				appState = ((ChefController) getApplicationContext());				
				
				// use this to get the user:
				mDbHelper = new BackEndSQLite(this);
				mDbHelper.open();
				String[] temp = mDbHelper.getUserSingle();
				user = temp[BackEndSQLite.out_int_userid];
				mDbHelper.close();
				
				
				//these months are all wrong ...all. does this start by 0 or 1?
				
				if (getIntent().hasExtra("DD-MM-YYYY")) {
					String DDMMYYYY = getIntent().getStringExtra("DD-MM-YYYY");
					int yy = Integer.valueOf(DDMMYYYY.split("-")[2]);
					int dd = Integer.valueOf(DDMMYYYY.split("-")[0]);
					int mm = Integer.valueOf(DDMMYYYY.split("-")[1]);
					_calendar = new GregorianCalendar(yy, mm-1, dd);
				} else {
					_calendar = Calendar.getInstance(Locale.getDefault());
				}
				month = _calendar.get(Calendar.MONTH)+ 1;
				year = _calendar.get(Calendar.YEAR);
				day = _calendar.get(Calendar.DAY_OF_MONTH);
				Log.d(tag, "Calendar Instance:= " + "Month: " + month + " " + "Year: " + year);

				//start off by getting the meals for this month:
				recipesThisMonth = getMealsByMonth(month-1,year,user);
				Iterator myit = recipesThisMonth.iterator();
				while(myit.hasNext()){
					String recipetmp = (String) myit.next();
					//System.out.println("*** Chef Planner onCreate mealtmp = "+recipetmp);
				}
				
				
				mealPlannerTitle = (Button) this.findViewById(R.id.mealPlannerTitle);
				mealPlannerTitle.setText("Meal Planner");
				
				leftarrow myleftarrow = (leftarrow) this.findViewById(R.id.leftarrow);
				myleftarrow.FrameSizeX = this.getWindowManager().getDefaultDisplay().getHeight()/10;
				myleftarrow.FrameSizeY = this.getWindowManager().getDefaultDisplay().getWidth()*13/100;
				myleftarrow.textWidth = dateFormatter.format(dateTemplate, _calendar.getTime()).length();
				myleftarrow.setOnClickListener( new LeftClickListener() );
				rightarrow myrightarrow = (rightarrow) this.findViewById(R.id.rightarrow);
				myrightarrow.FrameSizeX = this.getWindowManager().getDefaultDisplay().getHeight()/10;
				myrightarrow.FrameSizeY = this.getWindowManager().getDefaultDisplay().getWidth()*13/100;
				myrightarrow.setOnClickListener(new RightClickListener());
				
				currentMonth = (TextView) this.findViewById(R.id.currentMonth);
				currentMonth.setText(dateFormatter.format(dateTemplate, _calendar.getTime()));

				
				calendarView = (GridView) this.findViewById(R.id.calendar);

				// Initialised
				adapter = new GridCellAdapter(getApplicationContext(), R.id.calendar_day_gridcell, month, year);
				adapter.notifyDataSetChanged();
				calendarView.setAdapter(adapter);
				
				// make list for this month
				mainListView = (ListView) findViewById( R.id.simplecalendarrow ); 

				if (day<10) {
					makeListForDayClicked("0"+String.valueOf(day));	
				} else {
					makeListForDayClicked(String.valueOf(day));		
				}
				mainListView.setClickable(true);
				mainListView.setFocusable(true);
				CalendarTextButtonAdapter myTextButtonAdapter = new CalendarTextButtonAdapter(this,mealListDayClicked); //recipesThisMonth);
				mainListView.setAdapter(myTextButtonAdapter);  
				mainListView.setOnItemClickListener(new RecipeListClickListener());
			}

		public void callSelfPlanner(String DDMMYYYY) {
			// call Planner+self , but with a new DDMMYYYY.  
			// called when arrows (in view) are clicked.
			Intent i = new Intent(this, Planner.class);
			i.setType("text/plain");
			i.putExtra("DD-MM-YYYY",DDMMYYYY);
			startActivity(i);
		}
		
		public class LeftClickListener implements OnClickListener {
			@Override
			public void onClick(View v) {
				// call self with -1 month
				month = _calendar.get(Calendar.MONTH) + 1;
				year = _calendar.get(Calendar.YEAR);
				day = _calendar.get(Calendar.DAY_OF_MONTH);
				month = month-1;
				if (month<0) {
					month=11;
					year=year-1;
				}
				String DDMMYYYY= ""+day+"-"+month+"-"+year;
				callSelfPlanner(DDMMYYYY);
			}
		}
		public class RightClickListener implements OnClickListener {
			@Override
			public void onClick(View v) {
				// call self with +1 month
				month = _calendar.get(Calendar.MONTH) + 1;
				year = _calendar.get(Calendar.YEAR);
				day = _calendar.get(Calendar.DAY_OF_MONTH);
				month = month+1;
				if (month>11) {
					month=0;
					year=year+1;
				}
				String DDMMYYYY= ""+day+"-"+month+"-"+year;
				callSelfPlanner(DDMMYYYY);
			}
		}
		
		private List getMealsByMonth(int month2, int year2, String user2) {
			// send date and user to server
			BackEndPHPHandler myPhp = new BackEndPHPHandler();
			String result = myPhp.getMealByMonth(user, year2, month2);  //parsedDate); // return a list of meals at this month
			List recipedates = new ArrayList();
			
			// Add PHP results to list:
			if(result.equalsIgnoreCase("None")==false) {
				String[] tmps = result.split("<br>");
				for (int i=0;i<tmps.length;i++){
					// item format:  36424^^18678^^Chicken & Broccoli Casserole or (Make your own casserole)^^Dinner^^2012-07-12
					String item = tmps[i].replace("^^", "%%%%");
					recipedates.add(item);
				}
			}
			
			// when comparing the webpage/PHP to the phone backend:
			//     1) assume webpage is correct/master
			//     2) If user is not logged in or webpage is not available, then use the database
			mDbHelper.open();
			// split conditional statements for debugging purposes later (easier stacktrace to read, ie. read by line)
			boolean justUseWebserver = true;
			if (Integer.valueOf(this.user)<0) {
				justUseWebserver = false;
			}
			if (recipedates.size()==0) {
			  // just check phone db for recipes
				justUseWebserver = false;
			}
			if( !appState.check4InternetConnection(this.plannerCtx) ) {
				justUseWebserver = false;
			}
			System.out.println("**** Chef.getMealsByMonth justUseWebserver  = "+justUseWebserver);
			if (justUseWebserver) {
				// take meals from webserver and add them to the database
				Iterator myIt = recipedates.iterator();
				while (myIt.hasNext()) {
					String recipeHere = (String) myIt.next();
					mDbHelper.manageMeals(recipeHere, Integer.valueOf(this.user),"new");   // want these to be peristen.
				}
			} else {
				// goto db
				recipedates = mDbHelper.getAllMeals(Integer.valueOf(this.user));
			}
			System.out.println("**** Chef.getMealsByMonth recipedates.size() = "+recipedates.size());
			mDbHelper.close();
			
			if (recipedates.size()==0){
				recipedates.add("no meals for this day");
			}
			return recipedates;
		}

		/**
		 * 
		 * @param month
		 * @param year
		 */
		private void setGridCellAdapterToDate(int month, int year)
			{
				adapter = new GridCellAdapter(getApplicationContext(), R.id.calendar_day_gridcell, month, year);
				_calendar.set(year, month - 1, _calendar.get(Calendar.DAY_OF_MONTH));
				currentMonth.setText(dateFormatter.format(dateTemplate, _calendar.getTime()));
				adapter.notifyDataSetChanged();
				calendarView.setAdapter(adapter);
			}

		@Override
		public void onClick(View v)
			{
				if (v == prevMonth)
					{
						if (month <= 1)
							{
								month = 12;
								year--;
							}
						else
							{
								month--;
							}
						Log.d(tag, "Setting Prev Month in GridCellAdapter: " + "Month: " + month + " Year: " + year);
						setGridCellAdapterToDate(month, year);
					}
				if (v == nextMonth)
					{
						if (month > 11)
							{
								month = 1;
								year++;
							}
						else
							{
								month++;
							}
						Log.d(tag, "Setting Next Month in GridCellAdapter: " + "Month: " + month + " Year: " + year);
						setGridCellAdapterToDate(month, year);
					}
			}

		@Override
		public void onDestroy()
			{
				Log.d(tag, "Destroying View ...");
				super.onDestroy();
			}

		
		// create menu
		@Override
		public boolean onCreateOptionsMenu(Menu menu) {
			super.onCreateOptionsMenu(menu);
			Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
			menu.add(0, Cookbook_ID, 0, "Cookbook").setIcon(cookbook);
			Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
			menu.add(0, Grocerylist_ID, 0, "Grocery List").setIcon(grocerylist);
			Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
			menu.add(0, Search_ID, 0, "Search").setIcon(search);
			Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
			menu.add(0, Timers_ID, 0, "Timers").setIcon(timers);
			Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
			menu.add(0, Chef_ID, 0, "Home").setIcon(home);
			menu.add(0, Contact_ID, 0, "Contact Us");
			return true;
		}

		// create menu listener
		@Override
		public boolean onMenuItemSelected(int featureId, MenuItem item) {
			switch (item.getItemId()) {
			case Contact_ID:
				contact_us();
				return true;
			case Cookbook_ID:
				this.createCookbook();
				return true;
			case Grocerylist_ID:
				this.createGroceryList();
				return true;
			case Search_ID:
				this.createSearch();
				return true;
			case Timers_ID:
				this.createTimers();
				return true;
			case Chef_ID:
				this.gotoChef();
				return true;
			}
			return super.onMenuItemSelected(featureId, item);
		}
		
		private void createMealEditor(String recipeinformaiton) {
			Intent i = new Intent(this, MealEditor.class);
			i.setType("text/plain");
			i.putExtra("recipeinformation",recipeinformaiton);
			startActivity(i);
		}
		
		private void gotoChef() {
			if (mDbHelper != null) {
				mDbHelper.close();
			}
			Intent i = new Intent(this, Home.class);
			startActivity(i);
		}

		private void createTimers() {
			if (mDbHelper != null) {
				mDbHelper.close();
			}
			// goto timers
			Intent i = new Intent(this, TimersDisplay.class);
			// Intent i = new Intent(this, ChefCountdownTimer.class);
			startActivity(i);
		}

		private void createSearch() {
			if (mDbHelper != null) {
				mDbHelper.close();
			}
			Intent i_search = new Intent(this, SearchDisplay.class);
			startActivity(i_search);
		}

		private void createGroceryList() {
			if (mDbHelper != null) {
				mDbHelper.close();
			}
			// save state
			Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
			startActivityForResult(i_grocerylist, 0);
		}

		private void createCookbook() {
			if (mDbHelper != null) {
				mDbHelper.close();
			}
			Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
			//i_cookbook.putExtra("cookbookState","chefs");
			startActivity(i_cookbook);
		}
		private void contact_us() {
			// email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
			// users to provide feedback.
			Intent i = new Intent(Intent.ACTION_SEND);
			i.setType("text/plain");
			i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
			i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity Calendar");
			
			try {
			    startActivity(Intent.createChooser(i, "Send mail..."));
			} catch (android.content.ActivityNotFoundException ex) {
			    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
			}
		}

		public List makeListForDayClicked(String dayInput) {
    		// given a day, search through recipesThisMonth and display any recipes/meals for that day.

    		mealListDayClicked.clear();
		
    		Iterator recipesMonthIterator = recipesThisMonth.iterator();
    		while (recipesMonthIterator.hasNext()) {
				// check all recipes for this month.
				String item = (String) recipesMonthIterator.next();
				if (item.equalsIgnoreCase("no meals for this day")==false) {
					//System.out.println("***** Chef.Planner.makeListFroDayClicked  dayInput="+dayInput+" testday="+item.split("%%%%")[4].split("-")[2]+" "+item);
					if (dayInput.equalsIgnoreCase(item.split("%%%%")[4].split("-")[2])) {
						// dayClicked = meal for that day. so add to list
						mealListDayClicked.add(""+item.split("%%%%")[2]+", for "+item.split("%%%%")[3]);
					}
				}
			}
    		if (mealListDayClicked.size()==0){
				// nothing found. so add a "no recipes for this day"
    			mealListDayClicked.add("no meals for this day");
			}
    		return mealListDayClicked;
    	}
		

        public class RecipeListClickListener implements OnItemClickListener  {
        	public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
        		// This method is called when a recipe (located at the bottom of view in list) is clicked.
        		// calls the meal editor with a recipeInformation.
        		String recipeinformation = "error in RecipeListClickeListener in Planner.java";
				String testRecipeName = ((String) mealListDayClicked.get(position)).split(", for ")[0].trim();
				
				Iterator myIt = recipesThisMonth.iterator();
				while (myIt.hasNext()) {
					String testMeal = (String) myIt.next();
					//System.out.println("******** Chef.planner testRecipeName = "+testRecipeName+" testMeal = "+testMeal);
					if (testMeal.split("%%%%")[2].trim().equalsIgnoreCase(testRecipeName)) {
						recipeinformation = testMeal;
					}
				}
            	createMealEditor(recipeinformation);
			}
        }
		
		
		// ///////////////////////////////////////////////////////////////////////////////////////
		// Inner Class
		public class GridCellAdapter extends BaseAdapter implements OnClickListener
			{
				private static final String tag = "GridCellAdapter";
				private final Context _context;

				private final List<String> list;
				private static final int DAY_OFFSET = 1;
				private final String[] weekdays = new String[]{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
				private final String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
				private final int[] daysOfMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
				private final int month, year;
				private int daysInMonth, prevMonthDays;
				private int currentDayOfMonth;
				private int currentWeekDay;
				private Button gridcell;
				private TextView num_events_per_day;
				private final HashMap eventsPerMonthMap;
				private String clicked_date_month_year ="default is not to use.. set after click";
				private final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");

				// Days in Current Month
				public GridCellAdapter(Context context, int textViewResourceId, int month, int year)
					{
						super();
						this._context = context;
						this.list = new ArrayList<String>();
						this.month = month;
						this.year = year;

						Log.d(tag, "==> Passed in Date FOR Month: " + month + " " + "Year: " + year);
						Calendar calendar = Calendar.getInstance();
						setCurrentDayOfMonth(calendar.get(Calendar.DAY_OF_MONTH));
						setCurrentWeekDay(calendar.get(Calendar.DAY_OF_WEEK));
						Log.d(tag, "New Calendar:= " + calendar.getTime().toString());
						Log.d(tag, "CurrentDayOfWeek :" + getCurrentWeekDay());
						Log.d(tag, "CurrentDayOfMonth :" + getCurrentDayOfMonth());

						// Print Month
						printMonth(month, year);

						// Find Number of Events
						eventsPerMonthMap = findNumberOfEventsPerMonth(year, month);
					}
				private String getMonthAsString(int i)
					{
						return months[i];
					}

				private String getWeekDayAsString(int i)
					{
						return weekdays[i];
					}

				private int getNumberOfDaysOfMonth(int i)
					{
						return daysOfMonth[i];
					}

				public String getItem(int position)
					{
						return list.get(position);
					}

				@Override
				public int getCount()
					{
						return list.size();
					}

				/**
				 * Prints Month
				 * 
				 * @param mm
				 * @param yy
				 */
				private void printMonth(int mm, int yy)
					{
						Log.d(tag, "==> printMonth: mm: " + mm + " " + "yy: " + yy);
						// The number of days to leave blank at
						// the start of this month.
						int trailingSpaces = 0;
						int leadSpaces = 0;
						int daysInPrevMonth = 0;
						int prevMonth = 0;
						int prevYear = 0;
						int nextMonth = 0;
						int nextYear = 0;

						int currentMonth = mm - 1;
						String currentMonthName = getMonthAsString(currentMonth);
						daysInMonth = getNumberOfDaysOfMonth(currentMonth);

						Log.d(tag, "Current Month: " + " " + currentMonthName + " having " + daysInMonth + " days.");

						// Gregorian Calendar : MINUS 1, set to FIRST OF MONTH
						GregorianCalendar cal = new GregorianCalendar(yy, currentMonth, 1);
						Log.d(tag, "Gregorian Calendar:= " + cal.getTime().toString());

						if (currentMonth == 11)
							{
								prevMonth = currentMonth - 1;
								daysInPrevMonth = getNumberOfDaysOfMonth(prevMonth);
								nextMonth = 0;
								prevYear = yy;
								nextYear = yy + 1;
								Log.d(tag, "*->PrevYear: " + prevYear + " PrevMonth:" + prevMonth + " NextMonth: " + nextMonth + " NextYear: " + nextYear);
							}
						else if (currentMonth == 0)
							{
								prevMonth = 11;
								prevYear = yy - 1;
								nextYear = yy;
								daysInPrevMonth = getNumberOfDaysOfMonth(prevMonth);
								nextMonth = 1;
								Log.d(tag, "**--> PrevYear: " + prevYear + " PrevMonth:" + prevMonth + " NextMonth: " + nextMonth + " NextYear: " + nextYear);
							}
						else
							{
								prevMonth = currentMonth - 1;
								nextMonth = currentMonth + 1;
								nextYear = yy;
								prevYear = yy;
								daysInPrevMonth = getNumberOfDaysOfMonth(prevMonth);
								Log.d(tag, "***---> PrevYear: " + prevYear + " PrevMonth:" + prevMonth + " NextMonth: " + nextMonth + " NextYear: " + nextYear);
							}

						// Compute how much to leave before before the first day of the
						// month.
						// getDay() returns 0 for Sunday.
						int currentWeekDay = cal.get(Calendar.DAY_OF_WEEK) - 1;
						trailingSpaces = currentWeekDay;

						Log.d(tag, "Week Day:" + currentWeekDay + " is " + getWeekDayAsString(currentWeekDay));
						Log.d(tag, "No. Trailing space to Add: " + trailingSpaces);
						Log.d(tag, "No. of Days in Previous Month: " + daysInPrevMonth);

						if (cal.isLeapYear(cal.get(Calendar.YEAR)) && mm == 1)
							{
								++daysInMonth;
							}

						// Trailing Month days
						for (int i = 0; i < trailingSpaces; i++)
							{
								Log.d(tag, "PREV MONTH:= " + prevMonth + " => " + getMonthAsString(prevMonth) + " " + String.valueOf((daysInPrevMonth - trailingSpaces + DAY_OFFSET) + i));
								list.add(String.valueOf((daysInPrevMonth - trailingSpaces + DAY_OFFSET) + i) + "-GREY" + "-" + getMonthAsString(prevMonth) + "-" + prevYear);
							}

						// Current Month Days
						for (int i = 1; i <= daysInMonth; i++)
							{
								Log.d(currentMonthName, String.valueOf(i) + " " + getMonthAsString(currentMonth) + " " + yy);
								if (i == getCurrentDayOfMonth())
									{
										list.add(String.valueOf(i) + "-BLUE" + "-" + getMonthAsString(currentMonth) + "-" + yy);
									}
								else
									{
										list.add(String.valueOf(i) + "-WHITE" + "-" + getMonthAsString(currentMonth) + "-" + yy);
									}
							}

						// Leading Month days
						for (int i = 0; i < list.size() % 7; i++)
							{
								Log.d(tag, "NEXT MONTH:= " + getMonthAsString(nextMonth));
								list.add(String.valueOf(i + 1) + "-GREY" + "-" + getMonthAsString(nextMonth) + "-" + nextYear);
							}
					}

				/**
				 * NOTE: YOU NEED TO IMPLEMENT THIS PART Given the YEAR, MONTH, retrieve
				 * ALL entries from a SQLite database for that month. Iterate over the
				 * List of All entries, and get the dateCreated, which is converted into
				 * day.
				 * 
				 * @param year
				 * @param month
				 * @return
				 */
				private HashMap findNumberOfEventsPerMonth(int year, int month)
					{
						HashMap map = new HashMap<String, Integer>();
						return map;
					}

				@Override
				public long getItemId(int position)
					{
						return position;
					}

				@Override
				public View getView(int position, View convertView, ViewGroup parent)
					{
						View row = convertView;
						if (row == null)
							{
								LayoutInflater inflater = (LayoutInflater) _context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
								row = inflater.inflate(R.layout.day_gridcell, parent, false);
							}

						// Get a reference to the Day gridcell
						gridcell = (Button) row.findViewById(R.id.calendar_day_gridcell);
						gridcell.setBackgroundDrawable(getResources().getDrawable(R.drawable.grid_cell_background));
						gridcell.setOnClickListener(this);
						
						// ACCOUNT FOR SPACING

						Log.d(tag, "Current Day: " + getCurrentDayOfMonth());
						String[] day_color = list.get(position).split("-");
						String theday = day_color[0];
						String themonth = day_color[2];
						String theyear = day_color[3];
						if ((!eventsPerMonthMap.isEmpty()) && (eventsPerMonthMap != null))
							{
								if (eventsPerMonthMap.containsKey(theday))
									{
										num_events_per_day = (TextView) row.findViewById(R.id.num_events_per_day);
										Integer numEvents = (Integer) eventsPerMonthMap.get(theday);
										num_events_per_day.setText(numEvents.toString());
									}
							}
						
						// Set the Day GridCell
						// search through list of recipes, if recipe is here add "." if not add ""
						
						boolean textWithDayAndDot = false;
						Iterator recipesMonthIterator = recipesThisMonth.iterator();
						while (recipesMonthIterator.hasNext()) {
							// check all recipes for this month.
							String item = (String) recipesMonthIterator.next();
							if (item.equalsIgnoreCase("no meals for this day")==false) {
								if (Integer.valueOf(theday)==Integer.valueOf(item.split("%%%%")[4].split("-")[2])   
									&& Integer.valueOf(this.month)==Integer.valueOf(item.split("%%%%")[4].split("-")[1])  ) {
									// has recipe for this day, so include .
									textWithDayAndDot = true;
								}
							}
						}
						if (textWithDayAndDot) {
							gridcell.setText(theday+"\n.");
						} else {
							gridcell.setText(theday+"\n");
						}
						gridcell.setTag(theday + "-" + themonth + "-" + theyear);
						//gridcell.setTag(theday + "-" + this.month + "-" + theyear);
						String day_month_year_here = theday + "-" + themonth + "-" + theyear;
						//String day_month_year_here = theday + "-" + this.month + "-" + theyear;
						Log.d(tag, "Setting GridCell " + day_month_year_here);
						
						if(clicked_date_month_year.equals(day_month_year_here)){
							//gridcell.setBackgroundResource(R.color.opaque_red);
							gridcell.setBackgroundColor(Color.GREEN);
						}
						
						if (day_color[1].equals("GREY"))
							{
							    // NEXT month
								gridcell.setTextColor(Color.LTGRAY);
							}
						if (day_color[1].equals("WHITE"))
							{
								// day THIS month, NOT current day
								gridcell.setTextColor(Color.rgb(66, 41, 10));
							}
						if (day_color[1].equals("BLUE"))
							{
								//gridcell.setTextColor(getResources().getColor(R.color.static_text_color));
						        // CURRENT day
								gridcell.setTextColor(Color.rgb(66, 41, 10));
								gridcell.setBackgroundColor(Color.GRAY);
							}
						return row;
					}
				
				@Override
				public void onClick(View view)
					{
						String date_month_year = (String) view.getTag();
						//selectedDayMonthYearButton.setText("Selected: " + date_month_year);
						
						gridcell.invalidate();
						gridcell.setBackgroundColor(Color.GREEN);
						this.notifyDataSetChanged();
						//System.out.println("**** selected "+date_month_year);
						clicked_date_month_year = date_month_year;
						
						// format of date_month_year is now 3-October-2012.  we want 03-10-2012:
						// assume that user just clicked on a different day in the same month/year:
						int day = Integer.valueOf(date_month_year.split("-")[0]);
						String date_month_year_formated = "";
						if (day<10) {
						date_month_year_formated = "0"+day+"-"+this.month+"-"+this.year;
						} else {
							date_month_year_formated = ""+day+"-"+this.month+"-"+this.year;
						}
						
						try
							{
								Date parsedDate = dateFormatter.parse(date_month_year_formated); //date_month_year);
								Log.d(tag, "Parsed Date: " + parsedDate.toString());
								
								// day clicked:
								String dayClicked = date_month_year.split("-")[0].trim();
										
								if (Integer.valueOf(dayClicked)<10) {
									makeListForDayClicked("0"+dayClicked);
								} else {
									makeListForDayClicked(dayClicked);
								}

								mainListView = (ListView) findViewById( R.id.simplecalendarrow ); 
								CalendarTextButtonAdapter myTextButtonAdapter = new CalendarTextButtonAdapter(plannerCtx,mealListDayClicked); //myList);
								mainListView.setAdapter(myTextButtonAdapter); 
								
								// update adapte
								mainListView.invalidate();
							}
						catch (ParseException e)
							{
								e.printStackTrace();
							}
					}
					

				public int getCurrentDayOfMonth()
					{
						return currentDayOfMonth;
					}

				private void setCurrentDayOfMonth(int currentDayOfMonth)
					{
						this.currentDayOfMonth = currentDayOfMonth;
					}
				public void setCurrentWeekDay(int currentWeekDay)
					{
						this.currentWeekDay = currentWeekDay;
					}
				public int getCurrentWeekDay()
					{
						return currentWeekDay;
					}
			}
		private static final int Cookbook_ID = 0;
		private static final int Grocerylist_ID = 1;
		private static final int Search_ID = 2;
		private static final int Timers_ID = 3;
		private static final int Chef_ID = 4;
		static final int Add2GroceryList_ID = 5;
		static final int Add2Cookbook_ID = 6;
		static final int EmailRecipe_ID = 7;
		static final int RateRecipe_ID = 8;
		static final int DeleteRecipe_ID = 9;
		static final int Contact_ID = 10;
		static final int UpdateRecipe_ID = 11;
	    static final int DelecteRecipe_ID = 12;
	}
