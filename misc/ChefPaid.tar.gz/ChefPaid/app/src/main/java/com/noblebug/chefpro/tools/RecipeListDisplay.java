package com.noblebug.chefpro.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.cookbook.RecipePreviewButtonInfo;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.recipe.RecipeDisplay;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class RecipeListDisplay extends Activity {
    //public class RecipeListDisplay extends ListActivity {
	// class displays a list of recipes.
	// It uses RecipeButtonAdapter and RecipeInfo.
	// 4 June 2011 Jim Pizagno

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Adding in separators/breaks in List display.  (27 Aug 2011). 
		// If List is a particular Chef, then list is separated by Categories.
		// If List is a particular Cuisine, then list is separated by Categories.
		// If List is a particular Category, then list is separated by Cuisines.
		
		// fix phone orientation to PORTRAIT, no TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// try some garbage collection
		System.gc();
		
		// get cuisine/category/chef
		// displaytype = "chef::4","category::maincourse","cuisine::american"
		String displaytypename = getIntent().getStringExtra("How2Display");
		displaytype = displaytypename.split("::")[0];
		if (displaytype.equalsIgnoreCase("chef")) {
			displayname = displaytypename.split("::")[2];
		} else {
			displayname = displaytypename.split("::")[1];
		}
		System.out.println("****** RecipeListDisplay::onCreate displayname = "+displayname);
		if (displaytype.equalsIgnoreCase("cuisine")) {
			// get cuisine: USA, Germany, etc..
			//cuisinetype = getIntent().getStringExtra("cuisinetype");
			cuisinetype = displaytypename.split("::")[1];
		} else if (displaytype.equalsIgnoreCase("category")) {
			// category: get category: brunch,dessert,main courses
			//categorytype = getIntent().getStringExtra("categorytype");
			categorytype = displaytypename.split("::")[1];
		} else {
			chefid = Integer.valueOf(displaytypename.split("::")[1]);
		}

		// open database
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();

		
		// make and define the clear windowframe
    	buttonheight = this.getWindowManager().getDefaultDisplay().getHeight()/8;
    	width = this.getWindowManager().getDefaultDisplay().getWidth();
    	windowYfraction = (float) 0.80;
    	windowXfractionChef = (float) 0.17;
    	windowXfractionNotChef = (float) 0.25;
    	// flag and window size:
    	flagYsize = (int) ((float)buttonheight *windowYfraction); //70/100;  ///2;
    	flagXsize = (int)((float)this.getWindowManager().getDefaultDisplay().getWidth()*windowXfractionNotChef); //20/100; 
		// window position:
		windowXposition = flagXsize*1/6;
    	windowYposition = buttonheight*1/10;
    	// text position:
    	textX = this.getWindowManager().getDefaultDisplay().getWidth()*30/100;  // *2/5;*2/5;
		textY = buttonheight*55/100;
		
		// for XML recipeinfo
		float temp = (float) ((90.0/854.0) * (float) this.getWindowManager().getDefaultDisplay().getHeight());
		webviewScalePerc = (int) temp;  //must be between 0-100. percentage
		
		
    	// define layout
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setBackgroundResource(R.drawable.cookbookbackground);

		// add Title
		// USE displaytype + displayname  on title:
		LinearLayout innerLayout = new LinearLayout(this);
		innerLayout.setGravity(Gravity.CENTER);
		innerLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.WRAP_CONTENT));
		TextView title = new TextView(this);
		title.setText(displayname);
		title.setTextColor(Color.WHITE);
		title.setBackgroundResource(R.drawable.blanktitle);
		title.setGravity(Gravity.CENTER);
		Typeface myType = Typeface.create(Typeface.SERIF, Typeface.NORMAL);
		title.setTypeface(myType);
		if (this.getWindowManager().getDefaultDisplay().getHeight() > 600) {  
			// this If()else statement accounts for devices with different sizes
			title.setTextSize(36);
		} else {
			title.setTextSize(18);
		}
		innerLayout.addView(title, this.getWindowManager().getDefaultDisplay().getWidth(), 
				this.getWindowManager().getDefaultDisplay().getHeight()*10/100);
		mLinearLayout.addView(innerLayout);
		
		
		// if Chef, then cycle through each category and query DB for Chef && Category
		recipe_info = new ArrayList<RecipePreviewButtonInfo>();
		if (displaytype.equalsIgnoreCase("chef") | displaytype.equalsIgnoreCase("cuisine")){
			String[] categories = this.getResources().getStringArray(R.array.categories);
			for (int category_i=0;category_i<categories.length;category_i++){
				if (categories[category_i].equalsIgnoreCase("all")==false) {
					RecipePreviewButtonInfo mybreak = new RecipePreviewButtonInfo(this);
					mybreak.setType(RecipePreviewButtonInfo.BREAK);
					mybreak.setBreakText(categories[category_i]);
					mybreak.setXY(this.width, this.buttonheight/2);
					// query DB for category and Chef
					Cursor category_cursor;
					if (displaytype.equalsIgnoreCase("chef")) {
						category_cursor = mDbHelper.getCategoryChef(chefid,categories[category_i]);
					} else {
						category_cursor = mDbHelper.getCategoryCuisine(cuisinetype,categories[category_i]);
						System.out.println("******* RecipeListDisplay::onCreate cuisines categorycursor size = "+String.valueOf(category_cursor.getCount()));
					}
					
					if (category_cursor.getCount()>0){
						// only add breakpoint to arraylist if count is !=0.
						recipe_info.add(mybreak);
					}
					for (int m = 0; m < category_cursor.getCount(); m++) {
						category_cursor.moveToPosition(m);
						String name = category_cursor.getString(category_cursor
								.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPENAME));
						name = elideText(name, this.getWindowManager().getDefaultDisplay().getWidth());
						System.out.println("******* RecipeListDisplay::onCreate categories[category_i]="+categories[category_i]);
						System.out.println("******* RecipeListDisplay::onCreate name="+name);
						String imagehttp = category_cursor.getString(category_cursor
								.getColumnIndexOrThrow(BackEndSQLite.KEY_IMAGEHTTP));
						RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this);
						if (imagehttp!=null) { // recipe has no image ??. if recipe has "no" image then this is getting what?
							if (imagehttp.length()==0){
								// somehow recipe can be notnull but not have length.  this is problably
								// an error with downloading bookmarked recipes after user logs in.
								myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
								myrecipe.setResource(R.drawable.defaultrecipeimage);
							} else {
								String imagename = imagehttp.split("/")[imagehttp.split("/").length - 1];
								myrecipe.setDrawableFileName(imagename);
								myrecipe.setType(RecipePreviewButtonInfo.FILEONDISK);
							}
						} else {
							myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
							myrecipe.setResource(R.drawable.defaultrecipeimage);
						}
						float rating = category_cursor.getFloat(category_cursor
								.getColumnIndexOrThrow(BackEndSQLite.KEY_RATING));
						final Integer recipeid = category_cursor.getInt(category_cursor
										.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID));
						myrecipe.setButtonText(name);
						myrecipe.setXY(this.width, this.buttonheight);
						myrecipe.setXYFrame(this.flagXsize,this.flagYsize);
						myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
						myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
						myrecipe.addID(recipeid);
						myrecipe.addRating(rating);
						recipe_info.add(myrecipe);
					}
					category_cursor.close();
				}
			}
		} else {
			// Display type is categories, so sort by cuisine
			String[] cuisines = this.getResources().getStringArray(R.array.cuisines);
			for (int cuisines_i=0;cuisines_i<cuisines.length;cuisines_i++){
				RecipePreviewButtonInfo mybreak = new RecipePreviewButtonInfo(this);
				mybreak.setType(RecipePreviewButtonInfo.BREAK);
				mybreak.setBreakText(cuisines[cuisines_i]);
				mybreak.setXY(this.width, this.buttonheight/2);
				// query DB for category and Chef
				Cursor cuisines_cursor;
				cuisines_cursor = mDbHelper.getCategoryCuisine(cuisines[cuisines_i],categorytype);
				if (cuisines_cursor.getCount()>0){
					// only add breakpoint to arraylist if count is !=0.
					recipe_info.add(mybreak);
				}
				for (int m = 0; m < cuisines_cursor.getCount(); m++) {
					cuisines_cursor.moveToPosition(m);
					String name = cuisines_cursor.getString(cuisines_cursor
							.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPENAME));
					name = elideText(name, this.getWindowManager().getDefaultDisplay().getWidth());
					String imagehttp = cuisines_cursor.getString(cuisines_cursor
							.getColumnIndexOrThrow(BackEndSQLite.KEY_IMAGEHTTP));
					RecipePreviewButtonInfo myrecipe = new RecipePreviewButtonInfo(this);
					if (imagehttp!=null) { // recipe has no image ??. if recipe has "no" image then this is getting what?
						if (imagehttp.length()==0){
							// somehow recipe can be notnull but not have length.  this is problably
							// an error with downloading bookmarked recipes after user logs in.
							myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
							myrecipe.setResource(R.drawable.defaultrecipeimage);
						} else {
							String imagename = imagehttp.split("/")[imagehttp.split("/").length - 1];
							myrecipe.setDrawableFileName(imagename);
							myrecipe.setType(RecipePreviewButtonInfo.FILEONDISK);
						}
					} else {
						myrecipe.setType(RecipePreviewButtonInfo.RESOURCE);
						myrecipe.setResource(R.drawable.defaultrecipeimage);
					}
					float rating = cuisines_cursor.getFloat(cuisines_cursor
							.getColumnIndexOrThrow(BackEndSQLite.KEY_RATING));
					final Integer recipeid = cuisines_cursor.getInt(cuisines_cursor
									.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID));
					myrecipe.setButtonText(name);
					myrecipe.setXY(this.width, this.buttonheight);
					myrecipe.setXYFrame(this.flagXsize,this.flagYsize);
					myrecipe.setscreenHeight(this.getWindowManager().getDefaultDisplay().getHeight());
					myrecipe.setscreenWidth(this.getWindowManager().getDefaultDisplay().getWidth());
					myrecipe.addID(recipeid);
					myrecipe.addRating(rating);
					recipe_info.add(myrecipe);
				}
				cuisines_cursor.close();
			}
		}

		// give collection to instance of adapter
		final ListView myListView = new ListView(this);
		myListView.setCacheColorHint(Color.TRANSPARENT);
		myListView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		this.adapter_fileorresource = new RecipeButtonAdapter(this, R.layout.rowfileresource, recipe_info);
		myListView.setAdapter(this.adapter_fileorresource);
		// give adapter to layoutmanager
	    mLinearLayout.addView(myListView);
		
	    // make clickable
	    //myListView.setClickable(true);
        //myListView.setFocusable(true);
        myListView.setDividerHeight(0);
        myListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View view, int position, long ID) {
				// check if item is breakpoint, ignore click if breakpoint
				if (((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getType()==RecipePreviewButtonInfo.BREAK){
					// do nothing
				} else {
					int recipeid = ((RecipePreviewButtonInfo) myListView.getItemAtPosition(position)).getID();
					mDbHelper.close();
					callRecipeDisplay(recipeid);
				}
			}
		});
        
        mDbHelper.close();
        // display everything to the screen
        setContentView(mLinearLayout);
	}

	 public String setManySpaces2OneSpace(String input){
    	// this method is used to remove too many white spaces in a string.
    	// if upper2LowerCase has too many white spaces, then the code bombs
    	input.trim();
    	String temp5 = input.replace("     "," ");
    	String temp4 = temp5.replace("    "," ");
    	String temp3 = temp4.replace("   "," ");
    	String outstring = temp3.replace("  "," ");
    	return outstring;
	 }
	    
	
    public String upper2LowerCase(String input){
    	// this method convert the string to First letter upper case, other letteers lowercase.
    	// it allows a more even scaling of the words in elideText
    	input = input.trim();  //some people put spaces at beggining and end of recipe.
    	//System.out.println("RecipeListDisplay::upper2LowerCase input = "+input);
    	String outString = "";
    	input = setManySpaces2OneSpace(input);
    	String[] words = input.split(" ");
    	for (int i=0;i<words.length;i++) {
    		//System.out.println("RecipeListDisplay::upper2LowerCase words[i] = "+words[i]);
    		String firstLetter = words[i].substring(0,1);  // Get first letter
    		String remainder   = words[i].substring(1); 
    		String capitalized = firstLetter.toUpperCase() + remainder.toLowerCase();
    		outString = outString +" "+capitalized;
    	}
    	return outString;
    }
	
	public String elideText(String texttmp, Integer screenwidth){
		//System.out.println("RecipeListDisplay::elideText texttmp = "+texttmp);
		// shortens the text.  I think (4June2011) this needs to be worked on.
		String text = upper2LowerCase(texttmp);
		String elidedtext;
		int length = (int)(-0.0125* (float)screenwidth) + 26; 
		if (length>text.length()){
			elidedtext = text;
		} else {
			elidedtext = text.substring(0, length)+"...";
		}
		return elidedtext;
	}
   
	public void callRecipeDisplay(Integer recipeid) {
		Intent i = new Intent(this, RecipeDisplay.class);
		i.putExtra("RecipeId2View", recipeid);
		startActivity(i);
	}


	@Override
	protected void onStop() {
		super.onStop();
		NameAlreadyAdded.clear();
		mDbHelper.close();
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "").setIcon(home);

		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void gotoChef() {
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}

	private void createTimers() {
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		// Intent i = new Intent(this, ChefCountdownTimer.class);
		startActivity(i);
	}

	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	// fields
	private static final int Cookbook_ID = 0;
	private static final int Grocerylist_ID = 1;
	private static final int Search_ID = 2;
	private static final int Timers_ID = 3;
	private static final int Chef_ID = 4;
	private BackEndSQLite mDbHelper;
	static Map<String, Integer> NameAlreadyAdded = new HashMap<String, Integer>();
	private static final int ACTIVITY_RECIPELISTDISPLAY = 0;
	public String cuisinetype;
	private String displaytype;
	private String categorytype;
	private Integer chefid;
	private LinearLayout mLinearLayout;
	private String displayname;
	public int buttonheight;
	public float windowYfraction;
	public float windowXfractionNotChef;
	public int windowXposition;
	public int windowYposition;
	public int textX;
	public int textY;
	public int flagYsize;
	public int width;
	public int flagXsize;
	public float windowXfractionChef;
	private ArrayList<RecipePreviewButtonInfo> recipe_info = null;
	private int webviewScalePerc;
	private RecipeButtonAdapter adapter_fileorresource;

}
