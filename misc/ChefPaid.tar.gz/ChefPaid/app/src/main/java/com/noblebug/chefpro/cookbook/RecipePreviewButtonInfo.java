package com.noblebug.chefpro.cookbook;

import com.noblebug.chefpro.tools.ImageHandler;

import android.content.Context;
import android.graphics.drawable.Drawable;

public class RecipePreviewButtonInfo {
	// class that holds information about revipe preview buttons.
	// preview buttons can be webviews,resources, or files on disk.
	// it is put into a collection and called by getView() in adapter.
	// 4 June 2011

	
	public RecipePreviewButtonInfo(Context Ctxtmp){
    	this.Ctx = Ctxtmp;
    }
	public int getscreenWidth(){
    	return screenWidth;
    }
    public void setscreenWidth(int tmp){
    	this.screenWidth=tmp;
    }
    public int getscreenHeight(){
    	return screenHeight;
    }
    public void setscreenHeight(int tmp){
    	this.screenHeight=tmp;
    }
    
    public String getButtonText() {
        return buttonText;
    }
    public void setButtonText(String Name) {
        this.buttonText = Name;
    }
    
    // for Resource
	public Drawable getResource() {
		return Ctx.getResources().getDrawable(this.DrawableResourceInt);
	}
	public void setResource(int tmp) {
		this.DrawableResourceInt=tmp;
	}

	// for type webview,resource,file
	public void setType(int tmp){
		this.type = tmp;
	}
	public int getType(){
		return this.type;
	}
	
	// for webview
	public void setWebViewAddress(String tmp, int tmp2) {
		this.urlWebView = tmp;
		this.webviewScalePerc = tmp2;
	}
	public int getwebviewScalePerc(){
		return this.webviewScalePerc;
	}
	public String getWebViewAddress(){
		return this.urlWebView;
	}
	
	// set XY size of button
	public void setXY(int tmp1, int tmp2){
		this.sizeX = tmp1;
		this.sizeY = tmp2;
	}
	public int getX(){
		return this.sizeX;
	}
	public int getY() {
		return this.sizeY;
	}
	
	// get the window frame sizes and position
	public int getFrameX(){
		return this.FramerowX;
	}
	public int getFrameY(){
		return this.FramerowY;
	}
	public void setXYFrame(int tmp1,int tmp2) {
		this.FramerowX = tmp1; 
		this.FramerowY = tmp2;
	}
	
	// get file on disk
	public void setDrawableFileName(String tmp) {
		this.filenameondisk = tmp;
	}
	public Drawable getDrawableFile() {
		ImageHandler myImgHandler = new ImageHandler();
		return myImgHandler.getimageDrawable(this.filenameondisk);
	}
	
	// recipe id, needed for when button is clicked
	public void addID(int tmp) {
		this.recipeid = tmp;
	}
	public int getID() {
		return this.recipeid;
	}
	public void addRating(float tmp) {
		this.rating = tmp;
	}
	public float getRating() {
		return this.rating ;
	}
	public void setChefID(int tmp){
		this.chefid = tmp;
	}
	public int getChefID(){
		return this.chefid;
	}
	
	public void setBreakText(String tmp) {
		// used for break in Recipe List:  called by RecipeListDispla.java.  just a string in between the curly lines.
		breaktext = tmp;
	}
	public String getBreakText(){
		// returns break text.  called by RecipeButtonAdapter.
		return breaktext;
	}
	
	private String breaktext;
	private int screenWidth;
	private int screenHeight;
	private String buttonText;
	private int DrawableResourceInt;
	public Context Ctx;
	private int type;
	public boolean partofCookbook = false;
	private String urlWebView;
	private int webviewScalePerc;
	private int sizeX;
	private int sizeY;
	private int FramerowX;
	private int FramerowY;
	private String filenameondisk;
	private int recipeid;
	private float rating;
	private String CuisineOrCategory;
	private int chefid;
	public static final int WEBVIEW = 0;
	public static final int FILEONDISK = 1;
	public static final int RESOURCE = 2;
	public static final int DEFAULT = 3;
	public static final int BREAK = 4;

}
