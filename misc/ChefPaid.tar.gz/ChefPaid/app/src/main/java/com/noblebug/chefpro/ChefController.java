package com.noblebug.chefpro;

import java.util.HashMap;
import java.util.Map;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.Cookbook;
import com.noblebug.chefpro.grocerylist.GroceryList;
import com.noblebug.chefpro.settings.Settings;
import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;

public class ChefController extends Application {
	/*
	 * This is the controller.  it passes cookbook,grocerylist,and settings info.  Since it can be killed by 
	 * the JVM, the database may be replacing some of the Controller's functionality.  Jim 12May2011.
	 */
	
	private static final int CONNECTION_TIMEOUT_milliSec = 30 * 1000;
	private static final int WAIT_RESPONSE_TIMEOUT_milliSec  = 30 * 1000;
	
	public void setUIDandPASSWD(String uID, String password) {
		// sets userID and password
		this.userid = uID;
		this.password = password;
	}
	
	public String getUIDandPASSWD() {
		// gets the userid and pass word
		//System.out.println("getUIDandPASSWD  userid = "+userid);
		return this.userid + "_" + this.password;
	}
	
	// this map is used to keep track of the most recent recipe search.  This map should only be 1 item long.
	public static Map<String, String> RecipeSearchMap = new HashMap<String, String>();
	public void setRecipeSearchMap(Map<String, String> RecipeSearchMaptmp ) {
		// sets the recipe search map.  it is used by the recipe search to remember the last recipe.
		RecipeSearchMap = RecipeSearchMaptmp;
	}
	public Map<String, String> getRecipeSearchMap() {
		// getter method for the recipesearchmap
		return RecipeSearchMap;
	}
	
	public ChefController() {
		// pass
	}
	
	public ChefController(Context Ctx) {
		// just checks for an internet connection
		//System.out.println("****** chefcontroller created");
		this.internetConnectionOpen = check4InternetConnection(Ctx);
	}
	
	
	public boolean check4InternetConnection(Context Ctx){
			// The getActiveNetworkInfo() method of ConnectivityManager returns a NetworkInfo instance 
			// 		representing the first connected network interface it can find or null if none if the 
			// 		interfaces are connected. Checking if this method returns null should be enough to tell if 
			// 		an internet connection is available.
		    ConnectivityManager connectivityManager 
		          = (ConnectivityManager) Ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
		    android.net.NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		    
		    boolean answer = (activeNetworkInfo != null);
		    this.internetConnectionOpen = answer;
		    return answer;
		
		//// first check to see if the device has an internet connection at all.
		//boolean result;
		//String address = "http://www.chefslittlehelper.com/";
		//URL myFileUrl = null;
		//try {
		//	myFileUrl = new URL(address);
		//	result = true;
		//} catch (MalformedURLException e) {
		//	e.printStackTrace();
		//	result = false;
		//}
		//try {
		//	HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
		//	conn.setDoInput(true);
		//	conn.connect();
		//	result = true;
		//	// check to make sure the user is not required to enter a password
		//	result = check4ConnectionOutOfProvider(); 
		//} catch (IOException e) {
		//	e.printStackTrace();
		//	result = false;
		//}
		//return result;
	}

	/*
	private boolean check4ConnectionOutOfProvider() {
		boolean result = false;
		// This method checks for an internet connection.  
		// There may be a situation where the phone/device is connected to the internet
		//    but the internet may request a password. This is typical for a WiFi hotspot.
		// So check for an actual result from chefslittlehelper.com.  
		// The quickest PHP script seems to be validateuser.php.
		// If the wrong password is given:  then "Incorrect password" may be returned.
		// If the correct password is given:  then Success^^4^^jpizagno is returned.
		// If a hotspot is there, then one gets something like: <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		String url = "http://www.chefslittlehelper.com/API/android/1.0.0/validateuser.php?user=";
		url = url + "jpizagno";
		url = url + "&password=junk";
		//System.out.println("***** ChefController::check4IntenerConnection url = " + url);
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			String Result = stream2text.GetText(response);
			//System.out.println("****** ChefController::check4internet connection BUT uidResult = "+Result);
			if (Result.contains("Incorrect") | Result.contains("^^")){
				// then connection to help is okay
				result = true;
			} else {
				// no result
				result = false;
			}
		} catch (Exception ex) {
			// internet connection may be entirely dead.
			//System.out.println("****** ChefController::check4internet FAIL");
			result = false;
		}
		return result;
	}
	*/

	public void createObjects(Context tempcontext) {
		// create objects cookbook, grocerylist
		this.mContext = tempcontext;
		//System.out.println("**** ChefController createObjects() called");
		// create cookbook
		myCookbook = new Cookbook(this.mContext);
		myCookbook.setupValues();

		// create grocerylist
		myGrocerylist = new GroceryList(this.mContext, userid, password);
		myGrocerylist.fillAdapters(AisleList);

		mySettings = new Settings();
	}

	public void setAllTimersZero() {
		// "zeros" timers
		// called when app is first uploaded
		this.timer1time = (long) 0.0;
		this.stillticking1 = false;
		this.date1millisec = (long)0.0;
		this.item1 = "item";
		this.timer2time = (long) 0.0;
		this.stillticking2 = false;
		this.date2millisec = (long)0.0;
		this.item2 = "item";
		this.timer3time = (long) 0.0;
		this.stillticking3 = false;
		this.date3millisec = (long)0.0;
		this.item3 = "item";
		this.timer4time = (long) 0.0;
		this.stillticking4 = false;
		this.date4millisec = (long)0.0;
		this.item4 = "item";
	}
	public void setTimer1time(long temp, Long date1temp, boolean b, String tempitem) {
		// sets the time,date,stillticking boolean, and item name for timer1
		this.timer1time=temp;
		this.date1millisec = date1temp;
		this.stillticking1 = b;
		this.item1 = tempitem;
		//System.out.println("**** Controller:  time1="+String.valueOf(temp)+" date=" +
		//		String.valueOf(date1temp)+" stillticking1="+String.valueOf(b) +
		//		" item1="+this.item1);
	}

	public void setTimer2time(long temp, Long datetemp, boolean b, String tempitem) {
		// sets the time,date,stillticking boolean, and item name for timer2
		this.timer2time=temp;
		this.date2millisec = datetemp;
		this.stillticking2 = b;
		this.item2 = tempitem;
		//System.out.println("**** Controller:  time2="+String.valueOf(temp)+" date=" +
		//		String.valueOf(datetemp)+" stillticking2="+String.valueOf(b) +
		//		" item2="+this.item2);
	}
	public void setTimer3time(long temp, Long datetemp, boolean b, String tempitem) {
		// sets the time,date,stillticking boolean, and item name for timer3
		this.timer3time=temp;
		this.date3millisec = datetemp;
		this.stillticking3 = b;
		this.item3 = tempitem;
		//System.out.println("**** Controller:  time3="+String.valueOf(temp)+" date=" +
		//		String.valueOf(datetemp)+" stillticking3="+String.valueOf(b) +
		//		" item3="+this.item3);
	}
	public void setTimer4time(long temp, Long datetemp, boolean b, String tempitem) {
		// sets the time,date,stillticking boolean, and item name for timer4
		this.timer4time=temp;
		this.date4millisec = datetemp;
		this.stillticking4 = b;
		this.item4 = tempitem;
		//System.out.println("**** Controller:  time4="+String.valueOf(temp)+" date=" +
		//		String.valueOf(datetemp)+" stillticking4="+String.valueOf(b) +
		//		" item4="+this.item4);
	}
	
	public String getTimer1timeDate1() {
		// gets info for timer 1
		return String.valueOf(this.timer1time)+"::"+String.valueOf(this.date1millisec)
		+"::"+String.valueOf(this.stillticking1)+"::"+this.item1;
	}
	public String getTimer2timeDate2() {
		// gets info for timer 2
		return String.valueOf(this.timer2time)+"::"+String.valueOf(this.date2millisec)
		+"::"+String.valueOf(this.stillticking2)+"::"+this.item2;
	}
	public String getTimer3timeDate3() {
		// gets info for timer 3
		return String.valueOf(this.timer3time)+"::"+String.valueOf(this.date3millisec)
		+"::"+String.valueOf(this.stillticking3)+"::"+this.item3;
	}
	public String getTimer4timeDate4() {
		// gets info for timer 4
		return String.valueOf(this.timer4time)+"::"+String.valueOf(this.date4millisec)
		+"::"+String.valueOf(this.stillticking4)+"::"+this.item4;
	}
	
	// create object getter methods
	public Cookbook getCookbook() {
		return myCookbook;
	}
	public GroceryList getGrocerylist() {
		return myGrocerylist;
	}
	public Settings getSettings() {
		return mySettings;
	}

	// create object setter methods
	public void setGroceryList(GroceryList tempGrocerylist) {
		this.myGrocerylist = tempGrocerylist;
	}
	public void setCookbook(Cookbook tempCookbook) {
		this.myCookbook = tempCookbook;
	}
	public void setSettings(Settings tempSettings) {
		this.mySettings = tempSettings;
	}

	public void setDefaultAisleList() {
		// used when phone is first installed, and maybe when the phone is turned off.  
		AisleList[0] = "FRUIT";
		AisleList[1] = "VEGETABLE";
		AisleList[2] = "HERBS_SPICE_AND_SEASONING";
		AisleList[3] = "BAKING_SUPPLIES";
		AisleList[4] = "BAKERY";
		AisleList[5] = "CAKES_PIES_PASTRIES";
		AisleList[6] = "BABY";
		AisleList[7] = "DELI";
		AisleList[8] = "SEAFOOD";
		AisleList[9] = "DAIRY";
		AisleList[10] = "CHEESE";
		AisleList[11] = "CANNED_GOODS";
		AisleList[12] = "BEVERAGES";
		AisleList[13] = "ALCOHOL";
		AisleList[14] = "PASTA";
		AisleList[15] = "SAUCE";
		AisleList[16] = "CONDIMENTS";
		AisleList[17] = "NUTS";
		AisleList[18] = "BREAKFAST";
		AisleList[19] = "DESSERTS";
		AisleList[20] = "Misc.";
	}

	public void setAisle(String[] tempstring) {
		// this is setting the aisle list.  this is done after the aisle list is edited.
		AisleList = tempstring;
		// save new Aislelist to the database:
		BackEndSQLite myDB = new BackEndSQLite(this.mContext);
		myDB.open();
		//String temp = myDB.getUserIDpassword();
		String[] temp = myDB.getUserSingle(); //username+"_"+password+"_"+md5password+"_"+useridout
		String UID = temp[3];
		myDB.updateAislelist(Integer.valueOf(UID), AisleList);
		myDB.close();
	}
	
	public String[] getAisleList() {
		// getter method for Aislist
		return AisleList;
	}

	public void setStartingPage(String temp) {
		// sets the starting page. user can set the starting page (home,cookbook,grocerylist,search,timer)
		startingPage = temp;
		//add to database
		BackEndSQLite myDB = new BackEndSQLite(this.mContext);
		myDB.open();
		myDB.setStartingPage(this.userid,startingPage);
		myDB.close();
	}
	public String getStartingPage() {
		// getter method for starting page
		return startingPage;
	}

	public void setQuantityGroceryList(boolean b) {
		// setter method for grocerylist quantity.  maybe this is not currently (12May) used.
		QuantityGroceryList = b;
	}
	public void setDisableSleep(boolean b) {
		// setter method for disable sleep.  mabye this is not currently(12may) used.
		DisableSleep = b;
	}
	public void setShowQuantBadge(boolean b) {
		// setter method for quantity badge. maybe this is not currently(12may) used.
		ShowQuantBadge = b;
	}

	// field definitions
	boolean QuantityGroceryList;
	boolean DisableSleep;
	boolean ShowQuantBadge;
	 Cookbook myCookbook;
	 GroceryList myGrocerylist;
	private Context mContext;
	private Settings mySettings;
	public String[] AisleList = new String[21];
	//  variables okay, because variable fixed with controller instance.
	 static private String userid;
	 static private String password;
	String startingPage = "" +	"Home"; // Home,Search,Cookbook,Grocerylist,Timers
	 Long timer1time = (long)0.0;
	 Long date1millisec;
	boolean stillticking1 = false;
	 String item1;
	 Long timer2time = (long)0.0;
	 Long timer3time = (long)0.0;
	 Long timer4time = (long)0.0;
	private Long date2millisec;
	private String item2;
	private boolean stillticking2;
	private Long date3millisec;
	private boolean stillticking3;
	private String item3;
	private Long date4millisec;
	private boolean stillticking4;
	private String item4;
	public boolean internetConnectionOpen = false;
}
