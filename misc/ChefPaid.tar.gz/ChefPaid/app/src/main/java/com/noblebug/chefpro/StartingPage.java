package com.noblebug.chefpro;

//import com.android.vending.licensing.LicenseChecker;
//import com.android.vending.licensing.LicenseCheckerCallback;
import com.google.android.vending.licensing.AESObfuscator;
import com.google.android.vending.licensing.LicenseChecker;
import com.google.android.vending.licensing.LicenseCheckerCallback;
import com.google.android.vending.licensing.Policy;
import com.google.android.vending.licensing.ServerManagedPolicy;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


public class StartingPage extends Activity {
  //added functionality for the user to change 
  //the startingpage.  created a StartingPage.java activity, 
  //that is simple, and is called by the AndroidManifest.XML file.  
  //All it does is query the database to figure out which page the user 
  //has set as the starting page. default is Home.java.
  // this is the first activity that the phone goes to.  it doesn't display anything.
  // 12May2011  Jim Pizagno
	//
	// 26Sept2011,  Added back in the LVL library.  For now maybe we should just make the code
	// politely ask the user to buy chef if they have not already done so?
  //
  
  // key for licensing, which is checked by Google server and client's phone:
    private static final String BASE64_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhIg3WKLSFQyPpOiKYyfuAwKtyFsBEMOqtdJ5mQP4B7WDLXUlByEix6RL3dCxwnlAtxnLmajN1MUS1RwMbG/BSWQL+PbfBEaNAkX1Xt2S7VnfUAG3a0lzRGnm+y5TIWQtqDt60w2m4tJE8dKOh0GWQLgQ38t8puvqbnMowZrn+tuUUCFkEnqo3MvG9XkbaJ/h3lfyZkWC+KrGz6g6MzS2arZ4/nPstEccB/6K+BiInzSyV2kS5pYDJo3hq5X2pedPTuDT1z9t70DPll8ecQl8NddQ/MJGNuXdgvbKD2J5HUc486uSZm8YSQLKt50T52n8GTriz2qRCCZHxH6ubGJBXwIDAQAB";

    // Generate your own 20 random bytes, and put them here.
    // used python:  for i in range(20): print random.random()*200-100
    private static final byte[] SALT = new byte[] {
        -46, 27, -29, -100, 20, -37, 74, 12, -47, -61, -22, 56, -9, 14, 65, -28, 56, 89, -81,
        74
    };

    //private TextView mStatusText;
    //private Button mChefCheckLicenseButton;

    private LicenseCheckerCallback mChefLicenseCheckerCallback;
    private LicenseChecker mChefChecker;
    // A handler on the UI thread.
    private Handler mChefHandler;

	private StartingPage Ctx;
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
	  // this is the first activity called.
    super.onCreate(savedInstanceState);
    
    Ctx = this;
    
    // GoogleLicenseCheck

    // Try to use more data here. ANDROID_ID is a single point of attack.
    String deviceId = Secure.getString(getContentResolver(), Secure.ANDROID_ID);

    // Library calls this when it's done.
    mChefLicenseCheckerCallback = new ChefMyLicenseCheckerCallback();
    // Construct the LicenseChecker with a policy.
    mChefChecker = new LicenseChecker(
        this, 
        new ServerManagedPolicy(this, new AESObfuscator(SALT, getPackageName(), deviceId)),
        BASE64_PUBLIC_KEY);
    mChefHandler = new Handler();
    

    boolean makeCheck = getIntent().getBooleanExtra("makecheck", true);
    
    if (makeCheck) {
    	doChefCheck();
    } else {  
	    // Regular Chef stuff here:
	    // this is really just looking for the starting page (Home,Recpe, Cookbook, etc..)
	    BackEndSQLite mDbHelper = new BackEndSQLite(this);
	    mDbHelper.open();
	    //mDbHelper.setWakeLockInitial();
	    // check for alternate starting page:
	    // options:  "Home" "Cookbook" "List" "Search" "Timers"
	    try {
	      String userid = mDbHelper.getUserSingle()[3];
	      //String userid = mDbHelper.getUserIDpassword().split("_")[0];
	      String startingPage = mDbHelper.getStartingPage(userid); 
	      createInitialKeysInKeySettingsTable(mDbHelper, userid);
	      mDbHelper.close();
	      if (startingPage.equalsIgnoreCase("Cookbook")){
	        this.createCookbook();
	      }
	      if (startingPage.equalsIgnoreCase("Grocery List")){
	        this.createGroceryList();
	      }
	      if (startingPage.equalsIgnoreCase("Search")){
	        this.createSearch();
	      }
	      if (startingPage.equalsIgnoreCase("Timers")){
	        this.createTimers();
	      }
	      if (startingPage.equalsIgnoreCase("Home")){
	        this.createHome();
	      }
	    } catch (Exception ex) {
	      mDbHelper.close();
	      ex.printStackTrace();
	      this.createHome();
	    }
    }
    
  }
  
  private void createInitialKeysInKeySettingsTable(BackEndSQLite mDbHelper, String userid) {
	mDbHelper.setWakeLockInitial(userid);	
}

private void createHome(){
    // goto Home
    Intent i = new Intent(this, Home.class);
    startActivity(i);
  }
  
  private void createTimers() {
    // goto timers
    Intent i = new Intent(this, TimersDisplay.class);
    startActivity(i);
  }

  private void createSearch() {
    // goto search
    Intent i_search = new Intent(this, SearchDisplay.class);
    startActivity(i_search);
  }

  private void createGroceryList() {
    // goto grocerylist
    Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
    startActivityForResult(i_grocerylist, 0);
  }

  private void createCookbook() {
    // goto cookbook
    Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
    i_cookbook.putExtra("cookbookState","chefs");
    startActivity(i_cookbook);
  }
  
    protected Dialog onCreateDialog(int id) {
        // We have only one dialog, which is displayed if the LVL software detects licensing issues.
        return new AlertDialog.Builder(this)
            .setTitle(R.string.unlicensed_dialog_title)
            .setMessage(R.string.unlicensed_dialog_body)
            .setPositiveButton(R.string.buy_button, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(
                        "http://market.android.com/details?id=" + getPackageName()));
                    startActivity(marketIntent);
                }
            })
            .setNegativeButton(R.string.goto_chef_anyway_button, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    //finish();
                	callSelfNoCheck();
                }
            })
            .create();
    }

    private void callSelfNoCheck(){
    	Intent i = new Intent(Ctx, StartingPage.class);
		i.putExtra("makecheck", false);
		startActivity(i);
    }
    
    private void doChefCheck() {
        //mChefCheckLicenseButton.setEnabled(false);
        setProgressBarIndeterminateVisibility(true);
        //mStatusText.setText(R.string.checking_license);
        mChefChecker.checkAccess(mChefLicenseCheckerCallback);
    }
    
    private void displayResult(final String result) {
        mChefHandler.post(new Runnable() {
            public void run() {
              //System.out.println("****** Chef Message from Starting page MyLicenseCheckerCallback:displayResult result = "+result);
                //mStatusText.setText(result);
                setProgressBarIndeterminateVisibility(false);
                //mChefCheckLicenseButton.setEnabled(true);
            }
        });
    }
    private void displayDialog(final boolean showRetry) {
        mChefHandler.post(new Runnable() {
            public void run() {
                setProgressBarIndeterminateVisibility(false);
                showDialog(showRetry ? 1 : 0);
                //mChefCheckLicenseButton.setEnabled(true);
            }
        });
    }  

    private class ChefMyLicenseCheckerCallback implements LicenseCheckerCallback {
        public void allow(int policyReason) {
            if (isFinishing()) {
                // Don't update UI if Activity is finishing.
                return;
            }
            // Should allow user access.
            System.out.println("****** Chef Message from Starting page MyLicenseCheckerCallback::allow "+R.string.allow);
            callSelfNoCheck();
            displayResult(getString(R.string.allow));
        }

        public void dontAllow(int policyReason) {
            if (isFinishing()) {
                // Don't update UI if Activity is finishing.
                return;
            }
            displayResult(getString(R.string.dont_allow));
            // Should not allow access. In most cases, the app should assume
            // the user has access unless it encounters this. If it does,
            // the app should inform the user of their unlicensed ways
            // and then either shut down the app or limit the user to a
            // restricted set of features.
            // In this example, we show a dialog that takes the user to Market.
            // If the reason for the lack of license is that the service is
            // unavailable or there is another problem, we display a
            // retry button on the dialog and a different message.
            System.out.println("****** Chef Message from Starting page MyLicenseCheckerCallback::dontallow "+R.string.dont_allow);
            displayDialog(policyReason == Policy.RETRY);
        }

        public void applicationError(int errorCode) {
            if (isFinishing()) {
                // Don't update UI if Activity is finishing.
                return;
            }
            // This is a polite way of saying the developer made a mistake
            // while setting up or calling the license checker library.
            // Please examine the error code and fix the error.
            String result = String.format(getString(R.string.application_error), errorCode);
            System.out.println("****** Chef Message from Starting page MyLicenseCheckerCallback::applicationError result = "+result); 
            displayResult(result);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mChefChecker.onDestroy();
    }
}