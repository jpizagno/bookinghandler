package com.noblebug.chefpro.search;

import com.noblebug.chefpro.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class FramedDefault extends View {
	public Integer FrameSizeX;
	public Integer FrameSizeY;
	public Paint paint;
	
	public FramedDefault(Context context)
    {
        super(context);
        paint=new Paint();
    }
    public FramedDefault(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        paint=new Paint();
    }
    public FramedDefault(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        paint=new Paint();
    }
	
    protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		this.setBackgroundResource(R.drawable.defaultrecipeimage);
		Bitmap window = BitmapFactory.decodeResource(this.getResources(), R.drawable.windowframe);
		Bitmap obj = Bitmap.createScaledBitmap(window, FrameSizeX, FrameSizeY, true);
		canvas.drawBitmap(obj, 0, 0, paint);
	}
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
		this.setMeasuredDimension(FrameSizeX,FrameSizeY);
	} 

}
