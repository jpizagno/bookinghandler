package com.noblebug.chefpro.search;

import java.util.Map;

import com.noblebug.chefpro.planner.Planner;
import com.noblebug.chefpro.search.ArrayWheelAdapter;
import com.noblebug.chefpro.search.OnWheelChangedListener;
import com.noblebug.chefpro.search.WheelView;
import com.noblebug.chefpro.settings.AboutChef;
import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Looper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class SearchDisplay extends Activity {
	// displays the Search.  Displays a title, textedit, images, button, wheel view.
	// 4 June 2011 Jim Pizagno
	
	// called when search display is created
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// do some garbage collecting
		System.gc();
		
		mCtx = this;
		
		// fixes phone in PORTRAIN, and no TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		String sendtoSettings = null;
		if(this.getIntent().hasExtra("sendtoSettings")) {
			sendtoSettings = (String) this.getIntent().getCharSequenceExtra("sendtoSettings");
		}
		
		// check for open internet connection:
		appState = ((ChefController) getApplicationContext());

		viewwidth = this.getWindowManager().getDefaultDisplay().getWidth();
		viewheight = this.getWindowManager().getDefaultDisplay().getHeight();
		
		// create PHPhandler:
		myPHP = new BackEndPHPHandler();
		
		// instead of having all other actiivites pass userid to search
		// just have search open the database and get it.
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		userid = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
		
		// get settings from DB:
		String[] tempsettings = mDbHelper.getSearchSettings(userid).split("::");
		if (tempsettings[0].equalsIgnoreCase("latest")){
			order = "latest";
		}
		if (tempsettings[0].equalsIgnoreCase("alpha")){
			order = "alpha";
		}
		if (tempsettings[1].equalsIgnoreCase("YES")){
			dairyfree = "YES";
		}
		if (tempsettings[2].equalsIgnoreCase("YES")){
			eggfree = "YES";
		}
		if (tempsettings[3].equalsIgnoreCase("YES")){
			glutenfree = "YES";
		}
		if (tempsettings[4].equalsIgnoreCase("YES")){
			nutfree = "YES";
		}
		
		// set up Layout
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
		mLinearLayout.setBackgroundResource(R.drawable.searchbackgroundpaper);
		
		// create inner layout for title, edittext, checkbox, search button
		LinearLayout innerLayout1 = new LinearLayout(this);
		innerLayout1.setOrientation(LinearLayout.VERTICAL);
		innerLayout1.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
		innerLayout1.setGravity(Gravity.CENTER);
		
		// make instance of searchtest, box, button. linked to Resources (R)
		// title:
		final Button title = new Button(this);
		title.setBackgroundResource(R.drawable.recipesearchtitle);
		title.setClickable(true);
		title.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent ev) {
			       // Get the action that was done on this touch event
				switch (ev.getAction())
		        {
		            case MotionEvent.ACTION_DOWN:
						if (ev.getX()>0.80*viewwidth) {
							title.setBackgroundResource(R.drawable.recipesearchtitleclicked);
						}
						break;
		            case MotionEvent.ACTION_UP:
		            	if (ev.getX()>0.80*viewwidth) {
		            		gotoSearchSettings();
		            	}
						break;
		        }
				return true;
			}
		});
		
		innerLayout1.addView(title,this.viewwidth,this.viewheight*10/100);
		
		// add padding after title before searchtest
		ImageView space = new ImageView(this);
		space.setImageResource(R.drawable.searchbackgroundpaper);
		int spaceheight = this.viewheight*2/100;
		int spacewidth = this.viewwidth;
		innerLayout1.addView(space,spacewidth,spaceheight);
		
		searchtext = new EditText(this);
		searchtext.setHint("Enter title or ingredients");
		int searchtextwidth = viewwidth-viewwidth*10/100; //-50;
		int searchtextheight = viewheight*10/100-viewheight*1/100;      ///10-5;
		if (sendtoSettings!=null) {
			if(sendtoSettings.split("::")[2].length()>0) {
				searchtext.setText(sendtoSettings.split("::")[2]);
			}
		}
		innerLayout1.addView(searchtext,searchtextwidth,searchtextheight);
		
		LinearLayout innerLayout4 = new LinearLayout(this);
		innerLayout4.setGravity(Gravity.CENTER_HORIZONTAL);
		imagesbox = new CheckBox(this);
		imagesbox.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
		imagesbox.setText("Only Recipes With Images");
		imagesbox.setTextColor(Color.rgb(66, 41, 10));
		if (sendtoSettings!=null) {
			if(sendtoSettings.split("::")[3].length()>0) {
				if(sendtoSettings.split("::")[3].equalsIgnoreCase("yes")){
					imagesbox.setChecked(true);
				}
			}
		}
		int imagesboxwidth = viewwidth * 70/100;
		int imagesboxheight = viewheight * 10/100;
		innerLayout4.addView(imagesbox,imagesboxwidth,imagesboxheight);
		innerLayout1.addView(innerLayout4);
		
		//this is the search button
		LinearLayout innerLayout3 = new LinearLayout(this);
		int searchbuttonpadding = viewheight * 4/100;
		innerLayout3.setPadding(0, 0, 0, searchbuttonpadding);
		innerLayout3.setGravity(Gravity.CENTER);
		btnsearch = new Button(this);
		btnsearch.setClickable(true);
		btnsearch.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
		btnsearch.setBackgroundResource(R.drawable.searchnowbutton);
		btnsearch.setOnClickListener(myProgressBarShower);
		innerLayout3.addView(btnsearch,this.viewwidth/2,this.viewheight*8/100);
		
		innerLayout1.addView(innerLayout3);
		
		mLinearLayout.addView(innerLayout1);
		
		// create innerLayout2
		LinearLayout innerLayout2 = new LinearLayout(this);
		innerLayout2.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
		innerLayout2.setOrientation(LinearLayout.HORIZONTAL);
		innerLayout2.setGravity(Gravity.CENTER_HORIZONTAL);
		int backgroundleft = this.viewwidth * 1/100;
		int backgroundtop = this.viewheight * 5/100;
		int backgroundright = this.viewwidth * 1/100;
		int backgroundbottom = this.viewheight * 5/100;
		innerLayout2.setPadding(backgroundleft, backgroundtop, backgroundright, backgroundbottom);
		try {
			innerLayout2.setBackgroundResource(R.drawable.searchbackgroundspinner);
		} catch(OutOfMemoryError e) {
			innerLayout2.setBackgroundColor(Color.rgb(218, 227, 234));
		}
		
		// add Wheels
		cuisinewheel = new WheelView(this);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT, 1);
		cuisinewheel.setLayoutParams(params);
		cuisines = this.getResources().getStringArray(R.array.cuisines);
		cuisinewheel.setViewAdapter(new ArrayWheelAdapter<String>(this,cuisines));
	    cuisinewheel.setCurrentItem(0);
	    if (sendtoSettings!=null) {
		    if(sendtoSettings.split("::")[0].length()>0) {
		    	cuisinewheel.setCurrentItem(Integer.valueOf(sendtoSettings.split("::")[0]));
		    }
	    }
	    innerLayout2.addView(cuisinewheel);
	    
	    categorywheel = new WheelView(this);
	    categorywheel.setLayoutParams(params);
		categories = this.getResources().getStringArray(R.array.categories);
	    categorywheel.setViewAdapter(new ArrayWheelAdapter<String>(this,categories));
	    categorywheel.setCurrentItem(0);
	    if (sendtoSettings!=null) {
		    if(sendtoSettings.split("::")[1].length()>0) {
		    	categorywheel.setCurrentItem(Integer.valueOf(sendtoSettings.split("::")[1]));
		    }
	    }
	    // add listeners
	    addChangingListener(categorywheel, "category");
	    addChangingListener(cuisinewheel, "cuisines");
	    OnWheelChangedListener wheelListener = new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				// wtf is this doing?
				//wheelChanged = true;
				//wheelChanged = false;
			}
		};
		categorywheel.addChangingListener(wheelListener);
		cuisinewheel.addChangingListener(wheelListener);
		innerLayout2.addView(categorywheel);
		mLinearLayout.addView(innerLayout2);
		
		this.setContentView(mLinearLayout);
	}

	///
	 // Adds changing listener for wheel that updates the wheel label
	 // @param wheel the wheel
	 // @param label the wheel label
	 //
	private void addChangingListener(final WheelView wheel, final String label) {
		wheel.addChangingListener(new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				//wheel.setLabel(newValue != 1 ? label : label);
			}
		});
	}

	/// OnClickListener that fakes some work to be done. */
	OnClickListener myProgressBarShower = new OnClickListener(){
		// @Override
		public void onClick(View arg0) {
			btnsearch.setBackgroundResource(R.drawable.searchnowbuttonpressed);
			btnsearch.invalidate();
			btnsearch.setClickable(false);
			appState.check4InternetConnection(mCtx);
			if (appState.check4InternetConnection(mCtx)) {    //appState.internetConnectionOpen==true) {
				myProgressDialog = ProgressDialog.show(SearchDisplay.this,	
						"Please wait...", "Searching Chefslittlehelper.com...", true);
				new Thread() {
					public void run() {
						try{
							// Do some Fake-Work
							//sleep(5000);
							Looper.prepare();
							
							Integer catposition = categorywheel.getCurrentItem();
							Integer cuiposition = cuisinewheel.getCurrentItem();
							cuisine2search = (String) cuisines[cuiposition];
							category2search = (String) categories[catposition];
							String str = " you seletect: "+categories[catposition]+" "+cuisines[cuiposition];
							
							keywords2search = (String) searchtext.getText().toString();
							if(testHasSQLStatements(keywords2search)) {
								Looper.myLooper().quit();
								Looper.loop();
								Looper.myLooper().quit();
								// Dismiss the Dialog 
								myProgressDialog.dismiss();
							}
							if (keywords2search
									.equalsIgnoreCase(getString(R.string.search))) {
								keywords2search = null;
							}
							if (imagesbox.isChecked()) {
								getimages = "YES";
							} else {
								getimages = "NO";
							}
							String key = keywords2search + getimages + cuisine2search + category2search + dairyfree;
							key = key + eggfree + glutenfree + nutfree + order;
							Map<String,String> tempMap = appState.getRecipeSearchMap();
							if (tempMap.containsKey(key)) {
								// just made this search
								// dont remake search.  the SearchResults is the value in map:
								SearchResults = tempMap.get(key);
							} else {
								// do this search
								myPHP.setStringFields(keywords2search, getimages,
										cuisine2search, category2search, dairyfree,
										eggfree, glutenfree, nutfree, order);
								myPHP.getResult();
								SearchResults = myPHP.RecipeResultString;
								tempMap.clear();  // only 1 value in map
								tempMap.put(key, SearchResults);
								appState.setRecipeSearchMap(tempMap);
							}
							Looper.myLooper().quit();
							Looper.loop();
							Looper.myLooper().quit();
							// Dismiss the Dialog 
							myProgressDialog.dismiss();
							sleep(1000);
							callSearchResultsDisplayIFOKAYResult();
							btnsearch.setClickable(true);
						} catch (Exception e) {	
							e.printStackTrace();
						}
					}
				}.start();
			} else {
				Toast.makeText(getBaseContext(), "This device does not appear to be connected to the internet.",
						Toast.LENGTH_LONG).show();
			}
		}
    };
	
    public void callSearchResultsDisplayIFOKAYResult(){
    	if (SearchResults.split("::").length > 1) {
			callSearchResultsDisplay();
		} else {
			appState.check4InternetConnection(mCtx);
			if (appState.internetConnectionOpen==false) {
				Toast.makeText(getBaseContext(), "This phone may not be connected to the internet",
						Toast.LENGTH_LONG).show();
			} else {
				// toast "results not found"
				Toast.makeText(getBaseContext(), "No Recipes Found",
						Toast.LENGTH_LONG).show();
			}
		}	
    }
	
	protected void callSearchResultsDisplay() {
		// have result, show a list of recipes:
		mDbHelper.close();
		System.out.println("callSearchResultsDisplay()");
		Intent i = new Intent(this, SearchResultsDisplay.class);
		i.putExtra("searchresults", SearchResults);
		i.putExtra("userid", userid);
		startActivityForResult(i, 0);
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "").setIcon(grocerylist);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "").setIcon(home);
		Drawable mealplanner = this.getResources().getDrawable(R.drawable.mealplanner);
		menu.add(0, Planner_ID, 0, "").setIcon(mealplanner);;
		
		menu.add(0, AboutChef_ID, 0, "About Chef");
		menu.add(0, Contact_ID, 0, "Contact Us");
		
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Planner_ID:
			goto_planner();
			return true;
		case Contact_ID:
			contact_us();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		case AboutChef_ID:
			this.gotoAboutChef();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void goto_planner() {
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}
	
	private static final int AboutChef_ID = 10;
	protected void gotoAboutChef() {
		Intent i = new Intent(this, AboutChef.class);
		startActivity(i);
	}

	private void contact_us() {
		// email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
		// users to provide feedback.
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity Search");
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void gotoSearchSettings() {
		// get current wheel setting
		String cuisine2searchINT = String.valueOf(cuisinewheel.getCurrentItem());
		String category2searchINT = String.valueOf(categorywheel.getCurrentItem());
		keywords2search = (String) searchtext.getText().toString();
		if (imagesbox.isChecked()) {
			getimages = "YES";
		} else {
			getimages = "NO";
		}
		if (keywords2search==null){
			keywords2search="";
		}
		String sendtoSettings = cuisine2searchINT+"::"+category2searchINT+"::"+keywords2search+"::"+getimages;
		
		mDbHelper.close();
		Intent i = new Intent(this, SearchSettings.class);
		i.putExtra("sendtoSettings", sendtoSettings);
		startActivity(i);
	}
	
	public boolean testHasSQLStatements(String searchText) {
		// this method checks for SQL-type statements in searchText.
		// if user enters SQL-type statements, then www.chefslittlehelper.com may break.
		boolean answer = false;
		String[] SQLkeywords = {";","INSERT","SELECT","CREATE", "DELETE","DROP","SHOW","USER",")","'"};
		for (int i=0;i<SQLkeywords.length;i++) {
			if(searchText.contains(SQLkeywords[i])){
				answer = true;
			}
		}
		return answer;
	}
	
	private void gotoChef() {
		mDbHelper.close();
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}

	private void createTimers() {
		mDbHelper.close();
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createSearch() {
		mDbHelper.close();
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		mDbHelper.close();
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		mDbHelper.close();
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		//i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	// create fields
	private   final int Cookbook_ID = 0;
	private   final int Grocerylist_ID = 1;
	private   final int Search_ID = 2;
	private   final int Timers_ID = 3;
	private   final int Chef_ID = 4;
	private final int Planner_ID = 7;
	private   final int Contact_ID = 11;
	private Button btnsearch;
	private EditText searchtext;
	private CheckBox imagesbox;
	private Integer userid = null;
	private BackEndPHPHandler myPHP;
	String cuisine2search = null;
	String category2search = null;
	String keywords2search = null;
	String getimages = null;
	private BackEndSQLite mDbHelper;
	String SearchResults = null;
	ProgressDialog myProgressDialog = null;
	// Time changed flag
	WheelView cuisinewheel;
	WheelView categorywheel;
	private String cuisines[];
	private String categories[];
	protected String order = "EMPTY";
	protected String dairyfree = "NO";
	protected String eggfree = "NO";
	protected String glutenfree = "NO";
	protected String nutfree = "NO";
	private ChefController appState;
	private int viewwidth;
	private LinearLayout mLinearLayout;
	private int viewheight;
	private Context mCtx;
}
