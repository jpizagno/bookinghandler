package com.noblebug.chefpro.settings;

import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.NewUser;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class SectionsEditor extends ListActivity {
	// class to move grocery Aisle sections around, or to change the order.
	
	String[] jimString;
	ChefController appState;

	private ListView mExampleList;

	/// Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// fix phone in PORTRAIT and no TITLE
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(com.noblebug.chefpro.R.layout.sectionseditor);
		
		appState = ((ChefController) getApplicationContext());
		appState.createObjects(this);
		jimString = appState.getAisleList();
		if (jimString[0]==null){
			BackEndSQLite mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			Integer userid = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
			jimString = mDbHelper.getAislelist(userid);
			mDbHelper.close();
		}

		mExampleList = getListView();
		mExampleList.setOnCreateContextMenuListener(this);
		mExampleList.setBackgroundColor(Color.WHITE);
		((DDListView) mExampleList).setDropListener(mDropListener);
		mExampleList.setAdapter(new ExampleArrayAdapter(
				getApplicationContext(), R.layout.rowexample, jimString));
	}

	// ArrayAdapter
	private class ExampleArrayAdapter extends ArrayAdapter<String> {
		private Context mContext;
		private int mLayoutId;
		private String[] mListContent;

		public ExampleArrayAdapter(Context context, int textViewResourceId,
				String[] objects) {
			super(context, textViewResourceId, objects);
			mContext = context;
			mLayoutId = textViewResourceId;
			mListContent = objects;
		}

		public View getView(int position, View rowView, ViewGroup parent) {
			// fix with this:
			// http://android.amberfog.com/?p=296
			if (rowView != null) {
				LayoutInflater inflater = LayoutInflater.from(mContext);
				View v = inflater.inflate(mLayoutId, null);
				TextView rowTitle = (TextView) v.findViewById(R.id.text1);
				rowTitle.setTextColor(Color.BLACK);
				v.setBackgroundColor(Color.WHITE);
				rowTitle.setText(mListContent[position]);
				// return rowView;
				return v;
			} else {
				LayoutInflater inflater = LayoutInflater.from(mContext);
				View v = inflater.inflate(mLayoutId, null);
				TextView rowTitle = (TextView) v.findViewById(R.id.text1);
				rowTitle.setTextColor(Color.BLACK);
				v.setBackgroundColor(Color.WHITE);
				rowTitle.setText(mListContent[position]);

				return v;
			}
		}
	}

	public void moveItems(int old, int newposition) {
		String[] jimStringOld = new String[jimString.length];
		jimStringOld = jimString;
		String[] jimStringNew = new String[jimString.length];

		for (int i = 0; i < jimString.length; i++) {
			if (i == newposition) {
				jimStringNew[newposition] = jimStringOld[old];
			} else if (i == old) {
				jimStringNew[old] = jimStringOld[newposition];
			} else {
				jimStringNew[i] = jimStringOld[i];
			}
		}

		jimString = jimStringNew;
		mExampleList.invalidate();

		mExampleList.setAdapter(new ExampleArrayAdapter(
				getApplicationContext(), R.layout.rowexample, jimString));

		// now that items are moved, give them back to chefcontroller
		appState.setAisle(jimString);
	}

	// Drop Listener
	private DDListView.DropListener mDropListener = new DDListView.DropListener() {
		public void drop(int from, int to) {
			moveItems(from, to);
		}
	};

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, Cookbook_ID, 0, R.string.btncookbook);
		menu.add(0, Grocerylist_ID, 0, R.string.btngrocerylist);
		menu.add(0, Search_ID, 0, R.string.btnrecipesearch);
		menu.add(0, Timers_ID, 0, R.string.totimers);
		menu.add(0, Settings_ID, 0, R.string.tosettings);
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Settings_ID:
			this.gotoSettings();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private void gotoSettings() {
		Intent i = new Intent(this, SettingsDisplay.class);
		startActivity(i);
	}

	private void createTimers() {
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		startActivity(i);
	}

	private void createNewUser() {
		// call new user activity
		Intent i_newuser = new Intent(this, NewUser.class);
		startActivity(i_newuser);
	}

	private void createSearch() {
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	// create fields
	private static final int Cookbook_ID = 0;
	private static final int Grocerylist_ID = 1;
	private static final int Search_ID = 2;
	private static final int Timers_ID = 3;
	private static final int Settings_ID = 4;
}
