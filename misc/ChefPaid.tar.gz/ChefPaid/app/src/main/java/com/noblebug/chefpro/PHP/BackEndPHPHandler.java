package com.noblebug.chefpro.PHP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import com.noblebug.chefpro.recipe.Recipe;
import com.noblebug.chefpro.tools.InputStreamText;
import android.app.Activity;

public class BackEndPHPHandler extends Activity {

	// this class handles the PHP calls to www.chefslittlehelper.com
	// handles bookmarks,grocerylist, cookbook and search
	// 4 june 2011 Jim Pizagno
	
	
	public void bookmarkstoweb(int userID, List<Integer> recipeIDsBookmarked,String md5password) {
		// sends bookmarks to the web, in an effort to keep phone and webpage synced.
		if (recipeIDsBookmarked.size()==0) {
		} else {			
			String commaSepBookmarks = "";
			for (int i=0;i<recipeIDsBookmarked.size();i++){
				commaSepBookmarks = commaSepBookmarks + recipeIDsBookmarked.get(i) + ",";
		    }
			String temp = commaSepBookmarks.substring(0, commaSepBookmarks.length()-1);
			commaSepBookmarks=temp;
			
		    // Create a new HttpClient and Post Header
			
			// set timeout params
			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
			HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
			HttpConnectionParams.setTcpNoDelay(httpParameters, true);
			
			HttpClient httpclient = new DefaultHttpClient(httpParameters);
		    String url = "http://www.chefslittlehelper.com/API/android/2.0.0/bookmarkstoweb.php?uid=" +String.valueOf(userID)
			+"&password=" + md5password;
		    
		    // this didn't work either:  url = url +"&bookmarks="+commaSepBookmarks;
		    HttpPost httppost = new HttpPost(url);
		
		    // create info to post:
		    String boundary = "---------------------------14737809831466499882746641449";
		    httppost.setHeader("Content-Type", "multipart/form-data; boundary="+boundary);
		    final StringBuffer soap = new StringBuffer();
		    soap.append("\r\n--"+boundary+"\r\n");
		    soap.append("Content-Disposition: form-data; name=\"bookmarks\"; filename=\"ipodfile.jpg\"\r\n");
		    soap.append("Content-Type: application/octet-stream\r\n\r\n");
		    soap.append(commaSepBookmarks);
		    soap.append("\r\n--"+boundary+"--\r\n");
		    
		    // does ? work with these parameters either:
		    HttpParams httpParams = new BasicHttpParams();
		    httpParams.setParameter("bookmarks", commaSepBookmarks);
		    httppost.setParams(httpParams);
		    
		    try {
		    	HttpEntity entity = new StringEntity(soap.toString());
		    	httppost.setEntity(entity);
		    	
		        // Execute HTTP Post Request
		        HttpResponse response = httpclient.execute(httppost);
		        HttpEntity resEntity = response.getEntity();
		        //System.out.println("**** BackEndPHPHandler::bookmarkstobweb " +
		        //		"EntityUtils.toString(resEntity) = "+EntityUtils.toString(resEntity));
		    } catch (ClientProtocolException e) {
		       e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}
	}
	
	public void deleteRecipe(int recipeid, String md5password, int userid) {
		// this method deletes a recipe from the webpage
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/deleterecipe.php?index=" +String.valueOf(recipeid)
				+"&user=" + String.valueOf(userid)
				+"&password=" + md5password;
		url.replace(" ","%20");
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		//HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			String message = stream2text.GetText(response);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void syncAllCookbook(String uID,String md5password, Long recipeLastUpdateTime) {
		// used to Sync the cookbook.  sync ALL recipes. used after login/NewUser.java
		//
		//I also added cookbookUpdate.php to the android api folder. Here's how to call it:
		//NSString *url = @"http://www.chefslittlehelper.com/API/iPad/1.1.0/cookbookupdate.php?uid=";
		//url = [url stringByAppendingString:userInfo.uid];
		//url = [url stringByAppendingFormat:@"&password=%@",userInfo.hash];
		//url = [url stringByAppendingFormat:@"&updateTime=%f",settings.recipesUpdateTime];
		//
		//It'll return three lists of recipe id's separated by , and ^. e.g.
		//
		//10466,27000,26998^^112^1292291013
		//The first list is recipes updated since the time provided, 
		//the second is a list of recipes not updated since the time provided, 
		//the third list is a list of all the bookmarks and the last is the new update time. 
		//Let me know if you have any questions.

		
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/cookbookupdate.php?uid=" + uID;
		url = url + "&password=" + md5password;
		url = url + "&updateTime=" + String.valueOf(recipeLastUpdateTime);
		url.replace(" ","%20");
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			syncALLCookbookFulllist = stream2text.GetText(response);
			// maybe can't parse on "^"  so replace with "%%%"
			syncALLCookbookFulllist = syncALLCookbookFulllist.replace("^", "%%%");
			String[] temp = syncALLCookbookFulllist.split("%%%");
			String[] temp2 = temp[1].split(",");
			String[] temp3 = temp[2].split(",");
			recipesAll.clear();
			for (int i=0;i<temp2.length;i++) {
				recipesAll.add(Integer.valueOf(temp2[i]));
			}
			for (int i=0;i<temp3.length;i++) {
				if (temp3[i].equalsIgnoreCase("None")==false) {
					recipesAll.add(Integer.valueOf(temp3[i]));
					System.out.println("**** BackEndPHPHAndler::syncALLCookbook 3 adding="+String.valueOf(Integer.valueOf(temp3[i])));
				}
			}
			lastupdateTime = Long.valueOf(temp[3].trim()); //BJ "last is the new update time."
		} catch (Exception ex) {
			// should probably put method call to go back to Search page,
			// and give user a warning that the "database timed out" or
			// something.
			System.out.println(" url = " + url);
			ex.printStackTrace();
		}
		
	}
	
	public void syncCookbook(String uid, String md5password,Long recipeLastUpdateTimeOld) {
		// used to Sync the cookbook
		//
		//I also added cookbookUpdate.php to the android api folder. Here's how to call it:
		//NSString *url = @"http://www.chefslittlehelper.com/API/iPad/1.1.0/cookbookupdate.php?uid=";
		//url = [url stringByAppendingString:userInfo.uid];
		//url = [url stringByAppendingFormat:@"&password=%@",userInfo.hash];
		//url = [url stringByAppendingFormat:@"&updateTime=%f",settings.recipesUpdateTime];
		//
		//It'll return three lists of recipe id's separated by , and ^. e.g.
		//
		//10466,27000,26998^^112^1292291013
		//The first list is recipes updated since the time provided, 
		//the second is a list of recipes not updated since the time provided, 
		//the third list is a list of all the bookmarks 
		//and the last is the new update time. 
		//Let me know if you have any questions.

		
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/cookbookupdate.php?uid=" + uid;
		url = url + "&password=" + md5password;
		url = url + "&updateTime=" + String.valueOf(recipeLastUpdateTimeOld);
		url.replace(" ","%20");
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			syncCookbookFulllist = stream2text.GetText(response);
			// maybe can't parse on "^"  so replace with "%%%"
			syncCookbookFulllist = syncCookbookFulllist.replace("^", "%%%");
			String[] temp = syncCookbookFulllist.split("%%%");
			String[] temp2 = temp[0].split(",");  // recipes since time provided
			recipesNeedUpdating.clear();
			for (int i=0;i<temp2.length;i++) {
				if(temp2[i].length()>0) {
					recipesNeedUpdating.add(Integer.valueOf(temp2[i]));
				}
			}
			lastupdateTime = Long.valueOf(temp[3].trim()); //BJ "last is the new update time."
			// DO NOT ALWAYS UPDATE.  TEST FIRST
			if (recipeLastUpdateTimeOld.compareTo(lastupdateTime)==0){
				// do NOT UPDATE
				recipesNeedUpdating = null;
			}
		} catch (Exception ex) {
			// should probably put method call to go back to Search page,
			// and give user a warning that the "database timed out" or
			// something.
			ex.printStackTrace();
		}
	}
	
	public void validateuser(String user, String md5password) {
		// make sure this user has entered the correct user name and correct password
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/validateuser.php?user=";
		url = url + user;
		url = url + "&password="+md5password;
		url.replace(" ","%20");
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			uidResult = stream2text.GetText(response);
			System.out.println("uidResult = "+ uidResult);
		} catch (Exception ex) {
			// should probably put method call to go back to Search page,
			// and give user a warning that the "database timed out" or
			// something.
			ex.printStackTrace();
		}
	}
	
	public void sendWeb2GroceryList(String uid) {
		// get the grocery list from the web, user can add something to the list on the web, 
		// and the phone needs to know.
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/grocerylisttophone.php?";
		url = url + "uid=" + uid;
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			sendWeb2GroceryListResult = stream2text.GetText(response);
		} catch (Exception ex) {
			// should probably put method call to go back to Search page,
			// and give user a warning that the "database timed out" or
			// something.
			ex.printStackTrace();
		}
	}

	public void sendGroceryList2Web(String uid, String password, List Grocerylist) {
		// send the user's grocery list to the web
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/grocerylisttoweb.php?uid=";
		url = url + uid;
		url = url + "&password=" + password;
		// +1 need to be there? (below here ..>)
		url = url + "&numitems=" + String.valueOf(Grocerylist.size());
		for (int m = 0; m < Grocerylist.size(); m++) {
			url = url + "&item" + String.valueOf(m) + "=" + Grocerylist.get(m);
		}
		url = url.replace("%", "%25"); // NO percent signs, such as (at least 80%) as in Cheesy Burger Pie
		url = url.replace(" ", "%20"); // NO empty spaces
		url = url.replace("\"", "%22"); // NO quotes
		url = url.replace("<", "%3C"); // NO <
		url = url.replace(">", "%3E"); // NO >
		url = url.replace("#", "%23"); // NO #
		url = url.replace("{", "%7B"); // NO {
		url = url.replace("}", "%7D"); // NO }
		url = url.replace("|", "%7C"); // NO |
		url = url.replace("^", "%5E"); // NO ^
		url = url.replace("~", "%7E"); // NO ~
		url = url.replace("[", "%5B"); // NO [
		url = url.replace("]", "%5D"); // NO ]
		url = url.replace("'", "%60"); // NO '
		
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			sendGroceryList2Webresult = stream2text.GetText(response);
		} catch (Exception ex) {
			// should probably put method call to go back to Search page,
			// and give user a warning that the "database timed out" or
			// something.
			ex.printStackTrace();
		}
	}

	// get result of search. called from recipe search
	public void getResult() {
		// perform a search for recieps. called from SearchDisplay.java.
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/search.php?search=";
		if (keywords2search != null) {
			url = url + keywords2search;
		}
		if (cuisine2search != null) {
			url = url + "&cuisine=" + cuisine2search;
		}
		if (category2search != null) {
			url = url + "&category=" + category2search;
		}
		if (getimages != null) {
			url = url + "&imageonly=" + getimages;
		}
		if (dairyfree.equalsIgnoreCase("YES")) {
			url = url + "&dairyFree=YES";
		}
		if (eggfree.equalsIgnoreCase("YES")) {
			url = url + "&eggFree=YES";
		}
		if (glutenfree.equalsIgnoreCase("YES")) {
			url = url + "&glutenFree=YES";
		}
		if (nutfree.equalsIgnoreCase("YES")) {
			url = url + "&nutFree=YES";
		}
		if (order.equalsIgnoreCase("latest")) {
			url = url + "&order=latest";
		}
		if (order.equalsIgnoreCase("alpha")) {
			url = url + "&order=alpha";
		}
		url = url.replace(" ", "%20"); // NO empty spaces

		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			RecipeResultString = stream2text.GetText(response);
		} catch (Exception ex) {
			// should probably put method call to go back to Search page,
			// and give user a warning that the "database timed out" or
			// something.
			ex.printStackTrace();
		}
	}

	// sets the fields, called from search display
	public void setStringFields(String keywords2searchtemp,
			String getimagestemp, String cuisine2searchtemp,
			String category2searchtemp, String dairyfreetemp,
			String eggfreetemp, String glutenfreetemp, String nutfreetemp,
			String ordertemp) {
		// sets fields, after user clicks search in SearchDisplay
		keywords2search = keywords2searchtemp;
		cuisine2search = cuisine2searchtemp;
		getimages = getimagestemp;
		category2search = category2searchtemp;
		dairyfree = dairyfreetemp;
		eggfree = eggfreetemp;
		glutenfree = glutenfreetemp;
		nutfree = nutfreetemp;
		order = ordertemp;
	}
	
	
	public void fetchStringRecipe(Integer recipeid, Integer userid) {
		// plain text::^^ result:
		// http://www.chefslittlehelper.com/API/android/2.0.0/displayrecipe.php?index=13644&user=4
		//
		// BJ tried changing to UTF-8 strings with displayrecipeutf.php
		String urlstring = "http://www.chefslittlehelper.com/API/android/2.0.0/";
		//urlstring = urlstring + "displayrecipe.php?index="
		urlstring = urlstring + "displayrecipeutf.php?index="
				+ Integer.toString(recipeid);
		urlstring = urlstring + "&user=" + Integer.toString(userid);
		urlstring = urlstring.replace(" ", "%20"); // NO empty spaces
		String contents="";
		try {
           URL url = new URL(urlstring);
           URLConnection conn = url.openConnection();
           BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-16LE"));
           String line = "";
           while ((line = rd.readLine()) != null) {
               contents = contents + line;
           }
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		// now try to set the recipe:
		if (contents.length()>0){
			RecipeFromFetchString = new Recipe();
			contentsStringRecipe = contents;
			RecipeFromFetchString.setFieldsFromString(contents,recipeid);
			RecipeString = RecipeFromFetchString.Fields2String();
		} else {
			//System.out.println("******* BackEndPHPHAnderl::fetchSTRINGrecipe contents empty");
		}
	}
 
	public String getMealByMonth(String user, int yearin, int monthin) { //Date parsedDate) {
		// Sends the user and date to the web and asks for the recipes for that Month:
		// example call:
		// http://www.chefslittlehelper.com/API/android/2.0.0/mealsbymonth.php?user=4&date=2012-01
		// the return is a list of meals. in the format:  
		// node-in=nid ^^ recipid ^^ name ^^ type(dinner,lunch,etc) ^^ year-month-day
		// 36407^^26690^^Pizza^^Dinner^^2012-07-25<br>
		// 36424^^18678^^Chicken & Broccoli Casserole or (Make your own casserole)^^Dinner^^2012-07-12
		String result = "not changed in BackEndPHPHandler.getMealByMonth()";
		int year = yearin; //parsedDate.getYear()+1900;
		int month = monthin+1;  //parsedDate.getMonth() + 1;  // starts at january=0 so add 1
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/mealsbymonth.php?";
		url = url + "user="+user;
		if (month<10){
			url = url + "&date="+year+"-0"+month; // need extra "0" for 01-09.
		} else {
			url = url + "&date="+year+"-"+month;
		}
		url = url.replace(" ", "%20"); // NO empty spaces
		System.out.println("BackEndPHPHandler.exceptionlog() url = "+url);
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			result = stream2text.GetText(response).trim();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}
	
	public void exceptionlog(int userid, String comment, String priority) {
		// sends userid,comment,priority to exception_log table in noblebug_chef database.
		String url = "http://www.chefslittlehelper.com/API/android/2.0.0/exceptionlog.php?";
		url = url + "user="+userid;
		url = url + "&comment="+comment;
		url = url + "&priority="+priority;
		url = url.replace(" ", "%20"); // NO empty spaces
		System.out.println("BackEndPHPHandler.exceptionlog() url = "+url);
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			String result = stream2text.GetText(response).trim();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void rateRecipe(int userid, String user, int recipeid, String password, int vote){
		// this method takes information from RecipeDisplay.java, after user clicks rate recipe,
		//    and sends it to chefslittlehelper.com.  The result should come back as "Done".
		String url ="http://www.chefslittlehelper.com/API/android/2.0.0/vote.php?";
		url = url + "uid="+String.valueOf(userid);
		url = url + "&user="+user;
		url = url + "&recipe="+String.valueOf(recipeid);
		url = url + "&password="+password;
		if (vote==5) {
			url = url + "&vote=100";
		} else if (vote==4) {
			url = url + "&vote=80";
		} else if (vote==3) {
			url = url + "&vote=60";
		} else if (vote==2) {
			url = url + "&vote=40";
		} else if (vote==1) {
			url = url + "&vote=20";
		}
		//System.out.println("******* BackEndPHPHandler::rateRecipe url = "+url);
		
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			rateReciperesult = stream2text.GetText(response).trim();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	public void addRecipe2Calendar(int userid, String passwordmd5, int nid,
			Integer recipeid, String type, String yYYYMMDD, String username) {
		// called by RecipeDisplay when user wants to add this recipe to the web calendar.
		// method params obvious... type=enum(Breakfast, Brunch, Lunch, Dinner)
		// from Bryan's email:  updatemeal takes: user, password, nid, recipenid, type, and date.  
		//               If you're creating a meal pass -1 as the nid.  
		//               The date is a string with the format YYYY-MM-DD.  
		//               Type is a string that is Breakfast, Brunch, Lunch, Dinner.
		// note:  yYYYMMDD  in format YYYY-MM-DD.
		//EX:
		//   http://www.chefslittlehelper.com/API/android/2.0.0/updatemeal.php?uid=4&user=jpizagno&nid=-1&recipenid=100&date=2012-10-02&password=fbsdfsd
		String url ="http://www.chefslittlehelper.com/API/android/2.0.0/updatemeal.php?";
		url = url + "uid="+String.valueOf(userid);
		url = url + "&user="+username;
		url = url + "&recipenid="+String.valueOf(recipeid);
		url = url + "&password="+passwordmd5;
		url = url + "&type="+type;
		url = url + "&date="+yYYYMMDD;
		url = url + "&nid="+nid;

		System.out.println("****** BackEndPHPHanderl.addRecipe2Calendar url = "+url);
		
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			String addRecipeResult = stream2text.GetText(response).trim();
			System.out.println("****** Chef.BackEndPHPHandler.addRecipe2Calenda()   addRecipeResult= "+addRecipeResult);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	public void deleteRecipeFromCalendar(int userid, String passwordmd5,Integer nodeid) {
		// delete recipe from calendar.  just needs userid and passwordmd5.
		// called by RecipeDisplay.java.
		// from Bryan's email:  deletemeal.php takes a user, password, and nodeid.
		
		// The node id is the first element returned from a call to the mealsbymonth.php
		
		String url ="http://www.chefslittlehelper.com/API/android/2.0.0/deletemeal.php?";
		url = url + "user="+String.valueOf(userid);
		url = url + "&index="+String.valueOf(nodeid);
		url = url + "&password="+passwordmd5;

		System.out.println("****** Chef.BackEndPHPHandler.deleteRecipeFromCalendar url = "+url);
		
		// set timeout params
		HttpParams httpParameters = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECTION_TIMEOUT_milliSec );
		HttpConnectionParams.setSoTimeout(httpParameters, WAIT_RESPONSE_TIMEOUT_milliSec );
		HttpConnectionParams.setTcpNoDelay(httpParameters, true);
		
		HttpClient client = new DefaultHttpClient(httpParameters);
		HttpGet request = new HttpGet(url);
		try {
			HttpResponse response = client.execute(request);
			InputStreamText stream2text = new InputStreamText();
			String deleteRecipeResult = stream2text.GetText(response).trim();
			System.out.println("****** Chef.BackEndPHPHandler.deleteRecipeFromCalendar()  deleteRecipeResult = "+deleteRecipeResult);
		} catch (Exception ex) {
			ex.printStackTrace();
		}		
	}
	
	// define fields
	public String RecipeResultString = null;
	public String contentsStringRecipe;
	private String cuisine2search = null;
	private String keywords2search = null;
	private String getimages = null;
	private String category2search = null;
	private String dairyfree;
	private String eggfree;
	private String glutenfree;
	private String nutfree;
	private String order;
	private String sendGroceryList2Webresult;
	public String sendWeb2GroceryListResult;
	public String uidResult;
	private String syncCookbookFulllist;
	public List<Integer> recipesNeedUpdating = new ArrayList<Integer>();
	public Long lastupdateTime;
	public List<Integer> recipesAll = new ArrayList<Integer>();
	private String syncALLCookbookFulllist;
	public String RecipeString;
	public String RecipeStringAccentFixed;
	public Recipe RecipeFromFetchString;
	public String rateReciperesult;
	private static final int CONNECTION_TIMEOUT_milliSec = 60 * 1000;
	private static final int WAIT_RESPONSE_TIMEOUT_milliSec  = 60 * 1000;

}
