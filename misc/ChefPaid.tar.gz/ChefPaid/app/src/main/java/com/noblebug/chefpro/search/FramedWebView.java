package com.noblebug.chefpro.search;

import com.noblebug.chefpro.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.webkit.WebView;

public class FramedWebView extends WebView {
	public Integer FrameSizeX;
	public Integer FrameSizeY;
	public Paint paint;
	
	public FramedWebView(Context context)
    {
        super(context);
        paint=new Paint();
    }
    public FramedWebView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        paint=new Paint();
    }
    public FramedWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        paint=new Paint();
        
    }
    
    public void setWebViewStuff(int webviewScalePerc){
		this.setHorizontalScrollBarEnabled(false);
		this.setVerticalScrollBarEnabled(false);
		this.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		this.setInitialScale(webviewScalePerc);
		this.setClickable(false);
		this.setFocusable(false);
	}

	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		//Bitmap window = BitmapFactory.decodeResource(this.getResources(), R.drawable.windowframe);
		//Bitmap obj = Bitmap.createScaledBitmap(window, FrameSizeX, FrameSizeY, true);
		
		Bitmap obj = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(this.getResources(), R.drawable.windowframe), 
				FrameSizeX, FrameSizeY, true);
		canvas.drawBitmap(obj, 0, 0, paint);
	}
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);	
		this.setMeasuredDimension(FrameSizeX,FrameSizeY);
	} 
}