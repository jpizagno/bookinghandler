package com.noblebug.chefpro.tools;

import java.util.HashMap;
import java.util.Map;
import com.noblebug.chefpro.R;

public class FlagToRid {
	//
	 // this method matches flag/country string to the appropriate resource id
	 // 4June2011 Jim Pizagno

	public FlagToRid() {
		fillMapper();
	}

	public int getRid(String cuisine) {
		if (Flag2IntMapper.containsKey(cuisine) == true) {
			return Flag2IntMapper.get(cuisine);
		} else {
			return R.drawable.other;
		}
	}

	private void fillMapper() {
		Flag2IntMapper.put("appetizer", R.drawable.appetizer);
		Flag2IntMapper.put("breakfast", R.drawable.breakfast);
		Flag2IntMapper.put("breakfeast", R.drawable.breakfast);
		Flag2IntMapper.put("brunch", R.drawable.brunch);
		Flag2IntMapper.put("bread", R.drawable.bread);
		Flag2IntMapper.put("dessert", R.drawable.dessert);
		Flag2IntMapper.put("dressing", R.drawable.dressing);
		Flag2IntMapper.put("drink", R.drawable.drink);
		Flag2IntMapper.put("fusion", R.drawable.fusion);
		Flag2IntMapper.put("lunch", R.drawable.lunch);
		Flag2IntMapper.put("main course", R.drawable.maincourse);
		Flag2IntMapper.put("nouvelle", R.drawable.nouvelle);
		Flag2IntMapper.put("outdoor", R.drawable.outdoor);
		Flag2IntMapper.put("salad", R.drawable.salad);
		Flag2IntMapper.put("sauce", R.drawable.sauce);
		Flag2IntMapper.put("side", R.drawable.side);
		Flag2IntMapper.put("soulfood", R.drawable.soulfood);
		Flag2IntMapper.put("soup", R.drawable.soup);
		Flag2IntMapper.put("vegan", R.drawable.vegan);
		Flag2IntMapper.put("vegetarian", R.drawable.vegetarian);
		Flag2IntMapper.put("nouvelle", R.drawable.nouvelle);
		Flag2IntMapper.put("outdoor", R.drawable.outdoor);
		Flag2IntMapper.put("cajun", R.drawable.cajun);
		Flag2IntMapper.put("fusion", R.drawable.fusion);
		Flag2IntMapper.put("american", R.drawable.american);
		Flag2IntMapper.put("armenian", R.drawable.armenian);
		Flag2IntMapper.put("australian", R.drawable.australian);
		Flag2IntMapper.put("austrian", R.drawable.austrian);
		Flag2IntMapper.put("brazilian", R.drawable.brazilian);
		Flag2IntMapper.put("british", R.drawable.british);
		Flag2IntMapper.put("chinese", R.drawable.chinese);
		Flag2IntMapper.put("cypriot", R.drawable.cypriot);
		Flag2IntMapper.put("dutch", R.drawable.dutch);
		Flag2IntMapper.put("ethiopian", R.drawable.ethiopian);
		Flag2IntMapper.put("filipino", R.drawable.filipino);
		Flag2IntMapper.put("french", R.drawable.french);
		Flag2IntMapper.put("german", R.drawable.german);
		Flag2IntMapper.put("greek", R.drawable.greek);
		Flag2IntMapper.put("hungarian", R.drawable.hungarian);
		Flag2IntMapper.put("indian", R.drawable.indian);
		Flag2IntMapper.put("iranian", R.drawable.iranian);
		Flag2IntMapper.put("irish", R.drawable.irish);
		Flag2IntMapper.put("israeli", R.drawable.israeli);
		Flag2IntMapper.put("italian", R.drawable.italian);
		Flag2IntMapper.put("japanese", R.drawable.japanses);
		Flag2IntMapper.put("korean", R.drawable.korean);
		Flag2IntMapper.put("lebanese", R.drawable.lebanese);
		Flag2IntMapper.put("mexican", R.drawable.mexican);
		Flag2IntMapper.put("moroccan", R.drawable.moroccan);
		Flag2IntMapper.put("polynesian", R.drawable.polynesian);
		Flag2IntMapper.put("portuguese", R.drawable.portuguese);
		Flag2IntMapper.put("russian", R.drawable.russian);
		Flag2IntMapper.put("spanish", R.drawable.spanish);
		Flag2IntMapper.put("thai", R.drawable.thai);
		Flag2IntMapper.put("turkish", R.drawable.turkish);
		Flag2IntMapper.put("vietnamese", R.drawable.vietnamese);
	}

	// field
	Map<String, Integer> Flag2IntMapper = new HashMap<String, Integer>();

}
