package com.noblebug.chefpro.SQLite;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.recipe.Recipe;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;

public class BackEndSQLite {
	 //
	 // this is the database. The inner class DatabaseStarter opens and closes the database.
	 // there are methods for just about everything/anything in chef. 
	 // it could use transactions for entering recipes (if SQLite3 accepts this). 
	 // WakeLOCK methods still not working.
	 // 4 june 2011
	 //

	// private class to create,update database. called from BackEndSQLite
	private static class DatabaseStarter extends SQLiteOpenHelper {

		DatabaseStarter(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE_TABLE_RECIPE);
			db.execSQL(DATABASE_CREATE_TABLE_INSTRUCTIONS);
			db.execSQL(DATABASE_CREATE_TABLE_INGREDIENTS);
			db.execSQL(DATABASE_CREATE_TABLE_USER);
			db.execSQL(DATABASE_CREATE_TABLE_SETTINGS);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			//System.out.println("****** DatabaseStarter onUpgrade");
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_RECIPE + "");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_INGREDIENTS
					+ "");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_INSTRUCTIONS
					+ "");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_USER + "");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_SETTINGS + "");
			onCreate(db);
		}
	}

	/**
	 * Constructor - takes the context to allow the database to be
	 * opened/created
	 * 
	 * @param ctx
	 *            the Context within which to work
	 */
	public BackEndSQLite(Context ctx) {
		this.mCtx = ctx;
	}

	/**
	 * Open the Recipe database. If it cannot be opened, try to create a new
	 * instance of the database. If it cannot be created, throw an exception to
	 * signal the failure
	 * 
	 * @return this (self reference, allowing this to be chained in an
	 *         initialization call)
	 * @throws SQLException
	 *             if the database could be neither opened or created
	 */
	public BackEndSQLite open() throws SQLException {
		try {
			// see how much space is available:
			float MBavailable = megabytesAvailable();
			System.out.println("*** Chef:BackEndSQLite  MBavailable = "+MBavailable);
			
			mDbHelper = new DatabaseStarter(mCtx);
			mDb = mDbHelper.getWritableDatabase();
			this.isDatabaseOpen = true;
			//System.out.println("****** BackEndSQLite::open() ");
			return this;
		} catch (SQLException e) {
			this.isDatabaseOpen = false;
			e.printStackTrace();
			return this;
		}
	}

	public void close() {
		this.isDatabaseOpen = false;
		mDbHelper.close();
	}

	public void updateRecipe(Recipe recipeobj) {
		// update the fields of this recipe
		ContentValues recipeValues = new ContentValues();
		// need to implement dynamic AISLE finder, for now: nothing
		recipeValues.put(KEY_RECIPENAME, recipeobj.recipename);
		recipeValues.put(KEY_RECIPEID, recipeobj.recipeid);
		recipeValues.put(KEY_CHEFNAME, recipeobj.chefname);
		recipeValues.put(KEY_CUISINE, recipeobj.cuisine);
		recipeValues.put(KEY_CATEGORY, recipeobj.category);
		recipeValues.put(KEY_SERVES, recipeobj.serves);
		recipeValues.put(this.KEY_RECIPEUSERID, recipeobj.user);
		recipeValues.put(this.KEY_CHEFIMAGEDOWNLOADED, recipeobj.chefimagedownloaded);
		recipeValues.put(KEY_CHEFIMAGENAME,recipeobj.chefimagename);
		recipeValues.put(KEY_PARTOFCOOKBOOK, recipeobj.partofcookbook);
		recipeValues.put(this.KEY_BOOKMARKED, recipeobj.bookmarked);
		recipeValues.put(KEY_RATING, recipeobj.rating);
		if (recipeobj.Imagehttp==null){
			recipeobj.Imagehttp = null;
		} else {
			recipeobj.Imagehttp = recipeobj.Imagehttp.replace(" ", "%20");
		}
		recipeValues.put(this.KEY_IMAGEHTTP, recipeobj.Imagehttp);
		recipeValues.put(this.KEY_DESCRIPTION, recipeobj.description);
		if (recipeobj.recipeid!=-10) {  //-10=userAddedItems
			recipeValues.put(this.KEY_CHANGED, Integer
					.toString(recipeobj.changed));
		}
		mDb.update(DATABASE_TABLE_RECIPE, recipeValues, this.KEY_RECIPEID + "=" + recipeobj.recipeid, null);

		if (recipeobj.recipeid!=10) {//-10=userAddedItems
			String[] instructionsArray = recipeobj.instructionsArray;
			for (int i = 0; i < instructionsArray.length; i++) {
				ContentValues instructionValues = new ContentValues();
				instructionValues.put(KEY_RECIPEID, recipeobj.recipeid);
				instructionValues.put(KEY_STEPNUM, i);
				instructionValues.put(KEY_INSTRUCTIONS, instructionsArray[i]);
				mDb.update(DATABASE_TABLE_INSTRUCTIONS, instructionValues, this.KEY_RECIPEID + "=" + recipeobj.recipeid, null);
			}
		}

		String[] ingredientsArray = recipeobj.ingredientsArray;
		// format of Array item:  ingrednumber_number_fraction_unit_desc
		for (int m = 0; m < ingredientsArray.length; m++) {
			ContentValues ingredientsValues = new ContentValues();
			ingredientsValues.put(KEY_RECIPEID, recipeobj.recipeid);
			String[] rowarray = ingredientsArray[m].split("_");
			ingredientsValues.put(KEY_INGREDIENTNUMBER, rowarray[0]);
			ingredientsValues.put(KEY_QUANTITY, rowarray[1]);
			ingredientsValues.put(KEY_FRACTION, rowarray[2]);
			ingredientsValues.put(KEY_UNIT, rowarray[3]);
			ingredientsValues.put(this.KEY_ITEM, rowarray[4]);
			ingredientsValues.put(this.KEY_PARTOFGROCERYLIST, recipeobj.partofgrocerylist);
			ingredientsValues
					.put(this.KEY_RECIPENAME, recipeobj.recipename);
			mDb.update(DATABASE_TABLE_INGREDIENTS,ingredientsValues, this.KEY_RECIPEID + "=" + recipeobj.recipeid, null);
		}
	}
	
	public static float megabytesAvailable() {
		File path = Environment.getDataDirectory(); 
		StatFs stat = new StatFs(path.getPath());
	    long bytesAvailable = (long)stat.getBlockSize() * (long)stat.getAvailableBlocks();
	    return bytesAvailable / (1024.f * 1024.f);
	}
	
	
	public long addRecipe(Recipe recipeobj) {
		// adds a recipe to the database
		long resultadder = -1;

		TotalNumberRecipes = TotalNumberRecipes + 1;

		// DO NOT ADD if recipe is already there:
		Cursor cursorRecipe = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CUISINE },
				KEY_RECIPEID + "=" + recipeobj.recipeid, null, null, null,
				null, null);
		if (cursorRecipe.getCount() == 0) {
			//Log.v(TAG, "BackEndSQLite::addRecipe.recipeid="+String.valueOf(recipeobj.recipeid));
			//
			 // _id recipename recipeid chefname cuisine category serves
			 // partofcookbook rating" + picturename pictureresourceidint
			 // description changed partofgrocerylist
			 //
			// null means not there yet, so add this recipe
			ContentValues recipeValues = new ContentValues();
			// need to implement dynamic AISLE finder, for now: nothing
			recipeValues.put(KEY_RECIPENAME, recipeobj.recipename);
			recipeValues.put(KEY_RECIPEID, recipeobj.recipeid);
			recipeValues.put(KEY_CHEFNAME, recipeobj.chefname);
			recipeValues.put(KEY_CUISINE, recipeobj.cuisine);
			// all categories should be in lower case:
			//String temp2 = recipeobj.category.toLowerCase(); // category in lower case
			//recipeobj.category = temp2;
			recipeobj.category = setCategory2Uppercase(recipeobj.category);
			recipeValues.put(KEY_CATEGORY, recipeobj.category);
			recipeValues.put(KEY_SERVES, recipeobj.serves);
			recipeValues.put(this.KEY_RECIPEUSERID, recipeobj.user);
			recipeValues.put(this.KEY_CHEFIMAGEDOWNLOADED, recipeobj.chefimagedownloaded);
			recipeValues.put(KEY_CHEFIMAGENAME,recipeobj.chefimagename);
			recipeValues.put(KEY_PARTOFCOOKBOOK, recipeobj.partofcookbook);
			recipeValues.put(this.KEY_BOOKMARKED, recipeobj.bookmarked);
			recipeValues.put(KEY_RATING, recipeobj.rating);
			if (recipeobj.Imagehttp==null){
				recipeobj.Imagehttp = null;
			} else {
				recipeobj.Imagehttp = recipeobj.Imagehttp.replace(" ", "%20");
			}
			recipeValues.put(this.KEY_IMAGEHTTP, recipeobj.Imagehttp);
			recipeValues.put(this.KEY_DESCRIPTION, recipeobj.description);
			if (recipeobj.recipeid==-10) {
				// user-added item from grocerylist
				// do not add value to key KEY_CHANGED, it can be null
			} else {
				recipeValues.put(this.KEY_CHANGED, Integer
						.toString(recipeobj.changed));
			}
			resultadder = mDb.insert(DATABASE_TABLE_RECIPE, null, recipeValues);

			if (recipeobj.recipeid==-10) {
				// user-added item from grocerylist
				// no need for instructions:
			} else {
				String[] instructionsArray = recipeobj.instructionsArray;
				for (int i = 0; i < instructionsArray.length; i++) {
					ContentValues instructionValues = new ContentValues();
					instructionValues.put(KEY_RECIPEID, recipeobj.recipeid);
					instructionValues.put(KEY_STEPNUM, i);
					instructionValues.put(KEY_INSTRUCTIONS, instructionsArray[i]);
					resultadder = resultadder
							+ mDb.insert(DATABASE_TABLE_INSTRUCTIONS, null,
									instructionValues);
				}
			}

			String[] ingredientsArray = recipeobj.ingredientsArray;
			// ingrednumber_number_fraction_unit_desc
			for (int m = 0; m < ingredientsArray.length; m++) {
				ContentValues ingredientsValues = new ContentValues();
				ingredientsValues.put(KEY_RECIPEID, recipeobj.recipeid);
				String[] rowarray = ingredientsArray[m].split("_");
				// The code really relies on the 5-value format of:  ingrednumber_number_fraction_unit_desc.
				//  So if rowarray.length!=5, then add something, anything there.
				if (rowarray.length==5) {
					ingredientsValues.put(KEY_INGREDIENTNUMBER, rowarray[0]);
					ingredientsValues.put(KEY_QUANTITY, rowarray[1]);
					ingredientsValues.put(KEY_FRACTION, rowarray[2]);
					ingredientsValues.put(KEY_UNIT, rowarray[3]);
					ingredientsValues.put(this.KEY_ITEM, rowarray[4]);
				} else {
					// rowarray.length!=5. This is a problem. Must do something for all 4 values use switch/case
					// This is not correct.  I don't know which recipes will not have length=5.  So put obviously
					// 			wrong values, so users will complain and email chef.
					ingredientsValues.put(KEY_INGREDIENTNUMBER, m);
					ingredientsValues.put(KEY_QUANTITY, 0);
					ingredientsValues.put(KEY_FRACTION, 0);
					ingredientsValues.put(KEY_UNIT, 0);
					ingredientsValues.put(this.KEY_ITEM, ingredientsArray[m]+": problem with recipe. please contact us using Contact Us in Menu ");
				}
				// set grocerylist=1. assume when adding recipe, items not in
				// grocerylist
				ingredientsValues.put(this.KEY_PARTOFGROCERYLIST, 1);
				ingredientsValues
						.put(this.KEY_RECIPENAME, recipeobj.recipename);
				resultadder = resultadder
						+ mDb.insert(DATABASE_TABLE_INGREDIENTS, null,
								ingredientsValues);
			}
		}

		// close array
		cursorRecipe.close();
		
		return resultadder; // result adder should tell how many times/rows?
							// total updated
	}

	private String setCategory2Uppercase(String category) {
		// this method is used to convert categories to upper case
		String returnvalue = "Main Course";
		String[] categories = this.mCtx.getResources().getStringArray(R.array.categories); 
		for (int m=0; m<categories.length ;m++){
			if (categories[m].equalsIgnoreCase(category)) {
				returnvalue = categories[m];
			}
		}
		return returnvalue;
	}

	public void bookmarkrecipe(Integer recipeid) {
		// bookmark (=0) this recipe
		Integer zeroINT = 0;
		ContentValues values = new ContentValues();
		values.put(this.KEY_BOOKMARKED, zeroINT);
		int rowsaffected = mDb.update(this.DATABASE_TABLE_RECIPE, values,
				KEY_RECIPEID + "=" + recipeid, null);
	}

	public void clearAllIngredients() {
		// clear all recipes from grovery list
		Integer oneINT = 1;
		ContentValues values = new ContentValues();
		values.put(this.KEY_PARTOFGROCERYLIST, oneINT);
		int rowsaffected = mDb.update(this.DATABASE_TABLE_INGREDIENTS, values, null, null);
	}

	public void addFullRecipe2GroceryList(Integer recipeid) {
		// set this recipeID to be a part of the list zeroINT=0
		String whereClause = KEY_RECIPEID + "=" + recipeid;
		Integer zeroINT = 0;
		ContentValues values = new ContentValues();
		values.put(this.KEY_PARTOFGROCERYLIST, zeroINT);
		int rowsaffected = mDb.update(this.DATABASE_TABLE_INGREDIENTS, values,
				whereClause, null);
	}
	public boolean hasRecipeBYId(Integer recipeid) {
		// test to see if recipe has been added
		Cursor cursorRecipe = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID },
				KEY_RECIPEID + "=" + recipeid, null, null, null,
				null, null);
		if (cursorRecipe.getCount() == 0) {
			cursorRecipe.close();
			return false;
		} else {
			cursorRecipe.close();
			return true;
		}
	}

	public Long getDataBaseSize() {
		return mDb.getPageSize();
	}

	public void addUserSingle(String username, String password, Integer userid, String md5password) {
		// this method will delete any existing users, old information is lost.
		// this can be used when the user starts with userid=-1, then updates to userid=4.
		
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERNAME, username);
		values.put(this.KEY_PASSWORD, password);
		values.put(this.KEY_MD5HASHINFO, md5password);
		values.put(this.KEY_USERID, userid);
		int useridNegONE = -1;
		mDb.update(this.DATABASE_TABLE_USER, values, this.KEY_USERID + "=" + useridNegONE , null);
	}
	
	public String[] getUserSingle() {  //(Integer userid) {
		// returns:  username_passowrd_md5password_userid
		// since the addUserSingle only has one row don't need getUserSingle
		//String[] out = an array. so parsing on "_" (old version) is no longer necessary. if username=james_pizagno, then parsing "_" failes.
		String[] out = new String[4];
		out[this.out_int_username] = "newUser";
		out[this.out_int_password] = "newUserpassword";
		out[this.out_int_md5hashpass] = "defaultmd5hash";
		out[this.out_int_userid] = "-1";
		Cursor cursorUser = mDb.query(true, DATABASE_TABLE_USER,
				new String[] { this.KEY_USERNAME,this.KEY_PASSWORD,this.KEY_MD5HASHINFO,this.KEY_USERID}, 
						null, null, null, null, null, null);
						//this.KEY_USERID+"=" + userid, null, null, null, null, null);
		if (cursorUser != null && cursorUser.getCount()>0) {
			cursorUser.moveToFirst();
			String username = cursorUser.getString(cursorUser
					.getColumnIndexOrThrow(BackEndSQLite.KEY_USERNAME));
			String password = cursorUser.getString(cursorUser
					.getColumnIndexOrThrow(BackEndSQLite.KEY_PASSWORD));
			String md5password = cursorUser.getString(cursorUser
					.getColumnIndexOrThrow(BackEndSQLite.KEY_MD5HASHINFO));
			String useridout = cursorUser.getString(cursorUser
					.getColumnIndexOrThrow(BackEndSQLite.KEY_USERID));
			//out = username+"_"+password+"_"+md5password+"_"+useridout;
			out[this.out_int_username] = username;
			out[this.out_int_password] = password;
			out[this.out_int_md5hashpass] = md5password;
			out[this.out_int_userid] = useridout;
		}
		cursorUser.close();
		return out;
	}
	
	public void addUserAppend(String username, String password, Integer userid) {
		// add user to the database
		// only want one user at a time.
		ContentValues args = new ContentValues();
		args.put(this.KEY_USERNAME, username);
		args.put(this.KEY_PASSWORD, password);
		args.put(this.KEY_MD5HASHINFO, "junk");
		args.put(this.KEY_USERID, userid);
		mDb.insert(this.DATABASE_TABLE_USER, null, args);
	}

	// gets number of users 
	public int getNumUsers() {
		// gets number of users.
		// CRASH REPORT:  Got a crash on line="Cursor cursorAllUsers = mDb.query(this.DATABASE_TABLE_USER,"
		//    below for java.lang.NullPointerException.  Which maybe is caused by mDb=null.  Don't know why.
		//    maybe phone drive is full and database cannot open. 
		int count = 0;
		if (this.isDatabaseOpen==false || mDb==null) {
			count = 0;
		} else {
			Cursor cursorAllUsers = mDb.query(this.DATABASE_TABLE_USER,
					new String[] { this.KEY_USERNAME, this.KEY_USERID }, null,
					null, null, null, null);
			if (cursorAllUsers != null) {
				cursorAllUsers.moveToFirst();
			}
			count = cursorAllUsers.getCount();
			cursorAllUsers.close();
		}
		//return cursorAllUsers;
		return count;
	}

	public boolean deleteAllRecipes() {
		// delete all but User Info/Settings.  Should not be used.
		int resulttester;
		resulttester = mDb.delete(DATABASE_TABLE_RECIPE, null, null);
		resulttester = resulttester
				+ mDb.delete(DATABASE_TABLE_INSTRUCTIONS, null, null);
		resulttester = resulttester
				+ mDb.delete(DATABASE_TABLE_INGREDIENTS, null, null);
		return true;
	}

	public void deleteRecipe(int recipeId) {
		mDb.delete(DATABASE_TABLE_RECIPE, this.KEY_RECIPEID + "=" + recipeId,
				null);
		mDb.delete(DATABASE_TABLE_INSTRUCTIONS, this.KEY_RECIPEID + "="
				+ recipeId, null);
		mDb.delete(DATABASE_TABLE_INGREDIENTS, this.KEY_RECIPEID + "="
				+ recipeId, null);
		return;
	}

	public Recipe getRecipeByID(int id_wanted) throws SQLException {
		// get recipe by ID. called from several classes.
		// KEY_RATING,KEY_PICTURENAME,
		// KEY_PICTURERESOURCEIDINT,this.KEY_DESCRIPTION,
		Cursor cursorRecipe = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_RATING,
						this.KEY_IMAGEHTTP, this.KEY_DESCRIPTION,
						this.KEY_CHANGED, this.KEY_BOOKMARKED, this.KEY_RECIPEUSERID,
						this.KEY_CHEFIMAGEDOWNLOADED,this.KEY_CHEFIMAGENAME}, KEY_RECIPEID
						+ "=" + id_wanted, null, null, null, null, null);
		if (cursorRecipe != null) {
			cursorRecipe.moveToFirst();
		}

		// ingrednumber_number_fraction_unit_desc
		Cursor cursorIngredients = mDb.query(true, DATABASE_TABLE_INGREDIENTS,
				new String[] { KEY_RECIPEID, KEY_INGREDIENTNUMBER,
						KEY_QUANTITY, KEY_FRACTION, KEY_UNIT, KEY_ITEM },
				KEY_RECIPEID + "=" + id_wanted, null, null, null, null, null);
		if (cursorIngredients != null) {
			cursorIngredients.moveToFirst();
		}

		Cursor cursorInstructions = mDb.query(true,
				DATABASE_TABLE_INSTRUCTIONS, new String[] { KEY_RECIPEID,
						KEY_STEPNUM, KEY_INSTRUCTIONS }, KEY_RECIPEID + "="
						+ id_wanted, null, null, null, null, null);
		if (cursorInstructions != null) {
			cursorInstructions.moveToFirst();
		}
		Recipe recipeReturn = new Recipe();

		recipeReturn.setFieldsFrom3Cursors(cursorRecipe, cursorIngredients,
				cursorInstructions);

		return recipeReturn;
	}
	
	public boolean chefImageDownaloded(String chefname) {
		// used to test if a chef image has already been downloaded.
		// used by RecipeDisplay.  If chef image has already been 
		// downloaded, then dont down load it again, bc it wastes time/resources.
		Cursor cursorChefs = mDb.query(true,
				DATABASE_TABLE_RECIPE, new String[] {this.KEY_CHEFIMAGEDOWNLOADED}, 
				this.KEY_CHEFNAME + "= '" + chefname + "'", 
				null, null, null, null, null);
		if (cursorChefs != null) {
			cursorChefs.moveToFirst();
		}
		boolean result = false;  // instantiate as false
		for (int i=0;i<cursorChefs.getCount();i++){
			cursorChefs.moveToPosition(i);
			if (cursorChefs.getInt(cursorChefs
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CHEFIMAGEDOWNLOADED))==0){
				result=true;
				// have the image,so set result to true
			}
		}
		cursorChefs.close();
		return result;
	}

	// fetch recipes that are in the cookbook.
	public Cursor getRecipes4Cookbook() {
		// get all cursors with KEY_PARTOFCOOKBOOK=0
		Cursor cursorRecipes = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP,
						this.KEY_RATING, this.KEY_BOOKMARKED },
				KEY_PARTOFCOOKBOOK + "=" + 0 +" AND "+this.KEY_RECIPEID+" > "+0, null, null, null, null, null);
		if (cursorRecipes != null) {
			cursorRecipes.moveToFirst();
		}
		return cursorRecipes;
	}
	
	public Cursor getChefsUidDownloaded() {
		// get cursor for the Chefname-ChefID for the cookbook/chefs option.
		// want ALL chefs, even if image not downloaded. If image NOT downloaded, use drawable.chefprofile
		int idtest = 0; // user here to ignore id=-10
		Cursor cursorChefusid = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] {this.KEY_CHEFNAME,this.KEY_RECIPEUSERID,
				this.KEY_CHEFIMAGEDOWNLOADED,this.KEY_CHEFIMAGENAME},
				this.KEY_RECIPEID+">"+idtest, null, null, null, null, null);
				//this.KEY_CHEFIMAGEDOWNLOADED+"="+0,null, null, null, null, null);
		if(cursorChefusid!=null) {
			cursorChefusid.moveToFirst();
		}
		return cursorChefusid;
	}
	
	public Cursor getCuisines() {
		// get cursor for the List Cuisines for the cookbook/cuisines option.
		int idtest = 0; // user here to ignore id=-10
		 String sortOrder = this.KEY_CUISINE;
		Cursor cursorCuisines = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] {this.KEY_CUISINE},this.KEY_RECIPEID+">"+idtest,null, null, null, sortOrder, null);
		if(cursorCuisines!=null) {
			cursorCuisines.moveToFirst();
		}
		return cursorCuisines;
	}
	
	public Cursor getCategories() {
		// build cursor of categories for categories in Cookbook
		int idtest = 0; // user here to ignore id=-10
		Cursor cursorCategories = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] {this.KEY_CATEGORY},this.KEY_RECIPEID+">"+idtest,null, null, null, null, null);
		if(cursorCategories!=null){
			cursorCategories.moveToFirst();
		}
		return cursorCategories;
	}

	// get grocery list items, and recipe for grocerylist
	public Cursor getAllGroceryListItemsAndRecipeName() {
		int idtest = 0;
		Cursor cursor = mDb.query(true, this.DATABASE_TABLE_INGREDIENTS,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID,
						KEY_INGREDIENTNUMBER, KEY_QUANTITY, KEY_FRACTION,
						KEY_UNIT, KEY_ITEM, this.KEY_PARTOFGROCERYLIST },
				this.KEY_PARTOFGROCERYLIST + "=" + idtest, null, null, null,
				null, null);
		if (cursor != null) {
			cursor.moveToFirst();
		}
		return cursor;
	}

	public void clearCheckedGroceryItems(List listRecipeIDitem) {
		// 
		 // this method sets groceryitems to unchecked(KEY_PARTOFGROCERYLIST=0).
		 // it needs the description and recipid.
		 //
		
		Iterator itr = listRecipeIDitem.iterator();
		while (itr.hasNext()) {
			String value = (String) itr.next();
			//System.out.println("***** BackEndSQLite::clearCheckedGroceryItems value="+value+".");
			String item = (String) value.split("&&&&")[0];
			Integer recipeID = Integer.valueOf(value.split("&&&&")[1]);
			Integer oneINT = 1;
			ContentValues values = new ContentValues();
			values.put(this.KEY_PARTOFGROCERYLIST, oneINT);
			int rowsaffected = mDb.update(this.DATABASE_TABLE_INGREDIENTS,
					values, KEY_RECIPEID + "=" + recipeID + " AND "
							+ this.KEY_ITEM + "= \"" + item + "\" ", null);
		}
	}
	
	public void updateAislelist(Integer userid, String[] Aislelisttemp) {
		// add Aisle list after user edits it
		String value = "";
		for(int m=0;m<Aislelisttemp.length;m++){
			value=value+Aislelisttemp[m]+"::";
		}
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTIINGSKEY, "aislelist");
		values.put(this.KEY_SETTINGSVALUE, value);
		values.put(this.KEY_USERID, userid);
		Long rowsaffected = mDb.insert(this.DATABASE_TABLE_SETTINGS, null, values);
	}
	public String[] getAislelist(int userid) {
		// returns aislelist for user, used in GroceryList "Aisle" view
		String name = "aislelist";
		Cursor cursorAisle = mDb.query(true, this.DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND "
				+ this.KEY_SETTIINGSKEY + "= \""+name+"\" ", null, null, null,
				null, null);
		if (cursorAisle != null) {
			cursorAisle.moveToFirst();
		}
		String[] Aislelist = new String[21];
		String[] temp = cursorAisle.getString(cursorAisle
				.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE)).split("::");
		for(int m=0;m<temp.length;m++){
			Aislelist[m]=temp[m];
		}
		cursorAisle.close();
		return Aislelist;
	}

	public void addGroceryItems(List listRecipeIDitem) {
		Iterator itr = listRecipeIDitem.iterator();
		while (itr.hasNext()) {
			String value = (String) itr.next();
			String item = (String) value.split("&&&&")[0];
			Integer recipeID = Integer.valueOf(value.split("&&&&")[1]);
			Integer zeroINT = 0;
			ContentValues values = new ContentValues();
			values.put(this.KEY_PARTOFGROCERYLIST, zeroINT);
			int rowsaffected = mDb.update(this.DATABASE_TABLE_INGREDIENTS,
					values, KEY_RECIPEID + "=" + recipeID + " AND "
							+ this.KEY_ITEM + "= \"" + item + "\" ", null);
		}
	}

	public Cursor getRecipes4GroceryList() {
		// get recipes that are in the grocery list
		// get all cursors with KEY_PARTOFGROCERYLIST=0
		int idtest = 0;
		Cursor cursorRecipes = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_PARTOFGROCERYLIST },
				this.KEY_PARTOFGROCERYLIST + "=" + idtest, null, null, null,
				null, null);
		if (cursorRecipes != null) {
			cursorRecipes.moveToFirst();
		}
		return cursorRecipes;
	}

	public Cursor getRecipesbyCategory(String categorytype) {
		// get categoriescursor. get all recipes by a given category
		Cursor cursorCategory = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP, this.KEY_RATING }, KEY_CATEGORY
						+ " = '" + categorytype + "' AND "+this.KEY_RECIPEID+" > "+0, null, null, null, null,
				null);
		if (cursorCategory != null) {
			cursorCategory.moveToFirst();
		}
		return cursorCategory;
	}
	
	public Cursor getCategoryChef(int chefid, String categorytype) {
		// getCategoryChef(chefid,categories[category_i]).  Used by RecipeListDisplay when separating the 
		//      recipes.
		Cursor cursorCategory = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP, this.KEY_RATING }, KEY_CATEGORY
						+ " = '" + categorytype + "' AND "+this.KEY_RECIPEID+" > "+0+" AND "+this.KEY_RECIPEUSERID+"= '"+chefid+"'", 
						null,null,null,null,null);
		if (cursorCategory != null) {
			cursorCategory.moveToFirst();
		}
		return cursorCategory;
	}
	
	public Cursor getCategoryCuisine(String cuisinetype, String categorytype) {
		// getCategoryCuisine(cuisinetype,categories[category_i]);.  Used by RecipeListDisplay when separating the 
		//      recipes.
		Cursor cursorCategory = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP, this.KEY_RATING }, KEY_CATEGORY
						+ " = '" + categorytype + "' AND "+this.KEY_RECIPEID+" > "+0+" AND "+this.KEY_CUISINE+"= '"+cuisinetype+"'", 
						null,null,null,null,null);
		if (cursorCategory != null) {
			cursorCategory.moveToFirst();
		}
		return cursorCategory;
	}

	// get recipes by cuisine. called by cookbook
	public Cursor getRecipesbyCuisine(String cuisinetype) {
		// get all cursors with KEY_PARTOFCOOKBOOK=0
		Cursor cursorCuisines = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP , this.KEY_RATING}, KEY_CUISINE
						+ " = '" + cuisinetype + "' AND "+this.KEY_RECIPEID+" > "+0, null, null, null, null,
				null);
		if (cursorCuisines != null) {
			cursorCuisines.moveToFirst();
		}
		return cursorCuisines;
	}
	
	public Cursor getRecipesbyChef(Integer chefid) {
		// get recipe by chefid=this.KEY_RECIPEUSERID
		Cursor cursorChefs = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP , this.KEY_RATING}, this.KEY_RECIPEUSERID
						+ "= '" + chefid + "' AND "+this.KEY_RECIPEID+" > "+0, null, null, null, null,
				null);
		if (cursorChefs != null) {
			cursorChefs.moveToFirst();
		}
		return cursorChefs;
	}

	public Map<String, Integer> getAllCuisines4Cookbook() {
		// get all cursors with KEY_PARTOFCOOKBOOK=0
		// return a Map. use map because only want unique set of cuisine/string.
		// no repeated cuisines. ie. only Spanish dishes once.
		Cursor cursorCuisines = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPENAME, KEY_RECIPEID, KEY_CHEFNAME,
						KEY_CUISINE, KEY_CATEGORY, KEY_SERVES,
						KEY_PARTOFCOOKBOOK, this.KEY_IMAGEHTTP },
				KEY_PARTOFCOOKBOOK + "=" + 0+" AND "+this.KEY_RECIPEID+" > "+0, null, null, null, null, null);
		if (cursorCuisines != null) {
			cursorCuisines.moveToFirst();
		}
		for (int m = 0; m < cursorCuisines.getCount(); m++) {
			cursorCuisines.moveToPosition(m);
			String cuisine = cursorCuisines.getString(cursorCuisines
					.getColumnIndexOrThrow(BackEndSQLite.KEY_CUISINE));
			CuisinesInCookBook.put(cuisine, 0);
		}
		cursorCuisines.close();
		return CuisinesInCookBook;
	}
	
	
	public void setDefaultSearchSettings(Integer userid){
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERID, String.valueOf(userid));
		values.put(this.KEY_SETTIINGSKEY, "searchsettings");
		values.put(this.KEY_SETTINGSVALUE, "latest::NO::NO::NO::NO");
		mDb.insert(DATABASE_TABLE_SETTINGS,null, values);
	}
	public void setSearchSettings(Integer userid, String settings){
		// table format: DATABASE_TABLE_SETTINGS KEY_USERID (integer not null) KEY_SETTIINGSKEY(text not null)
		//KEY_SETTINGSVALUE(text not null)
		//
		// Also Strings settings = order+"::"+dairyfree+"::"+eggfree+"::"+glutenfree+"::"+nutfree;
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, settings);
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'searchsettings'", null);
	}
	public String getSearchSettings(Integer userid) {
		// get the settings.  used by SearchDisplay
		Cursor cursor = mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] {this.KEY_SETTINGSVALUE}, this.KEY_USERID + "=" + userid + " AND "
				+ this.KEY_SETTIINGSKEY + "= 'searchsettings'",
				null, null, null, null, null);
		if (cursor != null) {
			cursor.moveToFirst();
		}
		String settings = cursor.getString(cursor.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE));
		cursor.close();
		return settings;
	}
	
	public Integer[] getAllRecipesCookbook() {
		// returns all recipes on the Cookbook
		// used by Home.java for cyncing Cookbook with webpage
		Cursor recipesCursor =mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPEID },
		KEY_PARTOFCOOKBOOK + "=" + 0, null, null, null, null, null);
		if (recipesCursor != null) {
			recipesCursor.moveToFirst();
		}
		Integer[] result = new Integer[recipesCursor.getCount()];
		for (int i=0;i<recipesCursor.getCount();i++){
			recipesCursor.moveToPosition(i);
			result[i]= recipesCursor.getInt(recipesCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID));
		}
		recipesCursor.close();
		return result;
	}
	
	public void insertRecipeLastUpdateTime(Integer userid, Long time){
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERID, String.valueOf(userid));
		values.put(this.KEY_SETTIINGSKEY, "timelastupdated");
		values.put(this.KEY_SETTINGSVALUE, String.valueOf(time));
		mDb.insert(DATABASE_TABLE_SETTINGS,null, values);
	}
	
	public void updateRecipeLastUpdateTime(Integer userid, Long time) {
		// table format: DATABASE_TABLE_SETTINGS KEY_USERID (integer not null) KEY_SETTIINGSKEY(text not null)
		//KEY_SETTINGSVALUE(text not null)
		//
		// Also Strings settings = order+"::"+dairyfree+"::"+eggfree+"::"+glutenfree+"::"+nutfree;
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, String.valueOf(time));
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'timelastupdated'", null);
	}
	
	public Long getRecipeLastUpdateTime(Integer userid) {
		// used by Home.java to sync cookbook on phone/webpage
		Cursor recipesCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'timelastupdated'",
				null, null, null, null, null);
		if (recipesCursor != null) {
			recipesCursor.moveToFirst();
		}
		Long dateLastUpdated = recipesCursor.getLong(recipesCursor
				.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE));
		recipesCursor.close();
		return dateLastUpdated;
	}
	
	public void insertStartingPage(String userid){
		// called by NewUser, just sets the starting page to "Home"
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERID, String.valueOf(userid));
		values.put(this.KEY_SETTIINGSKEY, "startingpage");
		values.put(this.KEY_SETTINGSVALUE, "Home");
		mDb.insert(DATABASE_TABLE_SETTINGS,null, values);
	}
	
	public void setStartingPage(String userid, String startingPage) {
		// options are "Home" "Cookbook" "Grocery List" "Search" "Timers"
		//
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, startingPage);
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'startingpage'", null);
	}
	
	public String getStartingPage(String userid){
		Cursor startingpageCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'startingpage'",
				null, null, null, null, null);
		if (startingpageCursor != null) {
			startingpageCursor.moveToFirst();
		}
		String startingPage = "ProblemBackEndSQLite getStartingPage";
		if (startingpageCursor.getCount()==0) {
			// starting page never set.
			insertStartingPage(userid);
			startingPage = "Home";
		} else {
			startingPage = startingpageCursor.getString(startingpageCursor
				.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE));
		}
		startingpageCursor.close();
		return startingPage;
	}
	
	//
	 // Below is the functionality to remember the Grocerylist state:  aisle,recipe,or custom
	 ///
	public void insertGrocerylistState(String userid){
		// called by BackEndSQLite.getGroceryListState, and inserts the aisle as default.
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERID, String.valueOf(userid));
		values.put(this.KEY_SETTIINGSKEY, "groceryliststate");
		values.put(this.KEY_SETTINGSVALUE, "aisle");
		mDb.insert(DATABASE_TABLE_SETTINGS,null, values);
	}
	public void setGrocerylistState(String userid, String GrocerylistState) {
		// options are "aisle","recipe","custom"
		//
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, GrocerylistState);
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'groceryliststate'", null);
	}
	public String getGrocerylistState(String userid){
		// called by GrocerylistDisplay  and asks what the last state of the grocery list view was: aisle,recipe,custom?
		Cursor groceryliststateCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'groceryliststate'",
				null, null, null, null, null);
		if (groceryliststateCursor != null) {
			groceryliststateCursor.moveToFirst();
		}
		String groceryliststate = "ProblemBackEndSQLite groceryliststate";
		if (groceryliststateCursor.getCount()==0) {
			// starting page never set.
			insertGrocerylistState(userid);
			groceryliststate = "aisle";
		} else {
			groceryliststate = groceryliststateCursor.getString(groceryliststateCursor
				.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE));
		}
		groceryliststateCursor.close();
		return groceryliststate;
	}
	
	
	//
	 // Below is the functionality to remember the Cookbook state:  "cuisines","categories","chefs"
	 //
	public void insertCookbookState(String userid){
		// called by BackEndSQLite.getCookbookState, and inserts the chefs as default.
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERID, String.valueOf(userid));
		values.put(this.KEY_SETTIINGSKEY, "cookbookstate");
		values.put(this.KEY_SETTINGSVALUE, "chefs");
		mDb.insert(DATABASE_TABLE_SETTINGS,null, values);
	}
	public void setCookbookState(String userid, String CookbookState) {
		// options are chefs,categories,cuisines
		//
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, CookbookState);
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'cookbookstate'", null);
	}
	public String getCookbookState(String userid){
		// called by GCookbookDisplay  and asks what the last state of the Cookbook view was: chefs,cuisines,categories
		Cursor CookbookstateCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'cookbookstate'",
				null, null, null, null, null);
		if (CookbookstateCursor != null) {
			CookbookstateCursor.moveToFirst();
		}
		String Cookbookstate = "ProblemBackEndSQLite Cookbookstate";
		if (CookbookstateCursor.getCount()==0) {
			// starting page never set.
			insertCookbookState(userid);
			Cookbookstate = "chefs";
		} else {
			Cookbookstate = CookbookstateCursor.getString(CookbookstateCursor
				.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE));
		}
		CookbookstateCursor.close();
		return Cookbookstate;
	}
	
	public boolean getCookbookDownloaded(Integer userid) {
		// Try to figure out if we have already asked the user if they would like to download 
		// the default recipes.  this method assumes that if any user has downloaded cookbook
		//  using this phone, then value is to true, regardless of userid.  
		boolean alreadyAsked = false;
		// try to query
		Cursor askedCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_SETTIINGSKEY + "= 'askdownloadrecipes'",
				null, null, null, null, null);
		if (askedCursor != null) {
			askedCursor.moveToFirst();
		}
		if (askedCursor.getCount()==0) {
			// never asked, since entry is empy
			alreadyAsked = false;
		} else {
			// set value to 'true'
			alreadyAsked = true;
		}
		askedCursor.close();
		// ass soon as this is called ALWAYS put true in:
		ContentValues values = new ContentValues();
		values.put(this.KEY_USERID, String.valueOf(userid));
		values.put(this.KEY_SETTIINGSKEY, "askdownloadrecipes");
		values.put(this.KEY_SETTINGSVALUE, "true");
		mDb.insert(DATABASE_TABLE_SETTINGS,null, values);
		return alreadyAsked;
	}
	
	private boolean checkIfKeyInKeySettingsTable(String key, String userid) {
		Cursor testKeyExistsCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= '"+key.trim()+"'",
				null, null, null, null, null);
		if (testKeyExistsCursor == null ) {
			return false;
		} else if (testKeyExistsCursor.getCount()==0) {
			return false;
		} else {
			return true;
		}
	}
	
	public void setWakeLock(String userid, int YesOrNo) {
		// YES=0,NO=1
		//
		System.out.println("******* setWakeLock YesOrNo = "+String.valueOf(YesOrNo));
		System.out.println("******* setWakeLock userid = "+userid);
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, YesOrNo);
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'wakelock'", null);
	}
	public void setWakeLockInitial(String userid) {
		// YES=0,NO=1
		// first check to see if empty
		if (checkIfKeyInKeySettingsTable("wakelock", userid) == false) {
			// if empty then INSERT item
			System.out.println("*********************************************** setWakeLock YesOrNo=1 INITIALZE ");
			ContentValues values = new ContentValues();
			values.put(this.KEY_SETTINGSVALUE, 1);
			values.put(this.KEY_USERID, userid);
			values.put(this.KEY_SETTIINGSKEY, "wakelock");
			mDb.insert(DATABASE_TABLE_SETTINGS, null, values);
		}
	}
	public boolean getWakeLockState(String userid){
		// YES=0,NO=1
		// default to NO:
		boolean myAnswer = false;
		System.out.println("******* BackENDSQLIte::getWakeLockState setWakeLock default false ");
		System.out.println("******* BackENDSQLIte::getWakeLockState userid = "+userid);
		Cursor WakeLockCursor =mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'wakelock'",
				null, null, null, null, null);

		if (WakeLockCursor != null && WakeLockCursor.getCount()>0) {
			WakeLockCursor.moveToFirst();
			//if (WakeLockCursor.getCount()==0) {
			//	setWakeLock(userid, 1);
			//	System.out.println("******* setWakeLock false ");
			//} else {
				if(WakeLockCursor.getInt((WakeLockCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE)))==0){
					myAnswer=true;
					System.out.println("******* BackENDSQLIte::getWakeLockState setWakeLock true ");
				}
			//}
		}
		WakeLockCursor.close();
		return myAnswer;
	}
	
	
	public String[] addItem2OddsNEnds(String item2Add){
		//
		 // OddsNEnds recipe has OddsNEndsID = -10 Recipe.name="Odds N Ends", ingredients, 
		 //   and is part of the grocerylist:  this.KEY_PARTOFGROCERYLIST + "=" + 0
		 //
		List<String> finallist = new ArrayList<String>();
		// check for existing OddsNEnds recipe
		Recipe OddsNEnds = this.getRecipeByID(-10);
		// OddsNEnds recipeID = -10
		if (OddsNEnds.recipeid==null){
			// if NOT exists create, and add item2Add
			OddsNEnds.recipeid = -10;
			OddsNEnds.recipename = "Odds N Ends";
			OddsNEnds.NumIngredients = 1;
			OddsNEnds.partofgrocerylist = 0; // make it part of the grocerylist
			OddsNEnds.ingredientsArray = new String[OddsNEnds.NumIngredients];
			// ingredient format: // ingrednumber_number_fraction_unit_desc
			OddsNEnds.ingredientsArray[0] = "0____"+item2Add.trim();
			OddsNEnds.partofcookbook = 1;  //never part of cookbook
			this.addRecipe(OddsNEnds);
			this.addFullRecipe2GroceryList(OddsNEnds.recipeid);
			finallist.add(item2Add);
		} else { // already exists
			// ELSE get OddsNends, and add item2Add, put back in DB
			String[] oldlist = OddsNEnds.ingredientsArray;
			int oldNumIngredients = OddsNEnds.NumIngredients;
			for (int i=0;i<oldNumIngredients;i++){
				finallist.add(oldlist[i].split("_")[4]);
			}
			finallist.add(item2Add); // finallist is now full with new item2add
			int NumIngredients = oldNumIngredients + 1;
			String[] newlist = new String[NumIngredients];
			// add back into OddsNEends
			OddsNEnds.partofgrocerylist = 0; // make it part of the grocerylist
			OddsNEnds.partofcookbook = 1;  //never part of cookbook
			OddsNEnds.NumIngredients = NumIngredients;
			OddsNEnds.ingredientsArray = new String[NumIngredients];
			for (int m=0;m<OddsNEnds.NumIngredients;m++){
				// ingredient format: ingrednumber_number_fraction_unit_desc
				OddsNEnds.ingredientsArray[m] = String.valueOf(m)+"____"+finallist.get(m);
			}
			// give to DB with updated list, and add to grocerylist
			// can't use update recipe bc that is a databaseUPDATE need an INSERT:
			// only need to insert the most recent, since given a single item to addItem2Odds..
			ContentValues ingredientsValues = new ContentValues();
			ingredientsValues.put(KEY_RECIPEID, OddsNEnds.recipeid);
			String ingredient2Add = OddsNEnds.ingredientsArray[OddsNEnds.ingredientsArray.length-1];
			String[] rowarray = ingredient2Add.split("_");
			ingredientsValues.put(KEY_INGREDIENTNUMBER, rowarray[0]);
			ingredientsValues.put(KEY_QUANTITY, rowarray[1]);
			ingredientsValues.put(KEY_FRACTION, rowarray[2]);
			ingredientsValues.put(KEY_UNIT, rowarray[3]);
			ingredientsValues.put(this.KEY_ITEM, rowarray[4].trim());
			ingredientsValues.put(this.KEY_RECIPENAME, OddsNEnds.recipename);
			ingredientsValues.put(this.KEY_PARTOFGROCERYLIST, OddsNEnds.partofgrocerylist);
			mDb.insert(DATABASE_TABLE_INGREDIENTS, null,ingredientsValues);
			this.addFullRecipe2GroceryList(OddsNEnds.recipeid);
		}
		// return full list of OddsNnds
		String[] string2return = new String[finallist.size()];
		for (int n=0;n<finallist.size();n++){
			string2return[n] = finallist.get(n);
		}
		return string2return;
	}
	
	public void clearUserAddIngredients() {
		// used to clear the ingredients for the UserAdded recipe. ID=-10
		int rowsaffected = mDb.delete(DATABASE_TABLE_INGREDIENTS, this.KEY_RECIPEID + "="
				+ this.OddsNEndsID, null);
	}
	
	public void clearUserItems(List<String> userAddItemList) {
		Iterator itr = userAddItemList.iterator();
		while (itr.hasNext()) {
			String item = (String) itr.next();
			item=item.trim();
			int rowsaffected = mDb.delete(DATABASE_TABLE_INGREDIENTS, this.KEY_RECIPEID + "="
					+ this.OddsNEndsID +" AND "+ this.KEY_ITEM + "= \'" + item + "\' ", null);
		}
	}
	
	public boolean hasAnyRecipes() {
		// this can be called to see if any recipes are in the DB
		Cursor cursorRecipe = mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { KEY_RECIPEID}, null, null, null, null, null, null);
		if (cursorRecipe != null) {
			cursorRecipe.moveToFirst();
		}
		boolean returnvalue;
		if(cursorRecipe.getCount()==0) {
			returnvalue = false;
		} else {
			returnvalue = true;
		}
		cursorRecipe.close();
		return returnvalue;
	}

	public List<Integer> getAllRecipesNotThisUser(int userID) {
		// returns a list of recipes NOT belonging to this user.  used to send bookmarked recipes to the web
		List<Integer> returnList = new ArrayList<Integer>();
		Cursor bookmarks =mDb.query(true, DATABASE_TABLE_RECIPE,
				new String[] { this.KEY_RECIPEID },
				this.KEY_RECIPEUSERID + "!="+userID,
				null, null, null, null, null);
		if (bookmarks  != null) {
			for (int i=0;i<bookmarks.getCount();i++) {
				bookmarks.moveToPosition(i);
				returnList.add(bookmarks.getInt(bookmarks
						.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID)));
			}
		}
		bookmarks.close();
		return returnList;
	}
	
	
	public String[] getCrossItems(int userid) {
		// get all of the crossed items in the grocery list. called by GroceryList.
		// they should be parsed by '%!#!%'
		String[] answer = null;
		Cursor myCursor = mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'crossitems'",
				null, null, null, null, null);
		if (myCursor.getCount()==0) {
			// first time this may be called. so insert and return null string.
			answer = null;
			System.out.println("*** Chef.BackEndSQLite.getCrossItems answer = null. now calling zeroCrossedItems.");
			zeroCrossedItems(userid);
		} else {
			if (myCursor != null) {
				myCursor.moveToFirst();
				String temp = myCursor.getString((myCursor.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE)));
				answer = temp.split("%!#!%");
				System.out.println("*** Chef.BackEndSQLite.getCrossItems answer = "+answer);
			}
		}
		myCursor.close();
		return answer;
	}
	
	public void zeroCrossedItems(int userid) {
		// this method sets a zero value in crossitems. but adds the row with key='crossitems' to the SETTINGS table.
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, "");
		values.put(this.KEY_USERID, userid);
		values.put(this.KEY_SETTIINGSKEY, "crossitems");
		mDb.insert(DATABASE_TABLE_SETTINGS, null, values);
		System.out.println("*** Chef.BackEndSQLite.zeroCrossedItems");
	}
	
	public void setCrossItems(int userid, String item) {
		// this will add the item to the end of the grocery list.
		// first get all old items
		System.out.println("*** Chef.BackEndSQLite.setCrossItems item = "+item);
		String[] old = getCrossItems(userid);
		System.out.println("*** Chef.BackEndSQLite.setCrossItems old = "+old);
		if (old!=null && old.length==0){
			System.out.println("*** Chef.BackEndSQLite.setCrossItems old.lenth=0 old = "+old);
		}
		String newitems = "";
		if (old!=null && old.length>0) {
			// then add new item
			newitems = old[0];
			for (int i=1;i<old.length;i++){
				newitems = newitems + "%!#!%" + old[i];
				System.out.println("*** Chef.BackEndSQLite.setCrossItems old["+String.valueOf(i)+"] = "+old[i]);
			}
			// add the item sent in call to method:
			newitems = newitems + "%!#!%" + item;
			System.out.println("*** Chef.BackEndSQLite.setCrossItems newitems = "+newitems);
		} else {
			// add new item, if first one to add. there may not be others.
			newitems = item;
			System.out.println("*** Chef.BackEndSQLite.setCrossItems Single newitems = "+newitems);
		}
		// then update data
		ContentValues values = new ContentValues();
		values.put(this.KEY_SETTINGSVALUE, newitems);
		mDb.update(DATABASE_TABLE_SETTINGS, values, this.KEY_USERID + "=" + userid + " AND "
							+ this.KEY_SETTIINGSKEY + "= 'crossitems'", null);
	}
	
	public void unsetCrossItems(int userid, String text2remove) {
		// this removes a particular item.  They way I've done this seems ridiculous.
		System.out.println("*** Chef.BackEndSQLite.unsetCrossItems text2remove = "+text2remove);
		String[] currentItems = getCrossItems(userid);
		// clear key = 'crossitems' 
		zeroCrossedItems(userid);
		// remove test2remove. for remove() need LinkedList.  
		List<String> currentList = new LinkedList<String>(Arrays.asList(currentItems));
	    currentList.remove(text2remove); // this removes the first occurence
		// add each item back into the DB
		for (String val : currentList) {
			setCrossItems(userid, val);
		}
	}
	
	
	
	public void  manageMeals(String recipeinformation, int userid, String caseMeal) {
		// meal has been changed by MealEditor.java.  Please change table entry
		// DATABASE_CREATE_TABLE_SETTINGS
		// assume recipeinformation has format:  node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
		// for this methods let us read the old values into a List, change the element, and then send the list to saveNodIdsAndRecipeIdsByMonthYea
		// There are 3 cases:
		//      caseMeal = "new","update","delete"
		//      1) new recipe. add to list
		//      2) updated recipe.  remove old, add new
		//      3) delete recipe.  remove old
		List recipedates = new ArrayList();
		Cursor myCursor = mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'mealitems'",
				null, null, null, null, null);
		if (myCursor != null) {
			if (myCursor.getCount()==0) {
				// first time this may be called. so insert and return null string.
				recipedates.add(recipeinformation);
				System.out.println("*** Chef.BackEndSQLite.changeMeal inserting new recipeinformation = "+recipeinformation);
			} else {
				myCursor.moveToFirst();
				String temp = myCursor.getString((myCursor.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE)));
				System.out.println("*** Chef.BackEndSQLite.chengeMeal temp = "+temp);
				String nodeidTest = temp.split("%%%%")[0];
				String nodeidNew = recipeinformation.split("%%%%")[0];
				
				if (caseMeal.equalsIgnoreCase("new")){
					recipedates.add(recipeinformation);
					recipedates.add(temp);
				}
				if (caseMeal.equalsIgnoreCase("update")){
					// just don't add temp, only add recipeinformation since they are the same meal_nodeID
					recipedates.add(recipeinformation);
				}
				if (caseMeal.equalsIgnoreCase("delete")){
					if (nodeidTest.equalsIgnoreCase(nodeidNew)==true){
						// do nothing. i.e. do not att recipeinformation to recipedates
						recipedates.add(temp);
					}
				}
			}
		}
		myCursor.close();
		saveMealList(recipedates,userid);
	}
	
	private void saveMealList(List recipeDates, int userid) {
		// recipeDates is a list, where each item has the format:  node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
		// DATABASE_CREATE_TABLE_SETTINGS
		// only called with a complete list of meals (has old meals), or don't want repeats,  so first clear database:
		String sql = "DELETE FROM "+this.DATABASE_TABLE_SETTINGS+" WHERE "+this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'mealitems'";
		System.out.println("***** Chef BackEndSQLite saveMealList sql = " +sql);
		this.mDb.rawQuery(sql, null);
		
		// now add  meals
		// first recipe information, use insert
		ContentValues values = new ContentValues();
		Iterator myIt = recipeDates.iterator();
		while (myIt.hasNext()) {
			String value = (String) myIt.next();
			values.put(this.KEY_SETTINGSVALUE, value);
			values.put(this.KEY_USERID, userid);
			values.put(this.KEY_SETTIINGSKEY, "mealitems");
			System.out.println("*** Chef.BackEndSQLite.saveMealList INSERT value = "+value);
			long insertIDorError = mDb.insert(DATABASE_TABLE_SETTINGS, null, values);
			//the row ID of the newly inserted row, or -1 if an error occurred
			System.out.println("*** Chef.BackEndSQLite.saveMealList insert=true insertIDorError = "+insertIDorError);
		}
	}
	
	
	public List getAllMeals(int userid) {
		// called by Planner when webpage is down or userid<0.
		// just gets meals and returns them to planner
		List recipedates = new ArrayList();
		Cursor myCursor = mDb.query(true, DATABASE_TABLE_SETTINGS,
				new String[] { this.KEY_SETTINGSVALUE },
				this.KEY_USERID + "=" + userid + " AND " + this.KEY_SETTIINGSKEY + "= 'mealitems'",
				null, null, null, null, null);
		if (myCursor.getCount()!=0) {
			// put each item in recipedates
			System.out.println("***** Chef BackEndSQLite myCursor.getCount = "+myCursor.getCount());
			for (int i=0;i<myCursor.getCount();i++) {
				myCursor.moveToPosition(i);
				String item = myCursor.getString(myCursor.getColumnIndexOrThrow(BackEndSQLite.KEY_SETTINGSVALUE));
				System.out.println("***** Chef BackEndSQLite item = "+item);
				if (item.contains("%%%%")) {
					recipedates.add(item);
				}
			}
		}
		myCursor.close();
		return recipedates;
	}
	
	// create fields, objects, table create strings, etc...
	// create map for cuisines in cookbook
	public static final int OddsNEndsID = -10;
	Map<String, Integer> CuisinesInCookBook = new HashMap<String, Integer>();
	public static final String KEY_SEARCHSETTINGS = "searchsettings";
	public static final String KEY_ROWID_RECIPE = "_id";
	public static final String KEY_RECIPENAME = "recipename";
	public static final String KEY_RECIPEID = "recipeid";
	public static final String KEY_RECIPEUSERID = "recipeuserid"; // userid of chef who entered recipe
	public static final String KEY_CHEFIMAGEDOWNLOADED = "chefimagedownloaded";
	public static final String KEY_CHEFIMAGENAME = "chefimagename";
	public static final String KEY_CHEFNAME = "chefname";
	public static final String KEY_CUISINE = "cuisine";
	public static final String KEY_CATEGORY = "category";
	public static final String KEY_SERVES = "serves";
	public static final String KEY_PARTOFCOOKBOOK = "partofcookbook";
	public static final String KEY_PARTOFGROCERYLIST = "partofgrocerylist";
	public static final String KEY_STEPNUM = "stepnum";
	public static final String KEY_INSTRUCTIONS = "instructions";
	public static final String KEY_INGREDIENTNUMBER = "ingredientNumber";
	public static final String KEY_QUANTITY = "quantity";
	public static final String KEY_FRACTION = "fraction";
	public static final String KEY_UNIT = "unit";
	public static final String KEY_DESCRIPTION = "description";
	public static final String KEY_ITEM = "item";
	public static final String KEY_USERID = "userid";
	public static final String KEY_USERNAME = "username";
	public static final String KEY_PASSWORD = "password";
	public static final String KEY_MD5HASHINFO = "md5hashinfo";
	public static final String KEY_SETTIINGSKEY = "key";
	public static final String KEY_SETTINGSVALUE = "value";
	public static final String KEY_RATING = "rating";
	public static final String KEY_BOOKMARKED = "bookmarked";
	public static final int out_int_username = 0;
	public static final int out_int_password = 1;
	public static final int out_int_md5hashpass = 2;
	public static final int out_int_userid = 3;
	// public static final String KEY_PICTURENAME = "picturename";
	// public static final String KEY_PICTURERESOURCEIDINT =
	// "pictureresourceidint";
	public static final String KEY_CHANGED = "changed";
	// public static final String KEY_IMGNAME = "ImgName";
	public static final String KEY_IMAGEHTTP = "imagehttp";

	public static Integer TotalNumberRecipes = 0;

	private static final String TAG = "ChefDatabase";
	private DatabaseStarter mDbHelper;
	private SQLiteDatabase mDb;

	//
	 // INSTRUCTIONS and INGREDIENTS don't need a primary key. INGREDIENTS need
	 // qty, fraction, unit, and description as well as ingredientnumber. Doesn't
	 // need aisle, that can be determined dynamically. USER also doen't need a
	 // primary key. Needs to have a field for the md5 hash. SETTINGS should just
	 // be have a key and a value. There's over 20 of them, so one per row
	 // instead of one per column.
	 //

	private static final String DATABASE_NAME = "chef";
	private static final String DATABASE_TABLE_RECIPE = "chefrecipe";
	private static final String DATABASE_TABLE_INSTRUCTIONS = "chefinstructions";
	private static final String DATABASE_TABLE_INGREDIENTS = "chefingredients";
	// userid,username,password,md5hash
	private static final String DATABASE_TABLE_USER = "chefuserinfo";
	// key, value, userid
	private static final String DATABASE_TABLE_SETTINGS = "chefsettings";

	//
	 // from BJ: so to pull out the instructions you'll do SELECT description
	 // FROM instructions WHERE recipe_id=$ ORDER BY offset
	 //

	//
	 // Database creation sql statements
	 //
	private static final String DATABASE_CREATE_TABLE_RECIPE = "create table "
			+ DATABASE_TABLE_RECIPE + " (" + KEY_ROWID_RECIPE
			+ " integer primary key autoincrement, " + " " + KEY_RECIPENAME
			+ " text, " + KEY_RECIPEID + " integer, " + KEY_CHEFNAME
			+ " text, "+KEY_CUISINE+" text, " + " " + KEY_CATEGORY + " text, "
			+ KEY_SERVES + " integer, " + KEY_PARTOFCOOKBOOK + " integer, "
			+ " " + KEY_RATING + " real, " + KEY_IMAGEHTTP + " text,  " + " "
			+ KEY_DESCRIPTION + " text, " + KEY_CHANGED + " integer, " + " "
			+ KEY_RECIPEUSERID +" integer, "+KEY_CHEFIMAGEDOWNLOADED+" integer, "
			+ KEY_CHEFIMAGENAME+" text, "
			+ KEY_BOOKMARKED + " integer);";
	
	private static final String DATABASE_CREATE_TABLE_INSTRUCTIONS = " create table "
			+ DATABASE_TABLE_INSTRUCTIONS
			+ " ( "
			+ KEY_RECIPEID
			+ " integer , "
			+ " "
			+ KEY_STEPNUM
			+ " integer , "
			+ KEY_INSTRUCTIONS + " text )";
	// ingrednumber_number_fraction_unit_desc
	private static final String DATABASE_CREATE_TABLE_INGREDIENTS = " create table "
			+ DATABASE_TABLE_INGREDIENTS
			+ " ( "
			+ KEY_RECIPEID
			+ " integer not null, "
			+ " "
			+ KEY_INGREDIENTNUMBER
			+ " integer , "
			+ KEY_QUANTITY
			+ " text , "
			+ " "
			+ KEY_FRACTION
			+ " text , "
			+ KEY_UNIT
			+ " text , "
			+ " "
			+ KEY_ITEM
			+ " text , "
			+ KEY_PARTOFGROCERYLIST
			+ " integer, " + " " + KEY_RECIPENAME + " text)";
	private static final String DATABASE_CREATE_TABLE_USER = " create table "
			+ DATABASE_TABLE_USER + " ( " + KEY_USERID + " integer not null, "
			+ " " + KEY_USERNAME + " text not null, " + KEY_PASSWORD
			+ " text not null, " + " " + KEY_MD5HASHINFO + " text)";
	private static final String DATABASE_CREATE_TABLE_SETTINGS = "create table "
			+ DATABASE_TABLE_SETTINGS
			+ " ( "
			+ KEY_USERID
			+ "  integer not null, "
			+ KEY_SETTIINGSKEY
			+ " text not null, "
			+ KEY_SETTINGSVALUE + " text not null)";

	// version=8 has boolean for if in cookbook
	// version=9 has added rating value=number of stars/half stars. i.e. 3.5
	// version=10 has added picture name, picture resource id
	// version=11: changed recipeid to integer
	// version=12: added description, fixed ingredients for
	// "ingrednum_number_fraction_unit_desc"
	// version=13; added changed
	// version=15: added partofgrocerylist, version-14 had bad table
	// version=16: removed "not null" because some fields are not always used.
	// version=17: removed resource ID, remove picturename, insert bitmap image
	// name
	// v=18: using webview instead of sd card. need to store http image address
	// NOTE: the imagenameondisk is always the end of the httpimage address, so
	// dont need 2 entries
	// version=19: New Version of Chef/Application. Attempt to create new
	// database
	// version=20: added bookmark value in tableRECIPE
	//
	 // version=21: added recipename and partofgrocerylist(0/1 true/false)
	 // table_ing. and removed partofgrocerylist for table_recipe
	 //
	//
	 //  version=22: made table settings have setting/value like key/value pair.
	 //  for example usernae, setting="aislelist" value="misc::poultry::etc..."
	 //  this is like before, but has new version.
	 //
	// version=23: why not
	// version=24:  added KEY_RECIPEUSERID, added KEY_CHEFIMAGEDOWNLOADED
	// version=25: added KEY_CHEFIMAGENAME ="chefimagename"  ex:  picture-9058.png
	// version=26:  added the startingPage functions
	// version=27:  added functionality for OddsNEnds recipe.  used for user-added item in 
	//					grocerlist.  Also removed not null bc OddsNends only has ingredients 
	// 					and recipeID  = -10
	
	private static final int DATABASE_VERSION = 27;
	private final Context mCtx;
	public boolean isDatabaseOpen = false;
}
