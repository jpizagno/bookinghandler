package com.noblebug.chefpro.tools;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import com.noblebug.chefpro.R;
import android.content.Context;
import android.graphics.Paint;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListOfLists extends BaseAdapter {

	// this class is used to make a list with headers.
	// used for the grocery list.
	// headers = light grey color, (aisle, or recipe name)
	// section = item in list
	// 4 June 2011, Jim Pizagno

	private Adapter adapter;
	private Context mCtx;

	public ListOfLists(Context context, Map<String, Boolean> checkedlisttemp) {
		// constructor
		headers = new ArrayAdapter<String>(context, R.layout.list_header);
		checkedlistHERE = checkedlisttemp;
		mCtx = context;
	}

	public void addSection(String section, Adapter adapter) {
		// add section, "adapter" has the items to be added.
		this.adapter = adapter;
		this.headers.add(section);
		this.sections.put(section, adapter);
	}

	public Adapter getListOfListsAdapter() {
		return adapter;
	}

	public Object getItem(int position) {
		for (Object section : this.sections.keySet()) {
			Adapter adapter = sections.get(section);
			int size = adapter.getCount() + 1;

			// check if position inside this section
			if (position == 0)
				return null; // return section;
			if (position < size)
				return adapter.getItem(position - 1);

			// otherwise jump into next section
			position -= size;
		}
		return null;
	}

	public int getCount() {
		// total together all sections, plus one for each section header
		int total = 0;
		for (Adapter adapter : this.sections.values())
			total += adapter.getCount() + 1;
		return total;
	}

	public int getViewTypeCount() {
		// assume that headers count as one, then total all sections
		int total = 1;
		for (Adapter adapter : this.sections.values())
			total += adapter.getViewTypeCount();
		return total;
	}

	public int getItemViewType(int position) {
		int type = 1;
		for (Object section : this.sections.keySet()) {
			Adapter adapter = sections.get(section);
			int size = adapter.getCount() + 1;

			// check if position inside this section
			if (position == 0)
				return TYPE_SECTION_HEADER;
			if (position < size)
				return type + adapter.getItemViewType(position - 1);

			// otherwise jump into next section
			position -= size;
			type += adapter.getViewTypeCount();
		}
		return -1;
	}

	public boolean areAllItemsSelectable() {
		return false;
	}

	public boolean isEnabled(int position) {
		return (getItemViewType(position) != TYPE_SECTION_HEADER);
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		// here is where the magic happens.  it needs to figure out what was clicked on.
		// change the text if clicked.
		int sectionnum = 0;
		for (Object section : this.sections.keySet()) {
			Adapter adapter = sections.get(section);
			int size = adapter.getCount() + 1;
			
			// check if position inside this section
			if (position == 0) {
				return headers.getView(sectionnum, convertView, parent);
			}
			if (position < size) {
				View viewhere = adapter.getView(position-1, convertView, 	parent);

				TextView text = (TextView) viewhere.findViewById(R.id.list_item_title);
				text.setText((CharSequence) adapter.getItem(position-1));
				
				if (checkedlistHERE.containsKey(text.getText())){
					text.setPaintFlags(text.getPaintFlags()
							| Paint.STRIKE_THRU_TEXT_FLAG);
					// only do once at start up, and after reclicking. so empty
					// checkedlist.remove(key);
				}
				return viewhere;
			}

			// otherwise jump into next section
			position -= size;
			sectionnum++;
		}
		return null;
	}

	public Map<String, Adapter> getAllsectsions() {
		return sections;
	}

	public long getItemId(int position) { // id = position?
		return position;
	}

	// fields
	public final Map<String, Adapter> sections = new LinkedHashMap<String, Adapter>();
	public final ArrayAdapter<String> headers;
	public final static int TYPE_SECTION_HEADER = 0;
	static Map<String, Boolean> checkedlistHERE = new HashMap<String, Boolean>();

}
