package com.noblebug.chefpro.recipe;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import com.noblebug.chefpro.ChefController;
import com.noblebug.chefpro.Home;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.cookbook.Cookbook;
import com.noblebug.chefpro.cookbook.CookbookSelectorDisplay;
import com.noblebug.chefpro.grocerylist.GroceryList;
import com.noblebug.chefpro.grocerylist.GrocerylistDisplay;
import com.noblebug.chefpro.planner.MealEditor;
import com.noblebug.chefpro.planner.Planner;
import com.noblebug.chefpro.search.SearchDisplay;
import com.noblebug.chefpro.timers.TimersDisplay;
import com.noblebug.chefpro.tools.ImageHandler;
import com.noblebug.chefpro.tools.StarView;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.text.Editable;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RatingBar.OnRatingBarChangeListener;

public class RecipeDisplay extends Activity {
	private PowerManager.WakeLock wl;
	//
	 // This activity can be called from either the user/menu or after a search.
	 // when this class is called from the menu, then the recipe is already in
	 // database. when this class is called from the search reults, then the
	 // recipe is not in database and then class will get info from
	 // "RecipeStringFields".
	 // 
	 // 4 June 2011
	 //
	// called with activity is created
	private Context mCtx;
	
	public RecipeDisplay() {
		mCtx = this;
	}
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// attempt to disable sleep:
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		
		String[] outarr = mDbHelper.getUserSingle();
		userid = Integer.valueOf(outarr[BackEndSQLite.out_int_userid]);
		passwordmd5 = outarr[BackEndSQLite.out_int_md5hashpass];
		username = outarr[BackEndSQLite.out_int_username];
		try {
			//
			if(mDbHelper.getWakeLockState(String.valueOf(userid))) {
				PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
				wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
				Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
			}
		} catch (Exception e) {
			mDbHelper.setWakeLockInitial(String.valueOf(userid));
	        e.printStackTrace();
	    }
		
		// fix phone in POTRAIT (not landscape), and remove TITLE.
		this.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// try some system cleaning?
		System.gc();
		
		// get appstate. so we can update cookbook/grocerylist
		appState = ((ChefController) getApplicationContext());

		// see if this is a meal:
		if (getIntent().hasExtra("RecipeInformation")) {
			this.mealRecipeInformation = getIntent().getStringExtra("RecipeInformation");
			// recipe information format:  node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
			this.nodeid = Integer.valueOf(this.mealRecipeInformation.split("%%%%")[0]); 
		} else {
			this.mealRecipeInformation = "none";
			// recipe information format:  node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
			this.nodeid = -1; 
		}
		
		// get recipe. if no recipe exists
		recipeID = getIntent().getIntExtra("RecipeId2View", -1);
		if (recipeID != -1) {
			inDatabase = true;
			// Recipe is already saved on the phone in SQLite db
			// should already have bitmap image on SD card
			//mDbHelper = new BackEndSQLite(this);
			//mDbHelper.open();
			recipehere = mDbHelper.getRecipeByID(recipeID);
		} else {
			// being passed Recipe String from recipe search result
			String strout = getIntent().getStringExtra("RecipeStringFields");
			String[] array = strout.split("::");
			// separated by ::
			// recipehere.recipeid::recipehere.recipename::recipehere.rating::temprecipe.Imagehttp::
			// ::recipehere.chefname::recipehere.cuisine::recipehere.category::
			// ::recipehere.serves::recipehere.description::
			// ::recipe.NumIngredients::recipehere.ingredientsArray[]::
			// ::recipehere.NumInstructions::recipehere.instructionsArray[]
			// 
			recipehere = new Recipe();
			recipeID = Integer.valueOf(array[0].trim());
			recipehere.recipeid = recipeID;
			recipehere.recipename = array[1];
			recipehere.rating = Float.valueOf(array[2].trim()).floatValue();
			if (array[4].equalsIgnoreCase("null")) {
				recipehere.Imagehttp = null;
			} else {
				recipehere.Imagehttp = array[3];
				// CDATA in XML may have added quotes to beggining and end. so remove:
				String temp = recipehere.Imagehttp.replace("\"","");
				recipehere.Imagehttp=temp;
			}
			recipehere.chefname = array[4];
			recipehere.user = Integer.valueOf(array[5]);
			recipehere.cuisine = array[6];
			recipehere.category = array[7];
			recipehere.category.toLowerCase(); // categories in DB lower case
			String temp2 = recipehere.category.toLowerCase(); 
			recipehere.category = temp2;
			recipehere.serves = array[8];
			recipehere.description = array[9];
			recipehere.changed = Integer.valueOf(array[10]);
			recipehere.NumIngredients = Integer.valueOf(array[11].trim());
			String[] temp = new String[recipehere.NumIngredients];
			for (int i = 0; i < recipehere.NumIngredients; i++) {
				temp[i] = array[12 + i];
			}
			recipehere.ingredientsArray = temp;
			temp = null;
			recipehere.NumInstructions = Integer.valueOf(array[12 + recipehere.NumIngredients]);
			temp = new String[recipehere.NumInstructions];
			for (int i = 0; i < recipehere.NumInstructions; i++) {
				temp[i] = array[13 + recipehere.NumIngredients + i];
			}
			recipehere.instructionsArray = temp;
			temp = null;
		}

		// Create a LinearLayout in which to add the ImageView
		mLinearLayout = new LinearLayout(this);
		mLinearLayout.setOrientation(LinearLayout.VERTICAL);
		mLinearLayout.setBackgroundResource(R.drawable.grocerypaperbackground);
        
		// add title
		//Title myTitle = new Title(this,recipehere.recipename,this.getWindowManager().getDefaultDisplay().getHeight());
		//mLinearLayout.addView(myTitle);
		LinearLayout innerLayout = new LinearLayout(this);
		innerLayout.setGravity(Gravity.CENTER);
		innerLayout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.WRAP_CONTENT));
		TextView title = new TextView(this);
		title.setText(recipehere.recipename);
		title.setTextColor(Color.WHITE);
		title.setBackgroundResource(R.drawable.blanktitle);
		title.setGravity(Gravity.CENTER);
		Typeface myType = Typeface.create(Typeface.SERIF, Typeface.NORMAL);
		title.setTypeface(myType);
		if (this.getWindowManager().getDefaultDisplay().getHeight() > 600) {  
			// this If()else statement accounts for devices with different sizes
			title.setTextSize(36);
		} else {
			title.setTextSize(18);
		}
		innerLayout.addView(title, this.getWindowManager().getDefaultDisplay().getWidth(), 
				this.getWindowManager().getDefaultDisplay().getHeight()*10/100);
		mLinearLayout.addView(innerLayout);

		// add division bar:
		ImageView myDivisionLine = new ImageView(this);
		myDivisionLine.setImageResource(R.drawable.recipedivline);
		myDivisionLine.setPadding(5, 5, 5, 5);
		mLinearLayout.addView(myDivisionLine);
		
		
		// get drawable_image for webview_image for description
		ImageView image = null;
		WebView recipeWebview = null;
		int webviewwidth=50;
		int webviewheight=50;
		boolean isDefaultImage;
		if (inDatabase == true) { // in DB
			// Instantiate an ImageView and define its properties
			if (recipehere.PictureNameOnDisk == null) {
				// recipe might not have a picture
				image = new ImageView(this);
				image.setImageResource(R.drawable.defaultrecipeimage);			
				isDefaultImage = true;
			} else {
				if (recipehere.PictureNameOnDisk.length()==0) {
					// somehow recipe can be notnull but not have length.  this is problably
					// an error with downloading bookmarked recipes after user logs in.
					image = new ImageView(this);
					image.setImageResource(R.drawable.defaultrecipeimage);			
					isDefaultImage = true;
				} else {
					// load image from disk
					ImageHandler myImgHandler = new ImageHandler();
					//System.out.println("******* RecipeDisplay recipehere.PictureNameOnDisk = "+recipehere.PictureNameOnDisk);
					Drawable myDrawable = myImgHandler.getimageDrawable(recipehere.PictureNameOnDisk);
					image = new ImageView(this);
					image.setImageDrawable(myDrawable);
					isDefaultImage = false;
				}
			}
		} else {
			// this case is for viewing result of recipe search,
			// might need to display image but not in databse.
			// add image to webview if imagehttp is not null
			if(recipehere.Imagehttp.length()<5) {
				recipehere.Imagehttp=null;
				recipehere.PictureNameOnDisk = null;
				// not in database, and doesnt have image.
				image = new ImageView(this);
				image.setImageResource(R.drawable.defaultrecipeimage);
				isDefaultImage = true;
			} else {
				isDefaultImage = false;
				recipeWebview = new WebView(this);
				Display display = getWindowManager().getDefaultDisplay();
				//float scaleFloat = (float) ((80.0/854.0)* (float)display.getHeight());
				int webviewScalePerc = 100;; //= (int) scaleFloat;  //must be between 0-100. percentage
				//if (scaleFloat>100) {
				//	webviewScalePerc = (int) 100;  //must be between 0-100. percentage
				//} else {
				//	webviewScalePerc = (int) scaleFloat;  //must be between 0-100. percentage
				//}
				recipeWebview.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
				
				recipeWebview.setInitialScale(webviewScalePerc);
				webviewwidth = this.getWindowManager().getDefaultDisplay().getWidth() * 40/100;
				webviewheight = this.getWindowManager().getDefaultDisplay().getHeight() * 17/100;
				String url =" <img src=\""+recipehere.Imagehttp
				+"\" width=\""+String.valueOf(webviewwidth)+"\" height=\""
				+String.valueOf(webviewheight)+"\" >";
				String encoding = "utf-8";
				String mimeType = "image/jpeg";
				recipeWebview.loadData(url, mimeType, encoding);
				recipeWebview.setHorizontalScrollBarEnabled(false);
				recipeWebview.setVerticalScrollBarEnabled(false);
				recipeWebview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
				recipeWebview.setClickable(false);
				recipeWebview.setFocusable(false);
				recipeWebview.setPadding(-10, -10, -10, -10);
			}
		}
		
		// add description
		Description myDescription = null;
		if (image!=null) {
			myDescription = new Description(this, recipehere.chefname, recipehere.rating, 
					recipehere.cuisine, recipehere.category, image, 
					this.getWindowManager().getDefaultDisplay().getHeight(), isDefaultImage,
					this.getWindowManager().getDefaultDisplay().getWidth(),
					this.getWindowManager().getDefaultDisplay().getHeight());
		} else {
			// use webview bc image is not on disk. used after SearchResultsDisplay.java
			myDescription = new Description(this, recipehere.chefname, recipehere.rating, 
					recipehere.cuisine, recipehere.category, recipeWebview,
					this.getWindowManager().getDefaultDisplay().getHeight(),webviewwidth,webviewheight);
		}
		mLinearLayout.addView(myDescription);
		
		// add division bar:
		ImageView myDivisionLine2 = new ImageView(this);
		myDivisionLine2.setImageResource(R.drawable.recipedivline);
		myDivisionLine2.setPadding(5, 5, 5, 5);
		mLinearLayout.addView(myDivisionLine2);
		
		// add ingredients:
		Ingredients myIngredients = new Ingredients(this, recipehere.ingredientsArray);
		mLinearLayout.addView(myIngredients);
		
		// add division bar:
		ImageView myDivisionLine35 = new ImageView(this);
		myDivisionLine35.setImageResource(R.drawable.recipedivline);
		myDivisionLine35.setPadding(5, 5, 5, 5);
		mLinearLayout.addView(myDivisionLine35);
		
		if (recipehere.description.length()>0) {
			// add User description:
			TextView userDescriptionTitle = new TextView(this);
			userDescriptionTitle.setText("Description:");
			userDescriptionTitle.setTypeface(null,Typeface.ITALIC);
			userDescriptionTitle.setTextColor(Color.rgb(66, 41, 10));
			mLinearLayout.addView(userDescriptionTitle);
			TextView userDescription = new TextView(this);
			userDescription.setText(recipehere.description);
			userDescription.setTextColor(Color.rgb(66, 41, 10));
			mLinearLayout.addView(userDescription);
			
			// add division bar:
			ImageView myDivisionLine3 = new ImageView(this);
			myDivisionLine3.setImageResource(R.drawable.recipedivline);
			myDivisionLine3.setPadding(5, 5, 5, 5);
			mLinearLayout.addView(myDivisionLine3);
		}
		
		// add steps:
		instructionsArray = new String[recipehere.NumInstructions];
		instructionsArray = recipehere.instructionsArray;
		for (int m = 0; m < recipehere.NumInstructions; m++) {
			//System.out.println("in " + instructionsArray[m]);
			Step myStep = new Step(this,"Step "+String.valueOf(m+1),instructionsArray[m]);
			myStep.setPadding(0, 8, 0, 2);
			mLinearLayout.addView(myStep);
		}
	
		
		// create scroller view
		ScrollView scroller = new ScrollView(this);
		scroller.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		scroller.setScrollbarFadingEnabled(true);
		scroller.setBackgroundResource(R.drawable.grocerypaperbackground);
		// put linearlayout in scroller view
		scroller.addView(mLinearLayout);
		// Add the scroller (with mLinearLayout inside) to Activity
		setContentView(scroller);
		
		mDbHelper.close();
	}
	
	   private class Description extends LinearLayout {
	    	// displays Chef,Rating,Cuisine,Category,Image
			Context innercontext;
			LinearLayout innerlayout;

			public Description(Context innercontext, String chef, float rating, 
					String Cuisine, String Category, ImageView Image, Integer displayHeight, 
					boolean isDefaultimage, Integer screenWidth, Integer screenHeight) {
				super(innercontext);
				innerlayout = new LinearLayout(innercontext);
				innerlayout.setOrientation(LinearLayout.HORIZONTAL);
				innerlayout.setGravity(Gravity.CENTER_VERTICAL);
			
				// add descriptiontexts
				DescriptionTexts myTexts = new DescriptionTexts(innercontext,chef,rating, 
						Cuisine, Category, displayHeight, screenWidth);
				innerlayout.addView(myTexts);
				
				// add image
				// left, top, right, bottom
				Image.setPadding(5, 5, 5, 5);
				Image.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
				//innerlayout.addView(Image);
				Integer width = screenWidth/2;
				Integer height = screenHeight/4;
				innerlayout.addView(Image, width, height);
				
				addView(innerlayout);
			}

			public Description(RecipeDisplay innercontext2, String chefname,
					float rating, String cuisine, String category,
					WebView recipeWebview, Integer displayHeight, int webviewwidth, int webviewheight) {
				// for webview
				super(innercontext2);
				innerlayout = new LinearLayout(innercontext2);
				innerlayout.setOrientation(LinearLayout.HORIZONTAL);
				
				// add descriptiontexts
				DescriptionTexts myTexts = new DescriptionTexts(innercontext2,chefname,rating, 
						cuisine, category, displayHeight, innercontext2.getWindowManager().getDefaultDisplay().getWidth());
				innerlayout.addView(myTexts);
				
				LinearLayout innerlayout2 = new LinearLayout(innercontext2);
				innerlayout2.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
						LayoutParams.FILL_PARENT));
				innerlayout2.addView(recipeWebview);
				//recipeWebview.setPadding(-10, -10, -10, -10);
				//innerlayout2.setPadding(-20, -20, 0, 0);
				innerlayout.addView(innerlayout2,webviewwidth,webviewheight);
				
				addView(innerlayout);
			}
	    }
	    
	    private class DescriptionTexts extends LinearLayout {
			Context innercontext;
			LinearLayout innerlayout;
	    	public DescriptionTexts(Context innercontext, String chef, float rating, 
					String Cuisine, String Category, Integer displayHeight, int displayWidth){
	    		super(innercontext);
	    		innerlayout = new LinearLayout(innercontext);
				innerlayout.setOrientation(LinearLayout.VERTICAL);
				innerlayout.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
				
				// add chef
				ClearBrownText cheftext = new ClearBrownText(innercontext,"Chef:  ",chef);
				innerlayout.addView(cheftext);
				
				// add rating
				StarView myRating = new StarView(innercontext, rating, null, displayWidth);
				ClearBrownText ratingtext = new ClearBrownText(innercontext,"Rating:  ",myRating, displayHeight);
				innerlayout.addView(ratingtext);
				
				// add Cuisine
				ClearBrownText cuisinetext = new ClearBrownText(innercontext,"Cuisine:  ",Cuisine);
				innerlayout.addView(cuisinetext);
				
				// add Category
				ClearBrownText categorytext = new ClearBrownText(innercontext,"Category:  ",Category);
				innerlayout.addView(categorytext);
				
				addView(innerlayout);
	    	}
	    }
	    
	    private class ClearBrownText extends LinearLayout {
	    	// displays a clear: brown text. i.e: Chef:  jpizagno
			Context innercontext;
			LinearLayout innerlayout;
			public ClearBrownText(Context innercontext, String category, String field) {
				super(innercontext);
				innerlayout = new LinearLayout(innercontext);
				innerlayout.setOrientation(LinearLayout.HORIZONTAL);
				innerlayout.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));

				TextView myTitle = new TextView(innercontext);
				myTitle.setText(category);
				myTitle.setGravity(Gravity.LEFT);
				myTitle.setTextColor(Color.rgb(66, 41, 10));
				//myTitle.setTextSize(20);
				myTitle.setTypeface(Typeface.SERIF,Typeface.ITALIC);
				myTitle.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
				innerlayout.addView(myTitle);
				
				// set field
				TextView myField = new TextView(innercontext);
				myField.setText(field);
				myField.setGravity(Gravity.CENTER);
				myField.setTextColor(Color.rgb(66, 41, 10));
				//myField.setTextSize(20);
				myField.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
				innerlayout.addView(myField);
				
				addView(innerlayout);
			}
			
			// overloaded second constructor for StarView
			public ClearBrownText(Context innercontext, String category, 
					StarView myRating, Integer screenHeight) {
				super(innercontext);
				innerlayout = new LinearLayout(innercontext);
				innerlayout.setOrientation(LinearLayout.HORIZONTAL);

				// set category
				TextView myTitle = new TextView(innercontext);
				myTitle.setText(category);
				myTitle.setGravity(Gravity.LEFT);
				myTitle.setTextColor(Color.rgb(66, 41, 10));
				myTitle.setTypeface(Typeface.SERIF,Typeface.ITALIC);
				innerlayout.addView(myTitle);
				
				// add stars
				int bottomPadding = -1 * screenHeight * 7/100;
				myRating.setPadding(0, 5, 0, bottomPadding);
				innerlayout.addView(myRating);
				
				addView(innerlayout);
			}
	    }
	    
	
    private class Title extends LinearLayout {
    	// WARNING ERROR:  AS of 4 June 2013 this class may be obsolete....
    	// displays "Recipe Bar" and title "Sour Cream Biscuits"
		Context innercontext;
		LinearLayout innerlayout;

		public Title(Context innercontext, String title, Integer screenHeight) {
			super(innercontext);
			innerlayout = new LinearLayout(innercontext);
			innerlayout.setOrientation(LinearLayout.VERTICAL);
			// add bar:
			ImageView recipeBarTitle = new ImageView(innercontext);
			recipeBarTitle.setImageResource(R.drawable.recipebar);
			//set padding as a scale relative to the screenheight
			int padding = -1 * screenHeight * 7 / 100;
			recipeBarTitle.setPadding(0, padding, 0, padding);
			innerlayout.addView(recipeBarTitle);
			
			// set text
			TextView myTitle = new TextView(innercontext);
			myTitle.setText(title);
			myTitle.setGravity(Gravity.CENTER);
			myTitle.setTypeface(Typeface.SERIF);
			myTitle.setTextColor(Color.rgb(66, 41, 10));
			myTitle.setTextSize(30);
			innerlayout.addView(myTitle);
			
			addView(innerlayout);
		}
    }
    
    private class Ingredients extends LinearLayout {
    	// displays ingredients
		Context innercontext;
		LinearLayout innerlayout;

		public Ingredients(Context innercontext, String[] ingredientsarray) {
			super(innercontext);
			innerlayout = new LinearLayout(innercontext);
			innerlayout.setOrientation(LinearLayout.VERTICAL);
			
			// addTitle
			TextView title = new TextView(innercontext);
			title.setText("Ingredients:");
			title.setTextColor(Color.rgb(66, 41, 10));
			title.setTypeface(null, Typeface.BOLD);
			title.setTypeface(null,Typeface.ITALIC);
			innerlayout.addView(title);
			
			for (int m=0;m<ingredientsarray.length;m++) {
				// ingrednumber_number_fraction_unit_desc
				String[] temp = ingredientsarray[m].split("_");
				String input = "";
				for (int i=1;i<temp.length;i++){
					//System.out.println("RecipeDisplay::Indredients temp[i] = "+temp[i]);
					if (i==3) {
						input = input + temp[i]+" 8AAAAAAAA "; // need , for brownlightbrowntext
					} else {
						input = input + temp[i]+" ";
					}
				}
				//System.out.println("RecipeDisplay::Indredients input = "+input);
				input = input.replace("null", "");
				BrownLightBrownText ingredient =  
					new BrownLightBrownText(innercontext,input);
				innerlayout.addView(ingredient);
			}
			addView(innerlayout);
		}
    }
    
    private class BrownLightBrownText extends LinearLayout {
    	Context innercontext;
		LinearLayout innerlayout;
    	public BrownLightBrownText(Context innercontext, String title){
    		super(innercontext);
    		innerlayout = new LinearLayout(innercontext);
			innerlayout.setOrientation(LinearLayout.HORIZONTAL);
			
			//System.out.println("***** RecipeDisplay::BrownLightBrownText title = "+title);
			
			// Text View
			TextView text1 = new TextView(innercontext);
			String test = title.split("8AAAAAAAA")[0].trim();
			//System.out.println("***** RecipeDisplay::BrownLightBrownText test = "+test+" length="+String.valueOf(test.length()));
			if(test.length()>0) {  // I had here if(test.length()>3){ but that didn't work. maybe 3 was a typo.
				text1.setText(test+", ");
				text1.setTextColor(Color.rgb(66, 41, 10));
				text1.setTypeface(null, Typeface.BOLD);
				innerlayout.addView(text1);
			}
			
			// Text View
			//System.out.println("***** RecipeDisplay::BrownLightBrownText title.split(8AAAAAAAA)[1] = "+title.split("8AAAAAAAA")[1]);
			TextView text2 = new TextView(innercontext);
			text2.setText(title.split("8AAAAAAAA")[1]);
			text2.setTextColor(Color.rgb(66, 41, 10));
			innerlayout.addView(text2);
			
			addView(innerlayout);
    	}
    }
    
    private class Step extends LinearLayout {
    	// displays ingredients
		Context innercontext;
		LinearLayout innerlayout;

		public Step(Context innercontext, String steptitle, String stepinstructions) {
			super(innercontext);
			innerlayout = new LinearLayout(innercontext);
			innerlayout.setOrientation(LinearLayout.VERTICAL);
			innerlayout.setLayoutParams(
					new LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
							LinearLayout.LayoutParams.WRAP_CONTENT));
			
			// add step image
			ImageView stepbar = new ImageView(innercontext);
			stepbar.setImageResource(R.drawable.recipebackgroundverysmall);
			stepbar.setPadding(0, 0, 0, 0);
			innerlayout.addView(stepbar);
			
	
			int bottom = this.getBottom();
			int top = this.getTop();
			int height = this.getHeight();
			
			StepTitleView myTitle = new StepTitleView(innercontext,steptitle);
			myTitle.setPadding(0, 10, 0, 10);
			innerlayout.addView(myTitle);
			
			TextView instructions = new TextView(innercontext);  //this.getContext());
			instructions.setText(stepinstructions);
			instructions.setTextColor(Color.rgb(66, 41, 10));
			innerlayout.addView(instructions);	
			
			addView(innerlayout);
		}
    }
    
	private class StepTitleView extends View {
		String stepnum;
		private Paint painttext;
		BitmapDrawable myDrawable2;
		Integer width;
		Integer height;
		
		public StepTitleView(Context innercontext, String stepnumt) {
			super(innercontext);
			Display display = getWindowManager().getDefaultDisplay();
			width = display.getWidth();
			height =  display.getHeight()/15;
			stepnum = stepnumt;
			painttext = new Paint();
			painttext.setColor(Color.rgb(66, 41, 10));
			// setTextSize(36) worked for 850
			painttext.setTextSize(display.getHeight()*5/100);
			Typeface myType = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC);
			painttext.setTypeface(myType);
			painttext.setAntiAlias(true);
			this.setBackgroundResource(R.drawable.recipestep);
		}
		
		protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			// draw the text
			canvas.drawText(stepnum, 10, height * 3/4, painttext);
		}
	   	// set dimensions here
       	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    		this.setMeasuredDimension(width, height);
    	} 
	}
    
	
	@Override
	protected void onStop() {
		super.onStop();
		// add something here if needed
		if (mDbHelper != null) {
			mDbHelper.close();
		}
	}

	// create menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		//menu.add(0, Add2GroceryList_ID, 0, R.string.menu_add2groceryList);
		if (this.inDatabase==false) {
			menu.add(0, Add2Cookbook_ID, 0, R.string.menu_add2cookbook);
		} else {
			// gorcery list part of wepage:
			menu.add(0, this.DeleteRecipe_ID, 0, R.string.menu_deleterecipe);
			menu.add(0, Add2GroceryList_ID, 0, R.string.menu_add2groceryList);
			menu.add(0, EmailRecipe_ID, 0, "Share Recipe");
			menu.add(0, RateRecipe_ID, 0, R.string.menu_raterecipe);
			menu.add(0, UpdateRecipe_ID, 0, "Add Recipe to Calendar"); // updatemeal.php
			menu.add(0, DelecteRecipe_ID, 0, "remove recipe from Calendar"); // deletemeal.php */
			
		}
		Drawable cookbook = this.getResources().getDrawable(R.drawable.cookbookbutton);
		menu.add(0, Cookbook_ID, 0, "Cookbook").setIcon(cookbook);
		Drawable grocerylist = this.getResources().getDrawable(R.drawable.grocerylistbutton);
		menu.add(0, Grocerylist_ID, 0, "Grocery List").setIcon(grocerylist);
		Drawable search = this.getResources().getDrawable(R.drawable.searchbutton);
		menu.add(0, Search_ID, 0, "Search").setIcon(search);
		Drawable timers = this.getResources().getDrawable(R.drawable.timersbutton);
		menu.add(0, Timers_ID, 0, "Timers").setIcon(timers);
		Drawable home = this.getResources().getDrawable(R.drawable.homebutton);
		menu.add(0, Chef_ID, 0, "Home").setIcon(home);
		menu.add(0, Contact_ID, 0, "Contact Us");
		
		if ( userid > -1) {
			// only add Planner when user is logged in
			Drawable mealplanner = this.getResources().getDrawable(R.drawable.mealplanner);
			menu.add(0, Planner_ID, 0, "Meal Planner").setIcon(mealplanner);;
		}
		
		return true;
	}

	// create menu listener
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case UpdateRecipe_ID: // updatemeal.php
			updateRecipeCalendar();
			return true;
		case DelecteRecipe_ID: // delete recipe from Calendar
			deleteRecipeFromCalendar();
			return true;
		case Contact_ID:
			contact_us();
			return true;
		case Add2GroceryList_ID:
			Add2GroceryList();
			return true;
		case Add2Cookbook_ID:
			Add2Cookbook();
			return true;
		case EmailRecipe_ID:
			EmailRecipe();
			return true;
		case RateRecipe_ID:
			RateRecipe(this.userid, this.recipeID, this.passwordmd5);
			return true;
		case DeleteRecipe_ID:
			DeleteRecipe();
			return true;
		case Cookbook_ID:
			this.createCookbook();
			return true;
		case Grocerylist_ID:
			this.createGroceryList();
			return true;
		case Search_ID:
			this.createSearch();
			return true;
		case Timers_ID:
			this.createTimers();
			return true;
		case Chef_ID:
			this.gotoChef();
			return true;
		case Planner_ID:
			goto_planner();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}
	
	private void goto_planner() {
		Intent i = new Intent(this, Planner.class);
		startActivity(i);
	}
	
	public void deleteRecipeFromCalendar() {
		// delete meal from webpage/php and phone/sqlitedb
		// send to server:
		BackEndPHPHandler myPHP = new BackEndPHPHandler();
		myPHP.deleteRecipeFromCalendar(this.userid,this.passwordmd5,this.nodeid);
		// fix DB backend
		mDbHelper.open();
		mDbHelper.manageMeals(this.mealRecipeInformation, this.userid, "delete");
		mDbHelper.close();
	}
	
	private void createMealEditor(String recipeinformaiton) {
		Intent i = new Intent(this, MealEditor.class);
		i.setType("text/plain");
		i.putExtra("recipeinformation",recipeinformaiton);
		startActivity(i);
	}
	
	public void updateRecipeCalendar() {
		// Add meal to your calendar so get day/type.  
		// For the calendar:   updatemeal takes: user, password, nid, recipenid, type, and date.  
		//   If you're creating a meal pass -1 as the nid.  The date is a string with the format YYYY-MM-DD.  
		//    Type is a string that is Breakfast, Brunch, Lunch, Dinner.
		
		//format for recipeInformation:  // 36424^^18678^^Chicken & Broccoli Casserole or (Make your own casserole)^^Dinner^^2012-07-12
		//      						node-in=nid %%%% recipid %%%% name %%%% type(dinner,lunch,etc) %%%% year-month-day
		Calendar _calendar = Calendar.getInstance(Locale.getDefault());
		int month = _calendar.get(Calendar.MONTH)+ 1;
		int year = _calendar.get(Calendar.YEAR);
		int day = _calendar.get(Calendar.DAY_OF_MONTH);
		String recipeInformation = "-1%%%%"+recipeID+"%%%%"+recipehere.recipename+"%%%%Dinner"+"%%%%"+year+"-"+month+"-"+day;
		createMealEditor(recipeInformation);
		
		/*
		// create, for now, simple 
		LinearLayout myInnerLayout = new LinearLayout(this.Ctx);
		myInnerLayout.setOrientation(LinearLayout.VERTICAL);
		final EditText dayText = new EditText(this.Ctx);
		dayText.setHint("Day (Number i.e. 20)");
		myInnerLayout.addView(dayText);
		final EditText monthText = new EditText(this.Ctx);
		monthText.setHint("Month (Number i.e. 10)");
		myInnerLayout.addView(monthText);
		final EditText yearText = new EditText(this.Ctx);
		yearText.setHint("Year (Number i.e. 2012)");
		myInnerLayout.addView(yearText);
		final EditText typeText = new EditText(this.Ctx);
		typeText.setHint("Type (Breakfast, Brunch, Lunch, Dinner)");
		myInnerLayout.addView(typeText);
		
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Enter Date & Type");
		builder.setView(myInnerLayout); // give ratingbar to AlertDiablog builder
		AlertDialog alert = builder.create();
		
		// add button to rate recipe
		alert.setButton2("Okay",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						String type = typeText.getText().toString().trim();
						String DD = dayText.getText().toString().trim();
						if (DD.length()<2){
							DD = "0"+DD;
						}
						String MM = monthText.getText().toString().trim();
						if (MM.length()<2) {
							MM = "0"+MM;
						}
						String YYYY = yearText.getText().toString().trim();
						String YYYYMMDD =  YYYY+"-"+MM+"-"+DD;
						BackEndPHPHandler myPHP = new BackEndPHPHandler();
						
						int nid = -1; // If you're creating a meal pass -1 as the nid.
						
						myPHP.addRecipe2Calendar(userid, passwordmd5, nid, recipehere.recipeid, type,YYYYMMDD, username);
					}
				});
		alert.show();
		*/
	}
	
	/*
	public void deleteRecipeCalendar(){
		// removes meal from calendar:
		// deletemeal.php takes a user, password, and index.
		
		BackEndPHPHandler myPHP = new BackEndPHPHandler();
		myPHP.deleteRecipeFromCalendar(this.userid, this.passwordmd5,recipehere.recipeid);
		
		// remove recipe from DB:
		mDbHelper.open();
		mDbHelper.removeMeal(recipeNode);   // want these to be peristen.
		mDbHelper.close();
	}
	*/

	private void gotoChef() {
		if (mDbHelper != null) {
			mDbHelper.close();
		}
		Intent i = new Intent(this, Home.class);
		startActivity(i);
	}

	private void createTimers() {
		if (mDbHelper != null) {
			mDbHelper.close();
		}
		// goto timers
		Intent i = new Intent(this, TimersDisplay.class);
		// Intent i = new Intent(this, ChefCountdownTimer.class);
		startActivity(i);
	}

	private void createSearch() {
		if (mDbHelper != null) {
			mDbHelper.close();
		}
		Intent i_search = new Intent(this, SearchDisplay.class);
		startActivity(i_search);
	}

	private void createGroceryList() {
		if (mDbHelper != null) {
			mDbHelper.close();
		}
		// save state
		Intent i_grocerylist = new Intent(this, GrocerylistDisplay.class);
		startActivityForResult(i_grocerylist, 0);
	}

	private void createCookbook() {
		if (mDbHelper != null) {
			mDbHelper.close();
		}
		Intent i_cookbook = new Intent(this, CookbookSelectorDisplay.class);
		//i_cookbook.putExtra("cookbookState","chefs");
		startActivity(i_cookbook);
	}

	private void DeleteRecipe() {
		BackEndSQLite mDbHelper;
		mDbHelper = new BackEndSQLite(this);
		mDbHelper.open();
		mDbHelper.deleteRecipe(recipehere.recipeid);// deletes recipe from database, delete before syncing to web
		String[] outarr2 = mDbHelper.getUserSingle();
		int UserID = Integer.valueOf(outarr2[BackEndSQLite.out_int_userid]);
		String username = outarr2[BackEndSQLite.out_int_username];
		String md5password = outarr2[BackEndSQLite.out_int_md5hashpass];
		if (UserID>0 || username.equalsIgnoreCase("newUser")==false) {
			// if user is logged in, then delete recipe from webpage:  
			BackEndPHPHandler myPHP3 = new BackEndPHPHandler();
			if (UserID==recipehere.user){  //BJ says match on userid not username
				// from BJ:  If it's YOUR recipe then call deleterecipe.php with index and password parameters. 
				myPHP3.deleteRecipe(recipehere.recipeid,md5password,UserID);
			} else {
				//	           If it's a bookmark then call bookmarkstoweb.php.
				List<Integer> recipeIDs_bookmarked = mDbHelper.getAllRecipesNotThisUser(UserID);
				if (recipeIDs_bookmarked.size()==0) {
					// still may need to delete current recipe. database deleted it.
					// this is a problem for the case when there is a single recipeid left.
					// DB deletes it. by how to tell the website to clear the recipes.
					recipeIDs_bookmarked.add(0);
				} 
				myPHP3.bookmarkstoweb(UserID,recipeIDs_bookmarked,md5password);
			}
		} //esle user not logged in. so do nothing with webpage
		mDbHelper.close();
		reCreateObjectsReDisplayCookbook();
		return;
	}

	private void reCreateObjectsReDisplayCookbook() {
		mDbHelper.close();
		appState.createObjects(this);
		Intent myIntent = new Intent(this, CookbookSelectorDisplay.class);
		startActivity(myIntent);
	}
	
	private void RateRecipe(final int userid, final int recipeID, final String passwordmd5) {
		// add my rating to this recipe
		if (userid==-1) {
			Toast.makeText(Ctx, "Please Login to rate recipes", Toast.LENGTH_SHORT).show();
		} else { 
			// build rating bar.. just stars
			final RatingBar ratingbar = new RatingBar(this);
			
			ratingbar.setNumStars(5);
		
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("RateRecipe");
			builder.setView(ratingbar); // give ratingbar to AlertDiablog builder
			AlertDialog alert = builder.create();
			
			// add button to rate recipe
			alert.setButton2("Okay",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int whichButton) {
							int rating = (int) ratingbar.getRating();
							BackEndPHPHandler myPHP = new BackEndPHPHandler();
							//int userid, int recipeid, String password, int vote
							myPHP.rateRecipe(userid,username,recipeID,passwordmd5,rating);
							if (myPHP.rateReciperesult.equalsIgnoreCase("Done")) {
								Toast.makeText(Ctx, "New Rating: " + String.valueOf(rating), Toast.LENGTH_SHORT).show();
							} 
							//Toast.makeText(Ctx, "from web:  "+myPHP.rateReciperesult, Toast.LENGTH_SHORT).show();
							//System.out.println("RecipeDisplay::RateRecipe:: myPhP.rateReciperesult = "+myPHP.rateReciperesult);
							//rateRecipePHP(rating);
						}
					});
			alert.show();
		}
		
		//ratingbar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
		//   public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
		//        Toast.makeText(Ctx, "New Rating: " + String.valueOf(rating), Toast.LENGTH_SHORT).show();
		//    }
		//});
	}

	private void contact_us() {
		// email any comments about this activity to chefslittlehelper@gmail.com.  just a way for 
		// users to provide feedback.
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"chefslittlehelper@gmail.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A comment about Chef activity RecipeDisplay");
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void EmailRecipe() {
		// email recipe
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("text/plain");
		//i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"recipient@example.com"});
		i.putExtra(Intent.EXTRA_SUBJECT, "A Chef recipe called "+recipehere.recipename);
		String body ="Here is a recipe from www.chefslittlehelper.com titled: \n "+recipehere.recipename+". \n";
		body = body + "\n";
		if (recipehere.description.length()>0) {
			body = body + "The recipe's description:  \n "+recipehere.description+" \n";
			body = body + "\n";
		}
		if (recipehere.ingredientsArray.length>0){
			body = body +"Here are the ingredients: \n";
			for (int m=0;m<recipehere.ingredientsArray.length;m++){
				body = body + recipehere.ingredientsArray[m].split("_")[4]+" \n";
			}
		}
		body = body+"\n";
		body = body + "For more information, here is a link: \n http://www.chefslittlehelper.com/node/"+String.valueOf(recipehere.recipeid)+"\n";
		i.putExtra(Intent.EXTRA_TEXT   , body);
		
		try {
		    startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
		    Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
		}
	}

	private void Add2Cookbook() {
		// add the recipe to cookbook
		if (inDatabase != true) {
			recipehere.partofcookbook = 0;
			if (recipehere.Imagehttp==null || recipehere.Imagehttp.equalsIgnoreCase("null")) {  
				// no image with this recipe, dont download.
				recipehere.PictureNameOnDisk=null;
				recipehere.Imagehttp=null;
			} else {
				if (recipehere.PictureNameOnDisk==null) {
					// download file
					if (appState.internetConnectionOpen==true) {
						ImageHandler myImgHandler = new ImageHandler();
						myImgHandler.downloadFile(recipehere.Imagehttp);
						recipehere.PictureNameOnDisk = myImgHandler.imagename;
					} else {
						Toast.makeText(getBaseContext(), "This device may not be connected to the internet",
								Toast.LENGTH_SHORT).show();
					}
				}
			}
			// get chef image if needed:
			// cannot check if a particular recipe has its chefimagedownloaded because
			// one chef can have multiple recipes.  so check database for recipes that have
			// that chef AND have it downloaded:
			BackEndSQLite mDbHelper;
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			if(mDbHelper.chefImageDownaloded(recipehere.chefname)==false) {
				// chef image not downloaded so downloaded.
				if (appState.internetConnectionOpen==true) {
					ImageHandler myImgHandler = new ImageHandler();
					//String urlString = "http://www.chefslittlehelper.com/sites/default/files/pictures/picture-???.jpg";
					//urlString = urlString.replace("???", String.valueOf(recipehere.user));
					String answer=myImgHandler.downloadChefImage(recipehere.user);
					if (answer.equals("None")) {
						// no image
						recipehere.chefimagedownloaded=1;
						recipehere.chefimagename="None";
					} else {
						recipehere.chefimagedownloaded=0;
						recipehere.chefimagename = answer;
					}
				} else {
					// no open connection
					Toast.makeText(getBaseContext(), "This device may not be connected to the internet",
							Toast.LENGTH_SHORT).show();
					recipehere.chefimagedownloaded=1;
				}
			} else {
				recipehere.chefimagedownloaded=0;
			}
			// add recipe to the cookbook/database
			//String temp2 = recipehere.category.toLowerCase(); // category in lower case
			//recipehere.category = temp2;
			mDbHelper.addRecipe(recipehere);
			// now get list of current recipes on phone, and send to web:
			// need userID and password
			int UserID = Integer.valueOf(mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]);
			String md5password = mDbHelper.getUserSingle()[BackEndSQLite.out_int_md5hashpass];
			
			List<Integer> recipeIDs_bookmarked = mDbHelper.getAllRecipesNotThisUser(UserID);
			// send them to web:
			BackEndPHPHandler myPHP4 = new BackEndPHPHandler();
			myPHP4.bookmarkstoweb(UserID,recipeIDs_bookmarked,md5password);
			mDbHelper.close();
			inDatabase = true;
			// update cookbook
			Cookbook myCookbook = appState.getCookbook();
			if (myCookbook==null){  // make sure this is not null
				appState.createObjects(this);
				myCookbook = appState.getCookbook();
			}
			// have cookbook update values by calling database.
			myCookbook.setupValues();
			// pass this cookbook back to the Chefcontroller
			appState.setCookbook(myCookbook);
		} else {
			Toast.makeText(getBaseContext(), "Recipe Already in Cookbook",
					Toast.LENGTH_SHORT).show();
		}
	}

	private void Add2GroceryList() {
		// add recipe items to grocery list
		BackEndSQLite mDbHelperInner;
		mDbHelperInner = new BackEndSQLite(this);
		mDbHelperInner.open();
		recipehere.partofgrocerylist = 0;
		if (recipehere.Imagehttp==null || recipehere.Imagehttp.equalsIgnoreCase("null")) {  
			recipehere.PictureNameOnDisk=null;
			recipehere.Imagehttp=null;
		} else {
			if (recipehere.PictureNameOnDisk==null) {
				// download file
				if (appState.internetConnectionOpen==true) {
					ImageHandler myImgHandler = new ImageHandler();
					myImgHandler.downloadFile(recipehere.Imagehttp);
					recipehere.PictureNameOnDisk = myImgHandler.imagename;
				} else {
					Toast.makeText(getBaseContext(), "This device may not be connected to the internet",
							Toast.LENGTH_SHORT).show();
				}
			}
		}
		// get chef image, if needed
		// cannot check if a particular recipe has its chefimagedownloaded because
		// one chef can have multiple recipes.  so check database for recipes that have
		// that chef AND have it downloaded:
		if(mDbHelperInner.chefImageDownaloded(recipehere.chefname)==false) {
			// chef image not downloaded so downloaded.
			if (appState.internetConnectionOpen==true) {
				ImageHandler myImgHandler = new ImageHandler();
				String answer=myImgHandler.downloadChefImage(recipehere.user);
				if (answer.equals("None")) {
					// no image
					recipehere.chefimagedownloaded=1;
					recipehere.chefimagename="None";
				} else {
					recipehere.chefimagedownloaded=0;
					recipehere.chefimagename = answer;
				}
			} else {
				recipehere.chefimagedownloaded=1;
				recipehere.chefimagename="None";
			}
		} else {
			// chef image already downloaded
			recipehere.chefimagedownloaded=0;
			// dont update recipehere.chefimagename because it was downloaded previously (another recipe)
		}
		if(mDbHelperInner.hasRecipeBYId(recipehere.recipeid)==false){
			mDbHelperInner.addRecipe(recipehere);
		}
		mDbHelperInner.addFullRecipe2GroceryList(recipehere.recipeid);
		mDbHelperInner.close();
		// update grocery list after database update
		GroceryList myGrocerylist = appState.getGrocerylist();
		// have grocerylist object query database for new info, then refill
		// adapters
		if (appState==null) {
			appState = ((ChefController) getApplicationContext());
			mDbHelperInner = new BackEndSQLite(this);
			mDbHelperInner.open();
			appState.AisleList = mDbHelperInner.getAislelist(userid);
			mDbHelperInner.close();
		}
		myGrocerylist.fillAdapters(appState.AisleList);
		// send gorcery list to the web:
		myGrocerylist.grocerylist2web();
		// give grocerylist back to chefcontroller
		appState.setGroceryList(myGrocerylist);
	}
	
	@Override
	protected void onResume() {
	super.onResume();
		if (wl==null) {
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			// get userID:
			String[] temp = mDbHelper.getUserSingle();
			if(mDbHelper.getWakeLockState(temp[3])) {
				PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
				wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
				Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
			}
			// close DB:
			mDbHelper.close();
		} else {
			wl.acquire();
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (wl==null) {
			mDbHelper = new BackEndSQLite(this);
			mDbHelper.open();
			// get userID:
			String[] temp = mDbHelper.getUserSingle();
			if(mDbHelper.getWakeLockState(temp[3]) ) {
				PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
				wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");
				wl.release();
				Toast.makeText(this, "You have Sleep Disabled in Settings. Screen will not go blank, but more battery power used. ", Toast.LENGTH_LONG).show();
			}
			// close DB:
			mDbHelper.close();
		} else {
			wl.release();
		}
	}

	// define fields
	Map<String, Integer> RecipePic2IntMapper = new HashMap<String, Integer>();
	LinearLayout mLinearLayout;
	Integer recipeID = null;
	private BackEndSQLite mDbHelper;
	Recipe recipehere;
	public String[] instructionsArray;
	public String[] ingredientsArray;
	boolean inDatabase = false; // true=recipe already in DB, false=recipe from
								// search results
	int userid;
	String passwordmd5;
	String username;
	private static final int Cookbook_ID = 0;
	private static final int Grocerylist_ID = 1;
	private static final int Search_ID = 2;
	private static final int Timers_ID = 3;
	private static final int Chef_ID = 4;
	static final int Add2GroceryList_ID = 5;
	static final int Add2Cookbook_ID = 6;
	static final int EmailRecipe_ID = 7;
	private final int Planner_ID = 17;
	static final int RateRecipe_ID = 8;
	static final int DeleteRecipe_ID = 9;
	static final int Contact_ID = 10;
	static final int UpdateRecipe_ID = 11;
    static final int DelecteRecipe_ID = 12;
	ChefController appState;
	Context Ctx;
	private int nodeid = -2;
	private String mealRecipeInformation = "none";	 
}
