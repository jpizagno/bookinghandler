package com.noblebug.chefpro.grocerylist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import com.noblebug.chefpro.R;
import com.noblebug.chefpro.PHP.BackEndPHPHandler;
import com.noblebug.chefpro.SQLite.BackEndSQLite;
import com.noblebug.chefpro.tools.ItemToAisle;
import com.noblebug.chefpro.tools.ListOfLists;
import android.content.Context;
import android.database.Cursor;
import android.widget.ArrayAdapter;
import android.widget.SimpleAdapter;

public class GroceryList {
	// grocery list class. it builds and holds cursors for grocery list.  
	// also syncs grocery list to web with call to PHP.
	// 4 Jun 2011
	
	// constructor is getting context from ChefController, which gets context
	// form Home
	public GroceryList(Context context, String userid, String password) {
		this.mContext = context;
		this.userid = userid;
		this.password = password;
	}

	// get grocery list from database
	// this is called when Chef is started, and called upon updates (recipes
	// added to grocerylist)
	public void fillAdapters(String[] aisleListtemp) {
		Aisle = new String[aisleListtemp.length];
		Aisle = aisleListtemp;
		
		// open database
		// need to put proper context/"this" here.
		mDbHelper = new BackEndSQLite(this.mContext);
		mDbHelper.open();
		
		if (userid==null){
			this.userid = mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid];
		}
		
		// WARNGING this doesn't look right:  what if userid!=4? does Ailse list not work.
		if (Integer.valueOf(userid)==4) {
			Aisle = mDbHelper.getAislelist(Integer.valueOf(userid));
		}
		
		// check for empty aisle list
		if(Aisle[0]==null){
			Aisle = mDbHelper.getAislelist(Integer.valueOf(userid));
		}

		// call ItemToAisle, where things get filled in contsructor
		myItem2Aisle = new ItemToAisle();

		// instantiate adapter variable
		// need to put proper context/"this" here.
		Iterator itr = checkedlist.keySet().iterator();
		while (itr.hasNext()) {
			String item = (String) itr.next();
		}
		
		// add any items in Database to checked list.
		// items in database (persistent) may disagree with checkedlist if device shuts/turns app off
		String[] checkDBitems = mDbHelper.getCrossItems(Integer.valueOf(this.userid));
		if (checkDBitems!=null) {
			if (checkDBitems.length>0){
				// have items in DB, so add to these items to checkedlist, if checked list does NOT already have them
				for (int i=0;i<checkDBitems.length;i++){
					if (checkedlist.containsKey(checkDBitems[i])){;
						checkedlist.put(checkDBitems[i], true);
					} else {
						checkedlist.put(checkDBitems[i], true);
					}
				}
			}
		}
		
		
		adapterAisle = new ListOfLists(this.mContext, this.checkedlist);
		adapterRecipe = new ListOfLists(this.mContext, this.checkedlist);
		adapterCustom = new ListOfLists(this.mContext, this.checkedlist);

		// instantiate full ingredientslist for all recipes
		//fullingredientslist = new LinkedList<Map<String, ?>>();
		fullingredientslist = new ArrayList();
		
		// fill full ingredient list:
		allItemsCursor = mDbHelper.getAllGroceryListItemsAndRecipeName();

		// call fillFullingredientslistWithCursor();
		fillFullingredientslistWithCursor();

		// put ingredient list in Aisle adapter
		addFullList2AdapterAisle();

		// add ingredients in Recipe adapter
		addIngredientsToAdapterRecipe();

		// add this outside loop bc want ingredients from all recipes already in
		// fulingredientlist
		// add ingredientlist to Custom adapter
		addIngredientsToAdapterCustom();
		
		// this is the only method called by the outside.
		// so at end close the database.
		mDbHelper.close();

		// can I close the cursor now?
		allItemsCursor.close();
		
	}

	private void fillFullingredientslistWithCursor() {
		// also add userAddItemlist to full ingredients list
		smallRecipeMap.clear();
		for (int i = 0; i < allItemsCursor.getCount(); i++) {
			allItemsCursor.moveToPosition(i);
			// format: ingrednumber_number_fraction_unit_desc
			String number = allItemsCursor.getString(allItemsCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_QUANTITY));
			String fraction = allItemsCursor.getString(allItemsCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_FRACTION));
			String unit = allItemsCursor.getString(allItemsCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_UNIT));
			String desc = allItemsCursor.getString(allItemsCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_ITEM));
			Integer recipeID = allItemsCursor.getInt(allItemsCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPEID));
			// if ingredients already there
			int testvalue = check4ExistingItem(desc);
			if (testvalue == -1) {
				String caption = "";
				if (number.equalsIgnoreCase("null") == false
						&& number.length() > 0) {
					caption = caption + " " + number;
				}
				if (fraction.equalsIgnoreCase("null") == false
						&& fraction.length() > 0) {
					caption = caption + " " + fraction;
				}
				if (unit.equalsIgnoreCase("null") == false && unit.length() > 0) {
					caption = caption + " " + unit;
				}
				String item = desc+" "+caption;
				item=item.trim();
				fullingredientslist.add(item);
				smallRecipe currentSmallRecipe = new smallRecipe(desc,item,recipeID);
				smallRecipeMap.put(currentSmallRecipe, true);
			}
		}
		// with userAddItmeList having a Recipe(id=-10) this collection of userAddItem not needed
		
		// we want lines to fill the grocerylist 6-Feb-2011.
		if (fullingredientslist.size()<10){
			// add more empty items:
			for (int i=fullingredientslist.size();i<10;i++){
				// add blank space:
				fullingredientslist.add(" ");
			}
		}
		
	}

	public void matchDatabaseWithHomeGroceryList(String Homelisttemp) {
		// this method is called at home. and it gives the webpage the chance
		// to overwrite the database grocery list.  Homelisttemp comes from the webpage.  
		fullingredientslist.clear(); // must recall database now that this is cleared
		allItemsCursor.close();
		mDbHelper = new BackEndSQLite(this.mContext);
		mDbHelper.open();
		// clear old items
		mDbHelper.clearAllIngredients();

		String[] Homelist = Homelisttemp.replace("^^", "%%%").split("%%%");
		// match recipeID,item/desc,caption
		List listRecipeIDitem = new ArrayList();
		for (int m = 1; m < Homelist.length; m++) {
			String itemhome = Homelist[m];
			String descPluscaptionTester = itemhome.trim();
			
			// search through recipes
			Iterator itr_in = smallRecipeMap.keySet().iterator();
			while (itr_in.hasNext()) {
				smallRecipe mySmallRecipe = (smallRecipe) itr_in.next();
				String smallRecipeitem = mySmallRecipe.item;
				if (descPluscaptionTester.equalsIgnoreCase(smallRecipeitem)) {
					Integer recipeID = mySmallRecipe.id;
					String desc = mySmallRecipe.desc;
					String value = desc + "&&&&" + String.valueOf(recipeID);
					listRecipeIDitem.add(listRecipeIDitem.size(), value);
				}
			}
		}

		// update database.
		mDbHelper.addGroceryItems(listRecipeIDitem);
		mDbHelper.close();
	}

	// adds ingredients to adatper for the Custom view
	private boolean addIngredientsToAdapterCustom() {
		// for now it just puts all objects under "custom", without finding aisle first
		String[] itemarray = new String[fullingredientslist.size()];
		for (int m = 0; m < fullingredientslist.size(); m++) {
			String temp = (String) fullingredientslist.get(m);
			String item = temp.trim();
			itemarray[m] = item;
		}
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.mContext, 
				R.layout.list_item, itemarray);
		adapterCustom.addSection("Custom", adapter);
		
		return true;
	}

	// add grocerylist to adapter for Aisle view
	public void addFullList2AdapterAisle() {
		// check each aisle for any ingredients that are located within
		// This is sloppy, because all items are touched several times.
		// I guess this is okay as long as the fullingredientslist isnt too
		// large
		// this is actually bad/slow
		for (int ai = 0; ai < Aisle.length; ai++) {
			List myList = new ArrayList();
			for (int m = 0; m < fullingredientslist.size(); m++) {
				String temp = (String) fullingredientslist.get(m);
				String item = temp.trim();
				String Aisletest = myItem2Aisle.getAisle(item);
				if (Aisletest.equalsIgnoreCase(Aisle[ai])) {
					myList.add(item);
				}
			}
			Iterator tempIT = myList.iterator();
			String[] thisaislearray = new String[myList.size()];
			for (int m=0 ; m<myList.size() ; m++) {
				thisaislearray[m] = (String) tempIT.next();
			}
			// add mapper to thi Aisle/section in adapter IF IT has something
			if (thisaislearray.length>0) {
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.mContext, 
						R.layout.list_item, thisaislearray);
				adapterAisle.addSection("Aisle:  "+ Aisle[ai].replace("_", " "), adapter);
			}
		}
		return;
	}

	// clear adapters
	public boolean clearAllGroceryListAdapters() {
		// clear database, clear ingredientslist
		fullingredientslist.clear();
		adapterAisle = null;
		adapterRecipe = null;
		adapterCustom = null;
		mDbHelper = new BackEndSQLite(this.mContext);
		mDbHelper.open();
		mDbHelper.clearAllIngredients();
		mDbHelper.clearUserAddIngredients();
		mDbHelper.close();
		// clear clicked list as well
		AllItemsCleared();
		// clear recipe list:
		smallRecipeMap.clear();
		return true;
	}

	public void AllItemsCleared() {
		this.checkedlist.clear();
		adapterAisle = new ListOfLists(this.mContext, this.checkedlist);
		List<Map<String, ?>> localmapper = new LinkedList<Map<String, ?>>();
		String item = "Grocery List Empty";
		String caption = "Feel Free to Add Items";
		localmapper.add(createItem(item, caption));
		adapterAisle.addSection("Aisle:  Misc.", new SimpleAdapter(
				this.mContext, localmapper, R.layout.list_complex,
				new String[] { ITEM_TITLE, ITEM_CAPTION }, new int[] {
						R.id.list_complex_title, R.id.list_complex_caption }));
		adapterRecipe = new ListOfLists(this.mContext, this.checkedlist);
		adapterCustom = new ListOfLists(this.mContext, this.checkedlist);
	}

	// checks for exising item in grocery list
	private int check4ExistingItem(String item) {
		int returnvalue = -1;
		for (int m = 0; m < fullingredientslist.size(); m++) {
			String itemtest = (String) fullingredientslist.get(m);
			if (itemtest.equalsIgnoreCase(item)) {
				returnvalue = m;
			}
		}
		return returnvalue;
	}


	// add grocerylist to adapter for Recipe view
	private boolean addIngredientsToAdapterRecipe() {
		// cycle through cursor allItemsCursor
		// make list of recipe/items.
		// may need to cycle through several times, may be slow with many items.
		Map<String, String> RecipenameMap = new HashMap<String, String>();
		for (int m = 0; m < allItemsCursor.getCount(); m++) {
			allItemsCursor.moveToPosition(m);
			String recipename = allItemsCursor.getString(allItemsCursor
					.getColumnIndexOrThrow(BackEndSQLite.KEY_RECIPENAME));
			if (RecipenameMap.containsKey(recipename)) {
				// get old
				String value_old = RecipenameMap.get(recipename);
				// get new, add to old
				String number = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_QUANTITY));
				String fraction = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_FRACTION));
				String unit = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_UNIT));
				String desc = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_ITEM));
				String caption = "";
				if (number.equalsIgnoreCase("null") == false
						&& number.length() > 0) {
					caption = caption + " " + number;
				}
				if (fraction.equalsIgnoreCase("null") == false
						&& fraction.length() > 0) {
					caption = caption + " " + fraction;
				}
				if (unit.equalsIgnoreCase("null") == false && unit.length() > 0) {
					caption = caption + " " + unit;
				}
				String value = value_old + "%%%" + desc + "___" + caption;
				RecipenameMap.put(recipename, value);
			} else {
				// create new
				String number = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_QUANTITY));
				String fraction = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_FRACTION));
				String unit = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_UNIT));
				String desc = allItemsCursor.getString(allItemsCursor
						.getColumnIndexOrThrow(BackEndSQLite.KEY_ITEM));
				String caption = "";
				if (number.equalsIgnoreCase("null") == false
						&& number.length() > 0) {
					caption = caption + " " + number;
				}
				if (fraction.equalsIgnoreCase("null") == false
						&& fraction.length() > 0) {
					caption = caption + " " + fraction;
				}
				if (unit.equalsIgnoreCase("null") == false && unit.length() > 0) {
					caption = caption + " " + unit;
				}
				String value = desc + "___" + caption;
				RecipenameMap.put(recipename, value);
			}
		}

		Collection c = RecipenameMap.keySet();
		Iterator itr = c.iterator();
		while (itr.hasNext()) {
			String recipename = (String) itr.next();
			String[] values = RecipenameMap.get(recipename).split("%%%");
			String[] recipearray = new String[values.length];
			for (int m = 0; m < values.length; m++) {
				String desc = values[m].split("___")[0];
				// caption may not be there
				String caption;
				if (values[m].split("___").length>1) {
					caption = values[m].split("___")[1];
				} else {
					caption = " ";
				}
				String item = desc+" "+caption;
				recipearray[m] = item.trim();
			}
			adapterRecipe.addSection("Recipe:  " + recipename, 
					new ArrayAdapter<String>(this.mContext, R.layout.list_item, recipearray));
		}
		
		// want to add blank lines and "add recipe " title if empty
		if (allItemsCursor.getCount()==0){
			// add blank lines:
			String[] recipearray = new String[10];
			for (int i=0;i<10;i++){
				recipearray[i]=" ";
			}
			adapterRecipe.addSection("Add a recipe", 
					new ArrayAdapter<String>(this.mContext, R.layout.list_item, recipearray));
		}
		
		allItemsCursor.close();
		return true;
	}

	private class smallRecipe {
		// like a small recipe object. it holds some of the information.
		String item;
		Integer id;
		String desc;

		public smallRecipe(String desctemp, String itemtemp, Integer tempID) {
			item=itemtemp;
			desc=desctemp;
			id = tempID;
		}
	}

	public void closeDatabase() {
		mDbHelper.close();
	}

	// getter methods, called by GrocerylistDisplay
	public ListOfLists getAdapterAisle() {
		return adapterAisle;
	}
	public ListOfLists getAdapterRecipe() {
		return adapterRecipe;
	}
	public ListOfLists getAdapterCuston() {
		return adapterCustom;
	}

	// need recipe for duplicate items in different recipe
	public void checkItem( String item) {
		checkedlist.put(item, true);
	}

	private String buildCheckedListKEY(String item) {
		String key = item;  //title + "%_%_%" + caption;
		return key;
	}

	public void UncheckItem( String item) {
		checkedlist.remove(item);
	}

	public void clearCheckedItems() {
		// make a map of <recipeID (int), title(string)>
		Map<Integer, String> RecipeIDitemMap = new HashMap<Integer, String>();
		List<String> UserAddItemList = new ArrayList<String>();
		
		List listRecipeIDitem = new ArrayList();
		Collection c = checkedlist.keySet();
		Iterator itr = c.iterator();
		while (itr.hasNext()) {
			String item = (String) itr.next();
			//System.out.println("****** GroceryList::ClearCheckedItems item.length="+String.valueOf(item.length()));

			fullingredientslist.remove(item);

			Iterator itr_in = smallRecipeMap.keySet().iterator();
			Integer recipeID = 0;
			String itemtest = "error in GroceryList";
			while (itr_in.hasNext()) {
				smallRecipe mySmallRecipe = (smallRecipe) itr_in.next();
				//System.out.println("******** GroceryList::clearCheckedItems mySmallRecipe.item="+mySmallRecipe.item+".");
				// if recipeid=-10 then working with useradded recipe. use different collection:
				// need to also remove the item, not just set partofgrocerylist=1.
				//System.out.println("******** GroceryList::clearCheckedItems mySmallRecipe.id="+String.valueOf(mySmallRecipe.id)+".");
				if (mySmallRecipe.id==-10) {
					if (item.equalsIgnoreCase(mySmallRecipe.item)) {
						//System.out.println("******** GroceryList::clearCheckedItems item="+item+".");
						UserAddItemList.add(item);
					}
				} else {
					if (item.equalsIgnoreCase(mySmallRecipe.item)) {
						String value = mySmallRecipe.desc + "&&&&" + String.valueOf(mySmallRecipe.id);
						listRecipeIDitem.add(listRecipeIDitem.size(), value);
					}
				}
			}
		}
		mDbHelper = new BackEndSQLite(this.mContext);
		mDbHelper.open();
		mDbHelper.clearCheckedGroceryItems(listRecipeIDitem); // RecipeIDitemMap);
		if (UserAddItemList.size()>0) {
			mDbHelper.clearUserItems(UserAddItemList);
		}
		mDbHelper.close();

		checkedlist.clear();
	}

	public void grocerylist2web() {
		if (this.userid==null){
			// should only happen first time after user first logs on
			mDbHelper = new BackEndSQLite(this.mContext);
			mDbHelper.open();
			//String temp = mDbHelper.getUserIDpassword();
			this.userid = mDbHelper.getUserSingle()[BackEndSQLite.out_int_userid]; //temp.split("_")[0];" +		
			mDbHelper.close();
		}
		
		if(Integer.valueOf(this.userid)>-1) {
			//System.out.println("****** Called grocerylist2web()");
			// send list to web
			List GroceryList2web = new ArrayList();
			for (int m = 0; m < fullingredientslist.size(); m++) {
				String item = (String) fullingredientslist.get(m);
				GroceryList2web.add(m, item );  //+ " " + caption);
			}
			BackEndPHPHandler myPHPHandler = new BackEndPHPHandler();
			myPHPHandler.sendGroceryList2Web(userid, password, GroceryList2web);
		} else {
			//System.out.println("****** NOT calling grocerylist2web() userid="+this.userid);
		}
	}
	
	public void addUserItem(String string) {
		// add item to "odd n ends" recipe;
		mDbHelper = new BackEndSQLite(this.mContext);
		mDbHelper.open();
		//System.out.println("***** Grocerylist::addUserItem string.length = "+String.valueOf(string.length()));
		String[] listofAllOddsNEnds = mDbHelper.addItem2OddsNEnds(string.trim());		
		mDbHelper.close();
	}
	

	// create fields, variables
	public String[] Aisle;
	public final  String ITEM_TITLE = "title";
	public final  String ITEM_CAPTION = "caption";
	public final  String ITEM = "item";
	private BackEndSQLite mDbHelper;
	private ListOfLists adapterAisle;
	private ListOfLists adapterRecipe;
	private ListOfLists adapterCustom;
	private List fullingredientslist ;
	ItemToAisle myItem2Aisle;
	private Context mContext;
	// items which are clicked;
	Map<String, Boolean> checkedlist = new HashMap<String, Boolean>();
	Map<smallRecipe, Boolean> smallRecipeMap = new HashMap<smallRecipe, Boolean>();
	private Cursor allItemsCursor;
	private String userid;
	private String password;

	// createItem()
	public Map<String, ?> createItem(String title, String caption) {
		Map<String, String> item = new HashMap<String, String>();
		item.put(ITEM_TITLE, title);
		item.put(ITEM_CAPTION, caption);
		return item;
	}

}
