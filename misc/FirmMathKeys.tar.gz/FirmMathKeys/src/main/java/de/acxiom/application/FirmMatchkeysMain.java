package de.acxiom.application;



/**
 * required libraries:
 * required libraries:  
 * commons-configuration-1.6.jar
 * commons-httpclient-3.0.1.jar
 * commons-lang-2.4.jar
 * commons-logging-1.1.1.jar
 * commons-logging-api-1.0.4.jar
 * core-3.1.1.jar
 * jackson-core-asi-1.8.8.jar
 * jackson-mapper-asl-1.8.8.jar
 * log4j-1.2.15.jar
 * hadoop-core-1.2.1jar
 */

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;


/**
 * @author jim pizagno
 * 04.05.2016
 *
 */
public class FirmMatchkeysMain {
	
	public static void main(String[] args) throws IOException {
		
		if (args.length!=3) {
			System.out.println("wrong number of parameters.");
			System.out.println("Example Call:");
			System.out.println("	shell% hadoop jar FirmMatchKeys-0.0.2-SNAPSHOT-jar-with-dependencies.jar "
					+ " <input path> <output path> <int number reducers>");
			System.exit(1);
		}
		
		JobConf conf = new JobConf(FirmMatchkeysMain.class);
		conf.setJobName("Firm Match Keys");
		
		FileInputFormat.addInputPath(conf, new Path(args[0]));
		FileOutputFormat.setOutputPath(conf, new Path(args[1]));
		conf.setNumReduceTasks(Integer.parseInt(args[2]));

		//http://stackoverflow.com/questions/24070557/what-is-the-relation-between-mapreduce-map-memory-mb-and-mapred-map-child-jav
		// mapreduce 1:
		// "heap available" :
		// mapred.child.java.opts (overriden by the 2 below):
		conf.set("mapred.map.child.java.opts", "-Xmx4096m");  // in production:-Xmx4096m, VM:-Xmx1024m
		conf.set("mapred.reduce.child.java.opts", "-Xmx8192m"); // in production:-Xmx8192m, VM:-Xmx1024m
		// "total memory":  (should be 25% bigger than above 2 settings)     
		conf.set("mapred.job.map.memory.mb", "5120");  // in production:5120, VM: 1024
		conf.set("mapred.job.reduce.memory.mb", "9216");// in production:9216, VM: 1024
		
		// MapRed 1. Fulfillment cluster
		conf.set("mapred.textoutputformat.separator", ",");
		// MapRed 2. Production Cluster, VM 
		//conf.set("mapreduce.output.textoutputformat.separator", ",");
		
		conf.setMapperClass(FirmMatchkeysMapper.class);
		conf.setReducerClass(FirmMatchkeysReducer.class);

		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(Text.class);
		
		JobClient.runJob(conf);
	}
}
