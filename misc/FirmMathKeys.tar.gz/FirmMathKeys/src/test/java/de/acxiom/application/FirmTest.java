package de.acxiom.application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.apache.hadoop.mrunit.MapDriver;
import org.apache.hadoop.mrunit.MapReduceDriver;
import org.apache.hadoop.mrunit.ReduceDriver;
import org.apache.hadoop.mrunit.types.Pair;

public class FirmTest {

	MapDriver<LongWritable, Text, Text, Text> mapDriver;
	ReduceDriver<Text, Text, Text, Text> reduceDriver;
	MapReduceDriver<LongWritable, Text, Text, Text, Text, Text> mapReduceDriver;

	@Before
	public void setUp() {
		FirmMatchkeysMapper mapper = new FirmMatchkeysMapper();
		FirmMatchkeysReducer reducer = new FirmMatchkeysReducer();
		mapDriver = MapDriver.newMapDriver(mapper);
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
		mapReduceDriver = MapReduceDriver.newMapReduceDriver(mapper, reducer);
	}

	@Test
	public void testMapper() throws IOException {
		String input = "key1" ;
		input += "\t" + "col4";
		input += "\t" + "4";
		mapDriver.withInput(new LongWritable(), new Text(input));
		mapDriver.withOutput(new Text("key1"), new Text("4"+FirmMatchkeysMapper.getParserField()+"col4"));
		mapDriver.runTest();
	}

	@Test
	public void testReducer() throws IOException {
		String key = "key1" ;
		List<Text> values = new ArrayList<Text>();
		String input1 = "4"+FirmMatchkeysMapper.getParserField()+"col4" ;
		values.add(new Text(input1));
		String input2 = "5"+FirmMatchkeysMapper.getParserField()+"col5" ;
		values.add(new Text(input2));
		reduceDriver.withInput(new Text(key), values);
		reduceDriver.withOutput(new Text(key), new Text(",,,col4,col5,,,,,,,,,,,,,,,,,,,,,,,,,"));
		reduceDriver.runTest();
	}

	@Test
	@Ignore("just for long testing")
	public void testMapReduce() throws IOException {
		// ERROR WARNING does NOT actually run a test, it just runs.  
		List<String> inputList = new ArrayList<String>();
		File file = new File("C:\\Users\\jpizag\\Firm\\input_bigdata\\Firminput");
		BufferedReader reader = null;
		try {
		    reader = new BufferedReader(new FileReader(file));
		    String text = null;

		    while ((text = reader.readLine()) != null) {
		        inputList.add(text);
		    }
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		} finally {
		    try {
		        if (reader != null) {
		            reader.close();
		        }
		    } catch (IOException e) {
		    }
		}

		for (String input : inputList) {
			int i = Integer.parseInt(  input.split("\\t", -1)[0].replace("key", "") ) ;
			mapReduceDriver.addInput(new LongWritable(i), new Text(input));
		}

		Pair<Text, Text> outputRecord = new Pair(new Text("key"), new Text("not running"));
		mapReduceDriver.addOutput(outputRecord );

		mapReduceDriver.run();  //.runTest();
	}
}
